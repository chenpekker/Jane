/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of the Harvey Mudd College nor the names of its
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


import java.util.*;
import java.io.*;

public class Jane {

    public static Random rand = new Random();
    static int costs[] = {0, 1, 1, 2};
    static int numIter = 30;
    static int popSize = 30;
    static double m = 0.6;
    static double selectStr = .8;
    static String filename = null;
    static boolean verbose = false;
    static boolean tarzan = false;
    static int switchDist = -1;
    static String outputFile = null;


    static void usage() {
        System.err.println("usage: java Jane [-help] [-V] [-c {Cospeciation,Duplication,Switch,Loss}] [-T] [-m mutation_rate] [-p population_size] [-i iterations] [-s selection_strength] [-S max_switch_distance] [-o outputFile] file");
        System.exit(1);
    }

    static void readArgs(String[] args) {
        int index = 0;

        while (index < args.length) {
            if ("-c".equals(args[index])) {
                index++;
                costs = new int[4];
                for (int i = 0; i < 4; ++i) {
                    try {
                        costs[i] = Integer.parseInt(args[index]);
                    } catch (NumberFormatException e) {
                        System.err.println("The -c flag must be followed with 4 integers representing the costs of various operations.");
                        usage();
                    }
                    index++;
                }
            } else if("-help".equals(args[index]) || "-h".equals(args[index]) || "--h".equals(args[index]) || "--help".equals(args[index]) || "-?".equals(args[index])){
                help();
            } else if("-o".equals(args[index])){
                index++;
                outputFile = args[index];
                index++;
            }else if ("-m".equals(args[index])) {
                index++;
                try {
                    m = Double.parseDouble(args[index]);
                } catch (NumberFormatException e) {
                    System.err.println("The argument following -m must be a number");
                    usage();
                }
                index++;
            } else if ("-p".equals(args[index])) {
                index++;
                try {
                    popSize = Integer.parseInt(args[index]);
                } catch (NumberFormatException e) {
                    System.err.println("The argument following -p must be a number");
                    usage();
                }
                index++;
            } else if ("-i".equals(args[index])) {
                index++;
                try {
                    numIter = Integer.parseInt(args[index]);
                } catch (NumberFormatException e) {
                    System.err.println("The argument following -i must be a number");
                    usage();
                }
                index++;
            } else if ("-s".equals(args[index])) {
                index++;
                try {
                    selectStr = Double.parseDouble(args[index]);
                } catch (NumberFormatException e) {
                    System.err.println("The argument following -s must be a number");
                    usage();
                }
                index++;
            } else if ("-V".equals(args[index])) {
                index++;
                verbose = true;
            } else if ("-T".equals(args[index])) {
                index++;
                tarzan = true;
            } else if ("-S".equals(args[index])) {
                index++;
                try {
                    switchDist = Integer.parseInt(args[index]);
                } catch (NumberFormatException e) {
                    System.err.println("The argument following -S must be an integer");
                    usage();
                }
            } else if (args[index].startsWith("-")) {
                System.err.println("Unrecognized command-line switch: " + args[index]);
                usage();
            } else {
                break;
            }
        }

        if (index == args.length - 1) {
            filename = args[index];
        } else if (index >= args.length) {
            System.err.println("No filename provided");
            usage();
        } else {
            System.err.println("Unexpected arguments after the filename");
            usage();
        }
        return;
    }

    public static void main(String[] args) throws FileFormatException, heuristics.NoValidSolutionException{
        readArgs(args);

        TreeFileReader fin = null;
        try {
            fin = new NexusFileReader(filename);
            if (!((NexusFileReader) fin).isNexus()) {
                fin = new TarzanFileReader(filename);
            }
        } catch (java.io.FileNotFoundException e) {
            System.err.println("Could not find file: " + filename);
            System.exit(1);
        }catch(java.io.IOException e){
            System.err.println("Error reading file.\n"+e.getLocalizedMessage());
            System.exit(1);
        }

        try{
            TreeFileReader.ProblemInstance pi = fin.readProblem();

            Vector<pNetwork> sols = heuristics.genetic(pi, costs, numIter, popSize, m, selectStr, tarzan, switchDist);
            if(outputFile != null && sols.size() > 0)
            {
                try{
                    java.io.FileWriter fw = new java.io.FileWriter(outputFile);
                    fw.write(sols.get(0).fileTimingString());
                    fw.close();
                }
                catch(java.io.IOException e)
                {
                    System.err.println("Unable to write to the specified filename");
                    System.err.println(e);
                }
            }
       }
        catch(Exception e)
        {
            System.err.println("Something went pretty seriously wrong");
            System.err.println(e);
        }
    }

    private static void help() {
        System.out.println("usage: java Jane [-options] filename\n\n" +
                "Where [-options] include:\n" +
                "\t-help\tPrint this help message\n" +
                "\t-V\tTurns on verbose output\n" +
                "\t-T\tCauses Jane to evaluate costs the way Tarzan does rather than the way treeMap does\n" +
                "\t-c <cosp dup switch loss>\tThis defines the cost vector to use i.e. -c 0 1 2 3 \n" +
                "\t\twould cause cospeciations to cost 0, duplications to cost 1, host switches to cost\n" +
                "\t\t2, and losses/sorting to cost 3\n" +
                "\t\tDefault costs are cospeciation: " + costs[0] + ", duplication: " + costs[1] + ", host switch: " + costs[2] + ", loss/sorting: " + costs[3] + "\n" +
                "\t-m <value>\tSets the mutation rate. Appropriate values fall on the interval [0, 1] with 0 being never mutate and 1 being always mutate\n" +
                "\t\t\tDefaults to: " + m + "\n" +
                "\t-p <value>\tSets the initial population size\n" +
                "\t\t\tDefaults to: " + popSize + "\n" +
                "\t-i <value>\tSets the number of iterations that the algorithm should run\n" +
                "\t\t\tDefaults to: " + numIter + "\n" +
                "\t-s <value>\tSets the selection strength. 0 is completely random and there is no upper bound\n" +
                "\t\t\tDefaults to: " + selectStr + "\n" +
                "\t-S <value>\tSets the maximum host switch distance allowed. -1 causes the distance to be unlimited\n" +
                "\t\t\tDefaults to: " + switchDist + "\n" +
                "\t-o <filename>\tCauses output to be dumped to a file called <filename>");

        System.exit(0);
    }
}
