/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of the Harvey Mudd College nor the names of its
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

import java.util.*;

public class node extends treeLocation implements Comparable
{
	boolean isEdge()
	{
		return false;
	}

        @Override
	public String toString()
	{
		return fancyName;
	}
	public String timingString()
	{
		return String.format("Node name: %-30s Time: %-3d Zone: %-3d", name, time, this.zone);
	}

        public String fileTimingString()
        {
            return String.format("%d,%d,%d", name, time, this.zone);
        }

	public boolean equals(node other)
	{
		return this.name == other.name;
	}
	node(int name, String fancyName)
	{
		this.name = name;
		this.fancyName = fancyName;
		this.outDegree = 0;
		this.inDegree = 0;
		this.time = 0;
		this.counter = 0;
	}
	node(node n)
	{
		name = n.name;
		fancyName = n.fancyName;
		children = n.children;
		outDegree = n.outDegree;
		inDegree = n.inDegree;
		time = n.time;
		counter = n.counter;
		ancestors = n.ancestors;
		zone = n.zone;
                region = n.region;
	}
	boolean Tip()
	{
		return this.outDegree == 0;
	}
	boolean Root()
	{
		return this.inDegree == 0;
	}
	void addParent(node p)
	{
		inDegree++;
		parents.add(p);
		ancestors.put(p, 1);
	}
	void addChild(node c)
	{
		outDegree++;
		children.add(c);
	}

	void addZone(int i){
		timeZones.add(i);
	}


	// checks to make sure n can occur cotemporaneously with this node
	// do NOT call using a node argument which doesnt have an explicit time zone
	boolean cotemp(node n){
		return this.timeZones.contains(n.zone);
	}

	boolean cotemp(edge e){
		return this.timeZones.firstElement() <= e.second.zone && this.timeZones.lastElement() >= e.first.zone;
	}
		   
	public int compareTo(Object other)
	{
		return this.name - ((node)other).name;
	}
	//Information about the node
	int name;
	int time;
	int counter;
	String fancyName;
	
	//Bookkeeping for time zones
	int zone;
	Vector<Integer> timeZones = new Vector<Integer>();
	boolean assigned = false;

        int region; // the region in which the node occurs
	
	//Information about the relationship of the node to other nodes
	Vector<node> children = new Vector<node>();
	int outDegree;
	int inDegree;
	Vector<node> parents = new Vector<node>();
	Map<node, Integer> ancestors = new HashMap<node, Integer>();
}
