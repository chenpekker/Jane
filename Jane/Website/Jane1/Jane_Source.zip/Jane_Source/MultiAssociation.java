/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of the Harvey Mudd College nor the names of its
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 *
 * @author dfielder
 */
import java.util.HashSet;
import java.util.Vector;
public class MultiAssociation extends Association{
    public MultiAssociation(AssociationType type, node parasite, treeLocation associate,
                            int time, int cost, Association child1, Association child2,
                            Vector<Vector<MultiAssociation>> child1options, Vector<Vector<MultiAssociation>> child2options)
    {
        super(type, parasite, associate, time, cost, child1, child2);
        this.child1options = child1options;
        this.child2options = child2options;
    }

    public MultiAssociation(AssociationType type, node parasite, treeLocation associate,
                            treeLocation switchTarget, int time, int cost, Association child1, Association child2,
                            Vector<Vector<MultiAssociation>> child1options, Vector<Vector<MultiAssociation>> child2options, Vector<Vector<treeLocation>> switchTargets)
    {
        super(type, parasite, associate, switchTarget, time, cost, child1, child2);
        this.child1options = child1options;
        this.child2options = child2options;
        this.switchTargets = switchTargets;
    }

    void calculateMinCosts(pNetwork hostTree)
    {
        minChild1Costs = new Vector<Integer>();
        minChild2Costs = new Vector<Integer>();
        for(int i = 0; i < child1options.size(); i++)
        {
            int min1Cost = pNetwork.INFINITY;
            int min2Cost = pNetwork.INFINITY;
            for(int i2 = 0; i2 < child1options.get(i).size(); i2++)
            {
                min1Cost = Math.min(min1Cost, subAssociationCost(i,i2,1, hostTree));
            }
            for(int i2 = 0; i2 < child2options.get(i).size(); i2++)
                min2Cost = Math.min(min2Cost, subAssociationCost(i, i2, 2, hostTree));
            minChild1Costs.add(min1Cost);
            minChild2Costs.add(min2Cost);
        }
    }

    static Vector<MultiAssociation> clones;
    public MultiAssociation clone()
    {
        boolean root = false;
        if(clones == null)
        {
            root = true;
            clones = new Vector<MultiAssociation>();
        }

        int cloneIndex = clones.indexOf(this);
        if(cloneIndex != -1)
        {
            return clones.get(cloneIndex);
        }

        if(type==AssociationType.TIP)
        {
            MultiAssociation answer = new MultiAssociation(type, parasite, associate, time, cost, AChild1, AChild2, child1options, child2options);
            clones.add(answer);
            return answer;
        }

        Vector<Vector<MultiAssociation>> new1opt = new Vector<Vector<MultiAssociation>>();
        Vector<Vector<MultiAssociation>> new2opt = new Vector<Vector<MultiAssociation>>();
        MultiAssociation newAChild1 = null;
        MultiAssociation newAChild2 = null;

        for(Vector<MultiAssociation> oldopt : child1options)
        {
            Vector<MultiAssociation> newopt = new Vector<MultiAssociation>();
            for(MultiAssociation asc : oldopt)
            {
                MultiAssociation cln = asc.clone();
                if(asc.equals(AChild1))
                    newAChild1 = cln;
                newopt.add(cln);
            }
            new1opt.add(newopt);
        }

        for(Vector<MultiAssociation> oldopt : child2options)
        {
            Vector<MultiAssociation> newopt = new Vector<MultiAssociation>();
            for(MultiAssociation asc : oldopt)
            {
                MultiAssociation cln = asc.clone();
                if(asc.equals(AChild2))
                    newAChild2 = cln;
                newopt.add(cln);
            }
            new2opt.add(newopt);
        }

        MultiAssociation answer;
        if(type == AssociationType.HOST_SWITCH)
        {
            answer = new MultiAssociation(type, parasite, associate, switchTarget, time, cost, newAChild1, newAChild2, new1opt, new2opt, switchTargets);
        }
        else
        {
            answer = new MultiAssociation(type, parasite, associate, time, cost, newAChild1, newAChild2, new1opt, new2opt);
        }
        clones.add(answer);

        if(root)
            clones = null;
        return answer;
    }

    int getCost(pNetwork hostTree)
    {
        switch(type)
        {
            case COSPECIATION:
                if(Solver.TARZAN)
                    return Solver.costs[Solver.COSPECIATION];
                else
                    return Solver.costs[Solver.COSPECIATION] * 2;
            case DUPLICATION:
                if(Solver.TARZAN)
                    return Solver.costs[Solver.DUPLICATION];
                else
                    return Solver.costs[Solver.DUPLICATION] * 2;
            case HOST_SWITCH:
                if(Solver.TARZAN)
                    return Solver.costs[Solver.SWITCH] + hostTree.regionCosts.get(((edge)associate).second.region).get(((edge)switchTarget).second.region);
                else
                    return Solver.costs[Solver.SWITCH] + 2 * Solver.costs[Solver.DUPLICATION] + hostTree.regionCosts.get(((edge)associate).second.region).get(((edge)switchTarget).second.region);
            default:
                return 0;
        }
    }

    int subAssociationCost(int i1, int i2, int whichChild, pNetwork hostTree)
    {
        Vector<treeLocation> candidates = new Vector<treeLocation>();
        Association asc = null;
        if(whichChild == 1)
            asc = child1options.get(i1).get(i2);
        else
            asc = child2options.get(i1).get(i2);

        if(associate instanceof node)
            for(node child: ((node)associate).children)
                candidates.add(new edge((node)associate, child));
        else
            candidates.add(associate);
        if(type == AssociationType.HOST_SWITCH)
            candidates.add(switchTargets.get(i1).get(i2));

        int minCost = pNetwork.INFINITY;

        for(treeLocation loc:candidates)
        {
            minCost = Math.min(minCost, asc.cost + hostTree.distance(loc, asc.associate) * Solver.costs[Solver.LOSS]);
        }
        return minCost;
    }

    int childCost(MultiAssociation asc, pNetwork hostTree)
    {
        Vector<treeLocation> candidates = new Vector<treeLocation>();

        if(associate instanceof node)
            for(node child: ((node)associate).children)
                candidates.add(new edge((node)associate, child));
        else
            candidates.add(associate);
        if(type == AssociationType.HOST_SWITCH)
            candidates.add(switchTarget);

        int minCost = pNetwork.INFINITY;

        for(treeLocation loc:candidates)
        {
            minCost = Math.min(minCost, asc.cost + hostTree.distance(loc, asc.associate) * Solver.costs[Solver.LOSS]);
        }
        return minCost;
    }

    void reCalculateCosts(pNetwork hostTree)
    {
        this.cost = childCost((MultiAssociation)AChild1, hostTree) +
                    childCost((MultiAssociation)AChild2, hostTree) +
                    this.getCost(hostTree);
        this.countEvents(hostTree);
    }

    public boolean equals(Object other)
    {
        if(other instanceof Association)
            return this.equals((Association) other);
        else
            return false;
    }

    //wow this is a bad hash!
    public int hashCode()
    {
        return this.associate.hashCode() ^ this.parasite.hashCode() + this.type.hashCode() + this.time;
    }

    boolean equals(Association other)
    {
        return this.associate.equals(other.associate) && this.parasite.equals(other.parasite) && this.type == other.type && this.time == other.time;
    }

    Vector<Vector<MultiAssociation>> child1options;
    Vector<Vector<MultiAssociation>> child2options;
    Vector<Integer> minChild1Costs;
    Vector<Integer> minChild2Costs;
    Vector<Vector<treeLocation>> switchTargets;
}
