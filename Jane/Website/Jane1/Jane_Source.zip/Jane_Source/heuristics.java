/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of the Harvey Mudd College nor the names of its
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

import java.util.*;

class heuristics {

    /* Randomizes the timing of the given pNetwork within the constraints of its
     * time zones
     */
    static void randomizeTimes(pNetwork network) throws InconsistentTreeException, TreeFormatException {
        network.initializeCounters();
        Set<Integer> zList = network.zoneList.keySet();
        int tipTime = network.tips().size();
        node root = network.root();
        root.time = 0;
        root.assigned = true;
        root.zone = zList.iterator().next();
        int time = 1;
        Iterator<Integer> it = zList.iterator();
        while (it.hasNext()) {
            int curZone = it.next();
            Vector<Integer> zVector = new Vector<Integer>(network.zoneList.get(curZone));

            Vector<Integer> remaining = new Vector<Integer>();

            network.zoneTimes.put(curZone, time);
            while (!zVector.isEmpty()) {
                int randIndex = Jane.rand.nextInt(zVector.size());
                node temp = network.nodes.get(zVector.get(randIndex));
                zVector.removeElementAt(randIndex);
                // may want to support reticulation
                boolean parents = true;
                for (int i = 0; i < temp.inDegree; i++) {
                    if (!temp.parents.get(i).assigned) {
                        parents = false;
                    }
                    if (temp.parents.get(i).timeZones.firstElement() > temp.timeZones.lastElement()) {
                        throw new TreeFormatException("Node " + temp.parents.get(i).fancyName + " is a parent of Node " + temp.fancyName + " but is restricted to a later zone");
                    }
                }

                if (parents) {
                    double d = Jane.rand.nextDouble();
                    if (d < temp.timeZones.size() && !temp.assigned && !temp.Tip()) {
                        temp.assigned = true;
                        temp.time = time;
                        temp.zone = curZone;
                        if (time > network.zoneTimes.get(curZone)) {
                            network.zoneTimes.put(curZone, time);
                        }
                        time++;
                    } else if (temp.Tip() && !temp.assigned) {
                        if (temp.timeZones.lastElement() != network.finalZone) {
                            throw new TreeFormatException("Tip " + temp.name + " was not assigned to the final time zone!");
                        }
                        temp.assigned = true;
                        temp.time = tipTime;
                        temp.zone = network.finalZone;
                        network.zoneTimes.put(curZone, tipTime);
                    }
                } else {
                    remaining.add(temp.name);
                }
                if (zVector.isEmpty()) {
                    zVector = new Vector<Integer>(remaining);
                    remaining = new Vector<Integer>();
                }
            }
        }
        if (!network.checkConsistency()) {
            throw new InconsistentTreeException("RandomizeTimes somehow created a timing inconsistent with time zones");
        }
    }

    /* Runs solver a bunch of times.
     */
    static void multiSolve(TreeFileReader.ProblemInstance problem, int solves, int switchDist) throws InconsistentTreeException, TreeFormatException {
        Vector<Thread> vt = new Vector<Thread>();
        Vector<Solver> vs = new Vector<Solver>();
        pNetwork host = new pNetwork(problem.host, problem.hostRanks, problem.hostNames, problem.regionCosts, problem.hostRegions);
        pNetwork parasite = new pNetwork(problem.parasite, problem.parasiteRanks, problem.parasiteNames);
        randomizeTimes(host);
        for (int i = 0; i < solves; ++i) {
            Solver s = new Solver(host, parasite, problem.phi, new int[]{1, 1, 1, 2}, switchDist);
            vs.add(s);
            Thread t = new Thread(s);
            t.start();
            vt.add(t);
        }
        for (Thread t : vt) {
            try {
                t.join();
            } catch (Exception ignore) {
            }
        }
    }


    /* Uses a simulated annealing heuristic to generate solutions. This section of code
     * is old and unused and may have issues but here it is in case someone wants to mess
     * with it.
     */
    static double simulatedAnnealing(TreeFileReader.ProblemInstance problem, int[] costs, double[] schedule) throws InconsistentTreeException, TreeFormatException {
        pNetwork hostNetwork = new pNetwork(problem.host, problem.hostRanks, problem.hostNames, problem.regionCosts, problem.hostRegions);
        pNetwork parasiteTree = new pNetwork(problem.parasite, problem.parasiteRanks, problem.parasiteNames);

        hostNetwork.initializeCounters();
        parasiteTree.initializeCounters();
        randomizeTimes(hostNetwork);
        Solver instance = new Solver(hostNetwork, parasiteTree, problem.phi, costs, -1);
        double bestCost = instance.solve();

        System.err.println("\nInitial Cost: " + bestCost + "\nInitial Configuration:" + instance.hostNetwork + "\nSolution:\n" + instance.printOptimal());
        System.out.println("Initial Energy:" + bestCost);

        instance.printOptimal();
        Solver bestInstance = new Solver(instance);
        Solver currentInstance = new Solver(bestInstance);
        double currentCost = bestCost;

        int maxInterior = hostNetwork.tips().size() - 1;
        boolean done = false;

        int index = 0;
        while (!done) {
            pNetwork newHostNetwork = new pNetwork(bestInstance.hostNetwork);

            // only try to twiddle nodes 100 times before stopping. this is to prevent trees with very
            // strict timing due to zoning from making this loop infinite.
            for (int i = 0; i < 100; i++) {
                int candidateTime = (Jane.rand.nextInt(maxInterior - 1)) + 2;
                node node1 = bestInstance.hostNetwork.nodeAtTime(candidateTime);
                node node2 = bestInstance.hostNetwork.nodeAtTime(candidateTime - 1);

                if (bestInstance.hostNetwork.descendant(node1, node2) || bestInstance.hostNetwork.descendant(node2, node1)) {
                    continue;
                }
                if (node1.timeZones.lastElement() <= node2.timeZones.firstElement()) {
                    newHostNetwork.nodes.get(node1.name).time = candidateTime - 1;
                    newHostNetwork.nodes.get(node2.name).time = candidateTime;
                    int temp = node1.zone;
                    node1.zone = node2.zone;
                    node2.zone = temp;
                    newHostNetwork.initializeCounters();
                    parasiteTree.initializeCounters();
                    break;
                }
            }

            //time the running of the solver
            long startTime = System.currentTimeMillis();

            Solver newInstance = new Solver(newHostNetwork, parasiteTree, problem.phi, costs, -1);
            double cost = newInstance.solve();

            double timeTaken = (System.currentTimeMillis() - startTime) / (1000.0);
            System.out.println("solver," + index + "," + timeTaken);

            if (index < schedule.length) {
                index++;
            }

            if (cost < bestCost) {
                bestCost = cost;
                bestInstance = newInstance;
                currentCost = bestCost;
                currentInstance = bestInstance;
            } else if (index >= schedule.length) {
                done = true;
            } else {
                double p = Math.exp((bestCost - cost) / schedule[index]);
                if (Jane.rand.nextDouble() <= p) {
                    currentCost = cost;
                    currentInstance = newInstance;
                }
            }
        }

        System.err.println("\nFinal Cost: " + currentCost + "\nFinal Configuration:" + currentInstance.hostNetwork + "\nSolution:" + currentInstance.optSol);
        System.out.println("Final Energy:" + currentCost);
        System.err.println("\nBest Cost: " + bestCost + "\nInitial Configuration:" + bestInstance.hostNetwork + "\nSolution:" + bestInstance.optSol);
        System.out.println("Best Energy:" + bestCost);

        bestInstance.bestAssoc.countEvents(bestInstance.hostNetwork);
        System.out.println("Cospeciation:" + bestInstance.bestAssoc.eventCounts[Solver.COSPECIATION]);
        System.out.println("Duplication:" + bestInstance.bestAssoc.eventCounts[Solver.DUPLICATION]);
        System.out.println("Host Switch:" + bestInstance.bestAssoc.eventCounts[Solver.SWITCH]);
        System.out.println("Loss:" + bestInstance.bestAssoc.eventCounts[Solver.LOSS]);
        return bestCost;
    }

    /* Generates random timing configurations and then solves them for a given
     * period of time.
     */
    static double shotgun(TreeFileReader.ProblemInstance problem, int[] costs, long time) throws InconsistentTreeException, TreeFormatException {
        pNetwork hN = new pNetwork(problem.host, problem.hostRanks, problem.hostNames, problem.regionCosts, problem.hostRegions);
        pNetwork pN = new pNetwork(problem.parasite, problem.parasiteRanks, problem.parasiteNames);

        long startTime = System.currentTimeMillis();
        Solver sol = null;
        Solver best;
        double result = Double.POSITIVE_INFINITY;

        while (System.currentTimeMillis() - startTime < time) {
            hN = new pNetwork(problem.host, problem.hostRanks, problem.hostNames, problem.regionCosts, problem.hostRegions);
            hN.initializeCounters();
            pN.initializeCounters();
            randomizeTimes(hN);
            sol = new Solver(hN, pN, problem.phi, costs, -1);
            sol.solve();
            if (sol.cost < result) {
                result = sol.cost;
                best = new Solver(sol);
                System.out.println("New best solution of cost " + result + " at time " + (System.currentTimeMillis() - startTime) / 1000);
                //System.err.println(hN);
            } else {
                System.out.println("Solution of cost " + sol.cost + " at time " + (System.currentTimeMillis() - startTime) / 1000);
                //System.err.println(hN);
            }
        }
        System.err.println(sol.optSol);
        return result;
    }


    /* This is the heuristic Jane actually uses. It is a genetic algorithm which
     * creates a random population of a given size and completely replaces
     * the population every generation by crossing over individuals until
     * a new population of the same size is created.
     */
    static Vector<pNetwork> genetic(TreeFileReader.ProblemInstance prob,
            int[] costs, int numIter, int popSize, double m, double selectStr,
            boolean tarzan, int switchDist) throws NoValidSolutionException, InconsistentTreeException, TreeFormatException, Exception {
        checkTipConsistency(prob);

        Vector<Solver> pop = new Vector<Solver>(popSize);
        Vector<Solver> newPop = new Vector<Solver>(popSize);
        Vector<Thread> solveThreads = new Vector<Thread>();
        Solver x = null;
        Solver y = null;
        pNetwork childNet = null;
        pNetwork temp;
        pNetwork pN = new pNetwork(prob.parasite, prob.parasiteRanks, prob.parasiteNames);
        double result = Double.POSITIVE_INFINITY;
        pN.initializeCounters();
        Solver bestSolver = null;
        Solver thisSolver = null;
        double avg = 0;
        double nextAvg = 0;
        double thisBest = Double.POSITIVE_INFINITY;
        int thisCount = 0;
        int uniqueCount = 0; // for unique timings
        int infCount = 0;
        Vector<Vector<Association>> bestAssocs = new Vector<Vector<Association>>();
        Vector<Vector<Association>> bestRootAssocs = new Vector<Vector<Association>>();
        Vector<Solver.Solution> resultSolutions = new Vector<Solver.Solution>();
        Vector<pNetwork> bestUnique = new Vector<pNetwork>();
        Solver.TARZAN = tarzan;
        boolean foundNew;

        // seeds initial population
        for (int i = 0; i < popSize; i++) {
            temp = new pNetwork(prob.host, prob.hostRanks, prob.hostNames, prob.regionCosts, prob.hostRegions);
            temp.initializeCounters();
            randomizeTimes(temp);
            //randomizeHostTimes(temp);
            pN.initializeCounters();
            x = new Solver(temp, pN, prob.phi, costs, switchDist);
            x.setGenetic();
            pop.add(x);
        }

        // solves the initial population
        runThreads(pop, solveThreads);

        // gathers information about the initial population
        for (Solver z : pop) {
            if (z.cost < result) {
                bestSolver = new Solver(z);
                result = z.cost;
                resultSolutions = new Vector<Solver.Solution>();
                bestRootAssocs = new Vector<Vector<Association>>();
                bestUnique = new Vector<pNetwork>();
            }

            if (z.cost == result) {
                foundNew = true;
                for (pNetwork h : bestUnique) {
                    if (z.hostNetwork.equals(h)) {
                        foundNew = false;
                        break;
                    }
                }
                if (foundNew) {
                    bestUnique.add(z.hostNetwork);
                }

                for (Vector<Association> goodAssoc : z.bestRoots) {
                    if (findNew(bestRootAssocs, goodAssoc)) {
                        bestRootAssocs.add(goodAssoc);
                        resultSolutions.add(new Solver.Solution(goodAssoc.get(0), z.hostNetwork));
                    }
                }
            }

            if (z.cost == thisBest) {
                if (findNew(bestAssocs, z.bestAssocs)) {
                    uniqueCount++;
                    bestAssocs.add(z.bestAssocs);
                }
                thisCount++;
            }
            if (z.cost < thisBest) {
                thisBest = z.cost;
                thisCount = 1;
                uniqueCount = 1;
                bestAssocs.add(z.bestAssocs);
            }
            if (z.cost < pNetwork.INFINITY) {
                avg += z.cost;
            } else {
                infCount++;
            }
        }

        if (result >= pNetwork.INFINITY) {
            throw new NoValidSolutionException("Initial population - Only infinite cost solutions found!");
        }

        avg = avg / (popSize - infCount);
        if (Jane.verbose) {
            System.out.println("\nInitial Cost: " + result + "\nInitial Configuration:" + bestSolver.hostNetwork + "\nSolution:\n" + bestSolver.optSol);
        }
        System.err.println("Best Initial Cost " + result + "\tWith " + thisCount + " instances at " + uniqueCount + " individuals");
        Vector<String> unique;

        int uniqueCount2; // for unique solutions
        for (int i = 0; i < numIter; i++) {
            newPop = new Vector<Solver>(popSize);
            unique = new Vector<String>();
            bestAssocs = new Vector<Vector<Association>>();
            uniqueCount = 0;
            uniqueCount2 = 0;
            thisBest = Double.POSITIVE_INFINITY;
            thisCount = 1;
            nextAvg = 0;
            int nextInfCount = 0;

            // generate new population
            genNew(x, y, pop, newPop, avg, selectStr, pN, childNet, prob.phi, costs,
                    m, popSize, switchDist, infCount);

            runThreads(newPop, solveThreads);

            for (Solver childSolve : newPop) {
                if (childSolve.cost == thisBest) {
                    // this checks for timing uniqueness
                    foundNew = true;
                    for (String s : unique) {
                        if (childSolve.hostNetwork.toString().equals(s)) {
                            foundNew = false;
                            break;
                        }
                    }
                    if (foundNew) {
                        uniqueCount++;
                        unique.add(childSolve.hostNetwork.toString());
                    }


                    // this checks for speciation uniqueness (unique solutions)
                    if (findNew(bestAssocs, childSolve.bestAssocs)) {
                        uniqueCount2++;
                        bestAssocs.add(childSolve.bestAssocs);
                    }
                    thisCount++;
                }
                if (childSolve.cost < thisBest) {
                    thisSolver = new Solver(childSolve);
                    thisBest = childSolve.cost;
                    thisCount = 1;
                    uniqueCount = 1;
                    uniqueCount2 = 1;
                    unique = new Vector<String>();
                    unique.add(childSolve.hostNetwork.toString());
                    bestAssocs.add(childSolve.bestAssocs);
                }

                if (childSolve.cost < pNetwork.INFINITY) {
                    nextAvg += childSolve.cost;
                } else {
                    nextInfCount++;
                }



                // This finds solver instances of best cost with unique solutions
                // note that it only checks the first solution found in the DP table
                // of the solver. The actual set of solutions of two individuals which appear
                // identical under this measure might actually be different.
                if (childSolve.cost < result) {
                    bestSolver = new Solver(childSolve);
                    result = childSolve.cost;
                    resultSolutions = new Vector<Solver.Solution>();
                    bestRootAssocs = new Vector<Vector<Association>>();
                    bestUnique = new Vector<pNetwork>();
                }

                if (childSolve.cost == result) {
                    if (bestUnique.size() < 20) {
                        foundNew = true;
                        for (pNetwork h : bestUnique) {
                            if (childSolve.hostNetwork.equals(h)) {
                                foundNew = false;
                                break;
                            }
                        }
                        if (foundNew) {
                            bestUnique.add(childSolve.hostNetwork);
                        }
                    }
                    for (Vector<Association> goodAssoc : childSolve.bestRoots) {
                        if (findNew(bestRootAssocs, goodAssoc)) {
                            bestRootAssocs.add(goodAssoc);
                            resultSolutions.add(new Solver.Solution(goodAssoc.get(0), childSolve.hostNetwork));
                        }
                    }
                }


            }
            if (thisBest >= pNetwork.INFINITY) {
                throw new NoValidSolutionException("Iteration: " + i + " - Only infinite cost solutions found!");
            }

            infCount = nextInfCount;

            avg = nextAvg / (popSize - infCount);
            pop = new Vector<Solver>(newPop);

            System.out.println("Unique Timings " + uniqueCount + " and " + bestUnique.size() + " total unique timings found at best cost");
            System.err.println("Iteration " + i + " best " + thisBest + "\tWith " + thisCount + " instances at " + uniqueCount2 + " unique individuals and " + resultSolutions.size() + " unique best cost solutions");
        }
        if (Jane.verbose) {
            System.out.println("\nFinal Population Best Cost: " + thisBest + "\nFinal Population Best Configuration: " + thisSolver.hostNetwork + "\nSolution: " + thisSolver.optSol);
            System.out.println("Final Population Best Cost: " + thisBest);
        }

        System.out.println("\nBest Cost: " + result + "\nSolution: " + bestSolver.optSol);

        bestSolver.bestAssoc.countEvents(bestSolver.hostNetwork);
        System.out.println("Cospeciation:" + bestSolver.bestAssoc.eventCounts[Solver.COSPECIATION]);
        System.out.println("Duplication:" + bestSolver.bestAssoc.eventCounts[Solver.DUPLICATION]);
        System.out.println("Host Switch:" + bestSolver.bestAssoc.eventCounts[Solver.SWITCH]);
        System.out.println("Loss:" + bestSolver.bestAssoc.eventCounts[Solver.LOSS]);

        return bestUnique;
    }

    // generates the new population
    static void genNew(Solver x, Solver y, Vector<Solver> pop, Vector<Solver> newPop,
            double avg, double selectStr, pNetwork pN, pNetwork childNet,
            Map<Integer, Integer> phi, int[] costs, double m,
            int popSize, int switchDist, int infCount) throws InconsistentTreeException, Exception {
        for (int j = 0; j < popSize; j++) {
            x = randSelect(pop, avg, selectStr, infCount);
            y = randSelect(pop, avg, selectStr, infCount);
            childNet = reproduce(x, y);
            if (Jane.rand.nextDouble() < m) {
                mutate(childNet);
            }
            pN.initializeCounters();
            Solver childSolve = new Solver(childNet, pN, phi, costs, switchDist);
            childSolve.setGenetic();
            newPop.add(childSolve);
        }
    }

    // checks for speciation uniqueness
    static boolean findNew(Vector<Vector<Association>> bestAssocs, Vector<Association> childSolveAssoc) {
        for (Vector<Association> va : bestAssocs) {
            boolean isThisNew = false;
            for (int k = 0; k < va.size(); k++) {
                if (va.get(k).isDistinct(childSolveAssoc.get(k))) {
                    isThisNew = true;
                    break;
                }
            }
            if (!isThisNew) {
                return false;
            }
        }
        return true;
    }

    // threads the task of solving a population
    static void runThreads(Vector<Solver> pop, Vector<Thread> solveThreads) {
        for (Solver s : pop) {
            Thread t = new Thread(s);
            t.start();
            solveThreads.add(t);
        }

        for (Iterator<Thread> t = solveThreads.iterator(); t.hasNext();) {
            try {
                t.next().join();
            } catch (Exception e) {
                System.out.println(e);
            }
            t.remove();
        }
    }

    // randomly selects two individuals out of a population
    static Solver randSelect(Vector<Solver> pop, double avg, double selectStr, int infCount) throws Exception{
        double weights[] = new double[pop.size() - infCount];
        double total = 0;
        double choice = Jane.rand.nextDouble();

        // total cost across all solved networks
        for (int i = 0; i < pop.size(); i++) {
            if (pop.get(i).cost < pNetwork.INFINITY) {
                total += Math.exp(selectStr * (avg - pop.get(i).cost));
            }
        }
        // creates a series of intervals from [0, 1] for solvers
        // to be chosen from
        int i = 0;
        do {

            weights[0] = (Math.exp(selectStr * (avg - pop.get(i).cost))) / total;
        } while (pop.get(i++).cost >= pNetwork.INFINITY);
        i = 1;
        int j = 1;
        while (j < pop.size() - infCount) {
            weights[j] = (Math.exp(selectStr * (avg - pop.get(i).cost))) / total + weights[j - 1];
            if (pop.get(i).cost < pNetwork.INFINITY) {
                j++;
            }
            i++;
        }

        for (int k = 0; k < pop.size() - infCount; k++) {
            if (choice < weights[k]) {
                return pop.get(k);
            }
        }
        // this really should never happen. seriously.
        throw new Exception("Sorry guys, somehow randSelect wasnt able to select");
    }

    // this is the crossover method. it takes two individuals and creates a valid
    // new one by combining attributes of each. the algorithm is described in more
    // detail in our paper. this implementation follows it fairly closely
    static pNetwork reproduce(Solver x, Solver y) throws InconsistentTreeException {
        int finalTime = x.hostNetwork.tips().get(0).time;
        int cross = Jane.rand.nextInt(finalTime - 1) + 1;
        node newNode = null;
        int tempTime;
        pNetwork result = new pNetwork(y.hostNetwork);
        boolean foundParent = false;
        Vector<node> nodeList = new Vector<node>();
        Vector<node> nodeList2 = new Vector<node>();
        Vector<node> nodeToProcess = new Vector<node>();
        Vector<Integer> nodeTimes = new Vector<Integer>();
        Vector<Integer> nodeTimes2 = new Vector<Integer>();
        nodeList.add(x.hostNetwork.nodeAtTime(cross));
        nodeToProcess.addAll(x.hostNetwork.children(x.hostNetwork.nodeAtTime(cross).name));
        while (!nodeToProcess.isEmpty()) {
            tempTime = finalTime;
            for (node tempNode : nodeToProcess) {
                if (tempNode.time <= tempTime) {
                    tempTime = tempNode.time;
                    newNode = tempNode;
                }
            }
            if (newNode.Tip()) {
                break;
            }
            nodeList.add(newNode);
            nodeToProcess.remove(newNode);
            nodeToProcess.addAll(x.hostNetwork.children(newNode.name));
        }
        nodeList2.add(y.hostNetwork.root());
        nodeToProcess.addAll(y.hostNetwork.children(y.hostNetwork.root().name));
        int count = 0;
        while (!nodeToProcess.isEmpty()) {
            tempTime = finalTime;
            for (node tempNode : nodeToProcess) {
                if (tempNode.time <= tempTime && tempNode.name != nodeList.get(0).name) {
                    tempTime = tempNode.time;
                    newNode = tempNode;
                }
            }
            if (newNode.Tip()) {
                break;
            }
            count++;
            nodeList2.add(newNode);
            nodeToProcess.remove(newNode);
            nodeToProcess.addAll(y.hostNetwork.children(newNode.name));
        }
        int index1 = 0;
        int index2 = 0;
        Vector<node> parentList;
        while (!foundParent) {
            parentList = result.children(nodeList2.get(index2).name);
            for (node n : parentList) {
                if (n.name == nodeList.get(0).name) {
                    foundParent = true;
                }
            }
            index2++;
        }
        for (int i = index2; i < finalTime; i++) {
            if (index1 < nodeList.size()) {
                if (index2 < nodeList2.size()) {
                    if (nodeList.get(index1).timeZones.lastElement() < nodeList2.get(index2).timeZones.firstElement()) {
                        result.nodes.get(nodeList.get(index1).name).time = i;
                        index1++;
                    } else if (nodeList.get(index1).timeZones.firstElement() > nodeList2.get(index2).timeZones.lastElement()) {
                        result.nodes.get(nodeList2.get(index2).name).time = i;
                        index2++;
                    } else if (Math.abs(nodeList.get(index1).time - i) < Math.abs(nodeList2.get(index2).time - i)) {
                        result.nodes.get(nodeList.get(index1).name).time = i;
                        index1++;
                    } else if (Math.abs(nodeList.get(index1).time - i) > Math.abs(nodeList2.get(index2).time - i)) {
                        result.nodes.get(nodeList2.get(index2).name).time = i;
                        index2++;
                    } else if (Jane.rand.nextDouble() < 0.5) {
                        result.nodes.get(nodeList.get(index1).name).time = i;
                        index1++;
                    } else {
                        result.nodes.get(nodeList2.get(index2).name).time = i;
                        index2++;
                    }
                } else {
                    result.nodes.get(nodeList.get(index1).name).time = i;
                    index1++;
                }
            } else if (index2 < nodeList2.size()) {
                result.nodes.get(nodeList2.get(index2).name).time = i;
                index2++;
            } else {
                System.out.println("CRAP!");
            }
        }


        // just in case someone doesnt give continuous time zones (i.e. 1, 2, 5)
        Iterator<Integer> it = result.zoneList.keySet().iterator();
        int currentZone = it.next();
        for (int i = 0; i <= finalTime; i++) {
            while (result.nodeAtTime(i).timeZones.firstElement() > currentZone) {
                result.zoneTimes.put(currentZone, i - 1);
                currentZone = it.next();
            }
            result.nodeAtTime(i).zone = currentZone;
        }
        result.zoneTimes.put(currentZone, finalTime);
        while (it.hasNext()) {
            result.zoneTimes.put(it.next(), finalTime);
        }

        if (!result.checkConsistency()) {
            throw new InconsistentTreeException("Genetic somehow created a timing inconsistent with time zones");
        }
        return result;
    }

    // this simply twiddles the timing of two nodes at adjacent times in a way
    // that doesnt violate time zones or parent-child relationships.
    static void mutate(pNetwork child) {
        int maxInterior = child.tips().size() - 1;
        boolean done = false;
        int index = 0;
        int count = 0;
        // its possible for there to be trees of arbitrary size which
        // have only one possible timing and so cannot mutate
        // so only try 100 times and then stop
        while (!done && count < 100) {
            count++;
            int candidateTime = (Jane.rand.nextInt(maxInterior - 1)) + 2;
            node node1 = child.nodeAtTime(candidateTime);
            node node2 = child.nodeAtTime(candidateTime - 1);
            if (child.descendant(node1, node2) || child.descendant(node2, node1)) {
                continue;
            }
            if (node1.timeZones.lastElement() <= node2.timeZones.firstElement()) {
                child.nodes.get(node1.name).time = candidateTime - 1;
                child.nodes.get(node2.name).time = candidateTime;
                int temp = node1.zone;
                node1.zone = node2.zone;
                node2.zone = temp;
                child.initializeCounters();
                done = true;
            }
        }
    }

    // this makes sure that parasite nodes actually can be mapped to their corresponding
    // nodes in the host tree without violating time zone information.
    private static void checkTipConsistency(TreeFileReader.ProblemInstance prob) throws TreeFormatException {
        pNetwork tHost = new pNetwork(prob.host, prob.hostRanks, prob.hostNames);
        pNetwork tPar = new pNetwork(prob.parasite, prob.parasiteRanks, prob.parasiteNames);
        for (Integer i : prob.phi.keySet()) {
            if (tPar.nodes.get(i).timeZones.firstElement() > tHost.nodes.get(prob.phi.get(i)).timeZones.lastElement() ||
                    tPar.nodes.get(i).timeZones.lastElement() < tHost.nodes.get(prob.phi.get(i)).timeZones.firstElement()) {
                throw new TreeFormatException("Tip mapping of Parasite Node " + tPar.nodes.get(i).fancyName + " onto Host Node " +
                        tHost.nodes.get(prob.phi.get(i)).fancyName + " is impossible due to disjoint time zone information");
            }
        }
    }

    // exception for when the entire popluation ends up having infinite cost which
    // means that there arent any valid solutions
    public static class NoValidSolutionException extends Exception {

        public NoValidSolutionException() {}

        public NoValidSolutionException(String s) {
            super(s);
        }
    }

    // this exception should NEVER be thrown. it can only occur if somehow
    // we assign a timing that is inconsistent with time zones. errors in files
    // which might cause something like this should be caught before this exception
    // is thrown
    public static class InconsistentTreeException extends Exception {

        public InconsistentTreeException() {
        }

        public InconsistentTreeException(String s) {
            super(s);
        }
    }

    // this exception gets thrown when the file format is correct, but the
    // information inside of it implies something impossible. i.e. a node being
    // forced to have a time zone that is earlier than its parent's
    public static class TreeFormatException extends Exception {

        public TreeFormatException() {
        }

        public TreeFormatException(String s) {
            super(s);
        }
    }
}
