/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of the Harvey Mudd College nor the names of its
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


import java.util.*;
class Breeder
{
	// Return codes for DFS-Destroy to indicate what still needs to be done
	static final int KILLCYCLE = 2;
	static final int CYCLEKILLED = 1;
	static final int NOCYCLE = 0;
	
	// Types of edge, real indicates a parasite ancestor relationship, implied indicates
	// a host switch in one of the solutions.
	static final int REAL = 1;
	static final int IMPLIED = 2;
	
	// States for a particular vertex during DFS
	static final int NOT_VISITED = 0;
	static final int ACTIVE = 1;
	static final int INACTIVE = 2;
	
	//Map from names of nodes to their children or parents
	static Map<Integer, Set<timingedge> > children;
	static Map<Integer, Set<timingedge> > parents;
	static Map<Integer, Integer> visited;
	
	// Takes an association and a host network and creates a timing
	// for the host network such that the association can map onto
	// the host network
	static pNetwork applyAssociation(Association a1, pNetwork network)
	{
		int root = network.root().name;
		visited = new HashMap<Integer, Integer>();
		children = new HashMap<Integer, Set<timingedge> >();
		parents = new HashMap<Integer, Set<timingedge> >();
		
		//Initialize the parents and children
		for(Integer node:network.adjacencyList.keySet())
		{
			children.put(node, new HashSet<timingedge>());
			parents.put(node, new HashSet<timingedge>());
			visited.put(node, NOT_VISITED);
		}
		
		//Insert the real edges
		for(Map.Entry<Integer, Vector<Integer> > me : network.adjacencyList.entrySet())
		{
			for(Integer child : me.getValue())
			{
				addEdge(me.getKey(), child, REAL);
			}
		}
		
		//Insert the implied edges
		associationMerge(a1, new LinkedList<treeLocation>());

		//create a new host network to take the timing information
		pNetwork newHost = new pNetwork(network);
		node nroot = newHost.root();
		nroot.time = 0;
		
		//Keep a list of nodes for which all their parents have been assigned times
		Vector<node> readyList = nroot.children;
		int tipTime = newHost.tips().size();
		int time = 1;


		network.initializeCounters();
		Set<Integer> zList = network.zoneList.keySet();
		tipTime = network.tips().size();
		node root1 = network.root();
		root = root1.name;
		root1.time = 0;
		root1.assigned = true;
		root1.zone = zList.iterator().next();
		time = 1;
		Iterator<Integer> it = zList.iterator();
		if(dfsDestroy(root) != NOCYCLE)
		{
		    System.out.println("The tarzan solution contains a timing incompatability.");
		    System.exit(0);
		}
		while(it.hasNext()){
			int curZone = it.next();
			Vector<Integer> zVector = new Vector<Integer>(network.zoneList.get(curZone));
			
			Vector<Integer> remaining = new Vector<Integer>();
			while(!zVector.isEmpty()){
				int randIndex = Jane.rand.nextInt(zVector.size());
				node temp = network.nodes.get(zVector.get(randIndex));
				zVector.removeElementAt(randIndex);
				// may want to support reticulation
				boolean parentsAssigned = true;
				for(timingedge te : parents.get(temp.name)){
					if(!network.nodes.get(te.node).assigned)
						parentsAssigned = false;
				}
				if(parentsAssigned){
					double d = Jane.rand.nextDouble();
					if(d < temp.timeZones.size() && !temp.assigned && !temp.Tip()){
						temp.assigned = true;
						temp.time = time;
						temp.zone = curZone;
						time++;
					}
					else if(temp.Tip() && !temp.assigned){
						if(temp.timeZones.lastElement() != network.finalZone){
							System.err.println("Tip " + temp.name + " was not assigned to the final time zone!");
							System.exit(1);
						}
						temp.assigned = true;
						temp.time = tipTime;
						temp.zone = network.finalZone;
					}
				}
				else{
					remaining.add(temp.name);
				}
				if(zVector.isEmpty()){
					zVector = new Vector<Integer>(remaining);
					remaining = new Vector<Integer>();
				}
			}
			network.zoneTimes.put(curZone, time);
		}
		
		return network;		
	}
	
	// Takes a location in the host tree with additional implied edges and
	// does DFS to detect cycles. Once it detects a cycle, it returns through
	// the recursion with a code of KILLCYCLE until it finds a false edge in the
	// cycle (there will always be one, since the original host was acyclic).
	// Then, it returns out with CYCLEKILLED
	static int dfsDestroy(int location)
	{
		if(visited.get(location) == ACTIVE)
		{
			return KILLCYCLE;
		}
		if(visited.get(location) == INACTIVE)
		{
			return NOCYCLE;
		}
		visited.put(location, ACTIVE);

		Vector<timingedge> vt = new Vector<timingedge>(children.get(location));
		Collections.shuffle(vt);
		for(timingedge child: vt)
		{
			int retvalue = dfsDestroy(child.node);
			if(retvalue == KILLCYCLE)
			{
			    System.out.println("(" + location + ", " + child.node + ") " + child.type);
				if(child.type == IMPLIED)
				{
				    children.get(location).remove(child);
				    parents.remove(new timingedge(location, 2));
				    return CYCLEKILLED;
				}
				else
				{
					return KILLCYCLE;
				}
			}
			else if(retvalue == CYCLEKILLED)
			{
				System.out.println("(" + location + ", " + child.node + ") " + child.type);
				return CYCLEKILLED;
			}
		}
		visited.put(location, INACTIVE);
		return NOCYCLE;
	}
	
	static void addEdge(int start, int end, int type)
	{
		children.get(start).add(new timingedge(end, type));
		parents.get(end).add(new timingedge(start, type));
	}
	
	//Adds implied edges for host switches in the association
	static void associationMerge(Association assoc , LinkedList<treeLocation> previousEdges)
	{
		if(assoc == null)
			return;
		
		if(Association.AssociationType.HOST_SWITCH.equals(assoc.type))
		{
			treeLocation start = assoc.associate;
			treeLocation end = assoc.switchTarget;
			
			if(! (start instanceof edge && end instanceof edge))
				System.out.println("OK, I will do this the hard way");
			
			if(start instanceof edge)
			{
				if(end instanceof edge)
				{
					addEdge(((edge)start).first.name, ((edge)end).second.name, IMPLIED);
					addEdge(((edge)end).first.name,((edge)start).second.name, IMPLIED);
				}
				else
				{
					addEdge(((edge)start).first.name,((node)end).name, IMPLIED);
					addEdge(((node)end).name, ((edge)start).second.name, IMPLIED);
				}
			}
			else
			{
				if(end instanceof edge)
				{
					addEdge(((edge)end).first.name, ((node)start).name, IMPLIED);
					addEdge(((node)start).name, ((edge)end).second.name, IMPLIED);
				}
				else
				{
					addEdge(((node)start).name, ((node)end).name, IMPLIED);
				}
			}
			
			if(previousEdges.size() > 0 && previousEdges.getFirst().equals(start))
			{
				int target = ((edge)end).second.name;
				Iterator<treeLocation> edges = previousEdges.iterator();
				edges.next();
				while(edges.hasNext())
				{
					treeLocation t = edges.next();
					addEdge(((edge)t).first.name, target, IMPLIED);
				}
				previousEdges.addFirst(end);

			}
			else
			{
				previousEdges.clear();
				previousEdges.addFirst(start);
				previousEdges.addFirst(end);
			}
			
		}
		associationMerge(assoc.AChild1, new LinkedList<treeLocation>(previousEdges));
		associationMerge(assoc.AChild2, new LinkedList<treeLocation>(previousEdges));
	}
}
//A class to store an adjacency and whether that adjacency is caused by lineage or host switching.
class timingedge
{
	int type;
	int node;
	public timingedge(int n, int t)
	{
		type = t;
		node = n;
	}
	public boolean equals(Object other)
	{
		if(other instanceof timingedge)
			return ((timingedge)other).equals(this);
		else
			return false;
	}
	public boolean equals(timingedge other)
	{
		return node == other.node;
	}
    public int hashCode()
    {
	return node;
    }
}
