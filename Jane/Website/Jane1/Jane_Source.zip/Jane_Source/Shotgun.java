/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of the Harvey Mudd College nor the names of its
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


import java.io.IOException;



public class Shotgun
{
	static int costs[] = {0,1,1,2};
	static long time = 300000;
	static boolean verbose;
	static String filename;
	static int batchSize = 8;

	static void usage()
	{
		System.err.println("usage: java Shotgun [-V] [-c {Cospeciation,Duplication,Switch,Loss}] [-t minutes_to_run] file");
		System.exit(1);
	}

	static void readArgs(String[] args)
	{
		int index = 0;

		while(index < args.length)
		{
			if("-c".equals(args[index]))
			{
				index ++;
				costs = new int[4];
				for(int i = 0; i <4; ++i)
				{
					try{
						costs[i] = Integer.parseInt(args[index]);
					}
					catch(NumberFormatException e)
					{
						System.err.println("The -c flag must be followed with 4 integers representing the costs of various operations.");
						usage();
					}
					index++;
				}
			}
			else if("-t".equals(args[index]))
			{
				index ++;
				try{
					double t = Double.parseDouble(args[index]);
					time = (long)(t * 60 * 1000);
				}
				catch(NumberFormatException e)
				{
					System.err.println("The argument following -t must be a number");
					usage();
				}
				index++;
			}
			else if("-V".equals(args[index]))
			{
				index++;
				verbose = true;
			}
			else if(args[index].startsWith("-"))
			{
				System.err.println("Unrecognized command-line switch: " + args[index]);
				usage();
			}
			else
				break;
		}

		if(index == args.length-1)
			filename = args[index];
		else if(index >= args.length)
		{
			System.err.println("No filename provided");
			usage();
		}
		else
		{
			System.err.println("Unexpected arguments after the filename");
			usage();
		}
		return;
	}

	public static void main(String[] args) throws FileFormatException, heuristics.InconsistentTreeException, java.io.IOException, heuristics.TreeFormatException
	{
			readArgs(args);

			TreeFileReader fin = null;
			try{
				fin = new TarzanFileReader(filename);
			}
			catch(java.io.FileNotFoundException e)
			{
				System.err.println("Could not find file: " + filename);
				System.exit(1);
			}

			TreeFileReader.ProblemInstance pi = fin.readProblem();

			System.out.println(filename);
			System.out.println("Cospeciation:" + costs[0]);
			System.out.println("Duplication:" + costs[1]);
			System.out.println("Host Switch:" + costs[2]);
			System.out.println("Loss:" + costs[3]);

			heuristics.shotgun(pi, costs, time);
	}
}
