/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of the Harvey Mudd College nor the names of its
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


import java.util.*;

class Solver implements Runnable {

    static int solvesDone = 0;
    pNetwork hostNetwork;
    pNetwork parasiteTree;
    static Map<Integer, Integer> phi;
    static int[] costs;
    double cost;
    String optSol;
    Association bestAssoc;
    Vector<Association> bestAssocs = new Vector<Association>();
    Vector<Vector<Association>> bestRoots = new Vector<Vector<Association>>();
    Map<Integer, Vector<Association>> dpTable = new HashMap<Integer, Vector<Association>>();
    final static boolean VERBOSE = false;
    final static int COSPECIATION = 0;
    final static int DUPLICATION = 1;
    final static int SWITCH = 2;
    final static int LOSS = 3;
    static boolean TARZAN = false;
    boolean isGenetic = false;
    int switchDist;

    public Solver(pNetwork hN, pNetwork pT, Map<Integer, Integer> p, int[] c, int sd) {
        hostNetwork = new pNetwork(hN);
        parasiteTree = new pNetwork(pT);
        hostNetwork.initializeCounters();
        parasiteTree.initializeCounters();
        phi = p;
        costs = c;
        switchDist = sd;
        for (Integer name : pT.nodes.keySet()) {
            dpTable.put(name, new Vector<Association>());
        }
    }

    public Solver(Solver s) {
        hostNetwork = new pNetwork(s.hostNetwork);
        parasiteTree = new pNetwork(s.parasiteTree);
        cost = s.cost;
        optSol = s.optSol;
        bestAssoc = s.bestAssoc;
        bestRoots = new Vector<Vector<Association>>(s.bestRoots);
        switchDist = s.switchDist;
    }

    public void run() {
        solve();
        solvesDone++;
    }

    public double solve() {
        /*Invokes the dynamic program on the hostNetwork, parasiteTree,
        and costs and returns the cost of the optimal solution
         */

        // this is stuff we need to declare which wasnt in the python version because
        // java is cool like this.
        int time = 0;
        int hostLeafName = 0;
        node currentParasiteNode;

        if (VERBOSE) {
            System.out.println("Entring Solve");
        }
        // First find the list of leaves in the parasite tree
        Vector<node> parasiteLeafList = parasiteTree.tips();
        // queue of names of internal nodes in parasite tree
        Queue<node> parasiteQueue = new LinkedList<node>();

        // initialize DP table for leaves of parasite tree

        for (node parasiteLeaf : parasiteLeafList) {
            int parasiteLeafName = parasiteLeaf.name;
            // First find host tip associated with parasite leaf
            hostLeafName = phi.get(parasiteLeafName);
            // The cost of this association is 0,
            // the time of this association is the time of the
            // hostnode and the associations of the children of
            // leaf are null since the leaf has no children.
            time = hostNetwork.nodes.get(hostLeafName).time;
            dpTable.get(parasiteLeafName).add(new Association(Association.AssociationType.TIP, parasiteLeaf, hostNetwork.nodes.get(hostLeafName), time, 0, null, null));
            // increment parent counter to indicate that one child is done

            for (node parentNode : parasiteTree.nodes.get(parasiteLeafName).parents) {
                parentNode.counter++;
                if (parentNode.counter == 2) {
                    parasiteQueue.offer(parentNode);
                }
            }
        }
        // Begin main loop to process all nodes in parasiteQueue
        // The number of internal nodes to process is the floor of
        // 1/2 of the total size of the tree. Floor is implicit
        // here because of integer division
        int nodesToProcess = parasiteTree.size / 2;
        int count = 0;
        while (parasiteQueue.peek() != null) {
            if (VERBOSE) {
                System.out.println("Parasite nodes remaining to process: " + nodesToProcess);
            }
            currentParasiteNode = parasiteQueue.remove();
            nodesToProcess--;
            if (VERBOSE) {
                System.out.println("Processing parasite: " + currentParasiteNode);
            }
            processParasite(currentParasiteNode);

            if (!currentParasiteNode.Root()) {
                node parentNode = currentParasiteNode.parents.get(0);
                parentNode.counter++;
                if (parentNode.counter == 2) {
                    parasiteQueue.offer(parentNode);
                }
            } else {
                bestAssoc = bestAssociation(currentParasiteNode);
                bestRootAssociations(currentParasiteNode);

                // this instance cannot be solved?
                if (bestAssoc == null) {
                    cost = pNetwork.INFINITY;
                    return cost;
                }

                cost = bestAssoc.cost;
                optSol = printOptimal();
                
                if (isGenetic) {
                    dpTable = null;
                }
                return cost;
            }
        }
        System.out.println("sad face :(");
        return -1;
    }

    void setGenetic() {
        isGenetic = true;
    }

    void processParasite(node parasiteNode) {
        /* Takes a parasite node name and computes the DP table
        for that node
         */
        node child1 = parasiteNode.children.get(0);
        node child2 = parasiteNode.children.get(1);
        edge hostEdge;
        // find association lists for parasites' children
        Vector<Association> child1Assoc = dpTable.get(child1.name);
        Vector<Association> child2Assoc = dpTable.get(child2.name);

        for (node host : hostNetwork.nodes.values()) {
            if (parasiteNode.cotemp(host)) {
                if (!host.Tip() && host.outDegree == 2) {
                    cospeciation(parasiteNode, child1Assoc, child2Assoc, host);
                }
            }
            for (node hostChild : host.children) {
                hostEdge = new edge(host, hostChild);
                if (parasiteNode.cotemp(hostEdge)) {
                    duplication(parasiteNode, child1Assoc, child2Assoc, hostEdge);
                    hostSwitch(parasiteNode, child1Assoc, child2Assoc, hostEdge);
                }
            }
        }
    }

    void cospeciation(node parasiteNode, Vector<Association> child1Assoc, Vector<Association> child2Assoc, node hostNode) {

        // Recall that cospeciation is only considered when the
        // host node was exactly two children
        node hostChild1 = hostNode.children.get(0);
        node hostChild2 = hostNode.children.get(1);
        Vector<Association> p1candidates = new Vector<Association>();
        Vector<Association> p2candidates = new Vector<Association>();
        int cost = 0;
        Association assocA1 = null;
        Association assocA2 = null;
        Association assocB1 = null;
        Association assocB2 = null;
        Association optimalAssoc1;
        Association optimalAssoc2;
        int costA = 0;
        int costB = 0;
        int optimalCost = 0;
        // Option A: the parasite's first child, child1, is on a
        // descendant of edge (hostName, hostChild1) and its second
        // child is on a descendant of edge (hostName, hostChild2)
        for (Association assoc : child1Assoc) {
            if (hostNetwork.descendant(new edge(hostNode, hostChild1), assoc.associate)) {
                p1candidates.add(assoc);
            }
        }
        for (Association assoc : child2Assoc) {
            if (hostNetwork.descendant(new edge(hostNode, hostChild2), assoc.associate)) {
                p2candidates.add(assoc);
            }
        }
        // if neither list is empty, take the best from each
        costA = pNetwork.INFINITY;
        for (Association assoc1 : p1candidates) {
            for (Association assoc2 : p2candidates) {
                if (TARZAN) {
                    cost = costs[COSPECIATION];
                } else {
                    cost = 2 * costs[COSPECIATION];
                }

                cost += assoc1.cost + assoc2.cost +
                        (hostNetwork.distance(new edge(hostNode, hostChild1), assoc1.associate) +
                        hostNetwork.distance(new edge(hostNode, hostChild2), assoc2.associate)) * costs[LOSS];

                if (cost < costA) {
                    costA = cost;
                    assocA1 = assoc1;
                    assocA2 = assoc2;
                }
            }
        }
        // Option B: the parasite's first child, child1, is on a decendent of
        // edge (hostName, hostChild2) and its second child is on a decendent
        // of edge (hostName, hostChild1)


        for (Association assoc : child1Assoc) {
            if (hostNetwork.descendant(new edge(hostNode, hostChild2), assoc.associate)) {
                p1candidates.add(assoc);
            }
        }
        for (Association assoc : child2Assoc) {
            if (hostNetwork.descendant(new edge(hostNode, hostChild1), assoc.associate)) {
                p2candidates.add(assoc);
            }
        }


        costB = pNetwork.INFINITY;
        for (Association assoc1 : p1candidates) {
            for (Association assoc2 : p2candidates) {
                if (TARZAN) {
                    cost = costs[COSPECIATION];
                } else {
                    cost = 2 * costs[COSPECIATION];
                }

                cost += assoc1.cost + assoc2.cost +
                        (hostNetwork.distance(new edge(hostNode, hostChild2), assoc1.associate) +
                        hostNetwork.distance(new edge(hostNode, hostChild1), assoc2.associate)) * costs[LOSS];
                if (cost < costB) {
                    costB = cost;
                    assocB1 = assoc1;
                    assocB2 = assoc2;
                }
            }
        }

        if (costA >= pNetwork.INFINITY && costB >= pNetwork.INFINITY) {
            return;
        }

        if (costA <= costB) {
            dpTable.get(parasiteNode.name).add(new Association(Association.AssociationType.COSPECIATION, parasiteNode, hostNode, hostNode.time, costA, assocA1, assocA2));
        }
        if (costB <= costA) {
            dpTable.get(parasiteNode.name).add(new Association(Association.AssociationType.COSPECIATION, parasiteNode, hostNode, hostNode.time, costB, assocB1, assocB2));
        }
    }

    void duplication(node parasiteNode, Vector<Association> child1Assoc, Vector<Association> child2Assoc, edge hostEdge) {
        // Each time between the startnode's tiem and the endnode's time
        // (exclusive of endpoints) is a possible time for a duplication
        // event on the edge (startnode, endnode)
        node startnode = hostEdge.first;
        node endnode = hostEdge.second;
        int startTime = Math.max(startnode.time + 1, hostNetwork.timeZoneMin(parasiteNode.timeZones.firstElement()));
        int endTime = Math.min(endnode.time, hostNetwork.timeZoneMax(parasiteNode.timeZones.lastElement()));
        Vector<Association> p1candidates = new Vector<Association>();
        Vector<Association> p2candidates = new Vector<Association>();
        Association optimalAssoc1 = null;
        Association optimalAssoc2 = null;
        int optimalCost;
        int cost;

        for (Association assoc : child1Assoc) {
            if (assoc.time >= startTime && hostNetwork.descendant(hostEdge, assoc.associate)) {
                p1candidates.add(assoc);
            }
        }
        for (Association assoc : child2Assoc) {
            if (assoc.time >= startTime && hostNetwork.descendant(hostEdge, assoc.associate)) {
                p2candidates.add(assoc);
            }
        }

        // range function excludes right endpoint, so we add 1 to include it
        for (int i = startTime; i <= endTime; i++) {
            optimalCost = pNetwork.INFINITY;
            for (Iterator<Association> it = p1candidates.iterator(); it.hasNext();) {
                Association assoc = it.next();
                if (assoc.time < i) {
                    it.remove();
                }
            }
            for (Iterator<Association> it = p2candidates.iterator(); it.hasNext();) {
                Association assoc = it.next();
                if (assoc.time < i) {
                    it.remove();
                }
            }
            for (Association assoc1 : p1candidates) {
                for (Association assoc2 : p2candidates) {
                    if (TARZAN) {
                        cost = costs[DUPLICATION];
                    } else {
                        cost = 2 * costs[DUPLICATION];
                    }

                    cost += assoc1.cost + assoc2.cost +
                            (hostNetwork.distance(hostEdge, assoc1.associate) +
                            hostNetwork.distance(hostEdge, assoc2.associate)) * costs[LOSS];
                    if (cost < optimalCost) {
                        optimalCost = cost;
                        optimalAssoc1 = assoc1;
                        optimalAssoc2 = assoc2;
                    }
                }
            }
            if (optimalCost < pNetwork.INFINITY) {
                dpTable.get(parasiteNode.name).add(new Association(Association.AssociationType.DUPLICATION, parasiteNode, hostEdge, i, optimalCost, optimalAssoc1, optimalAssoc2));
            }
        }
    }

    void hostSwitch(node parasiteNode, Vector<Association> child1Assoc, Vector<Association> child2Assoc, edge hostEdge) {
        // each time between the startnode's time and the endnode's time
        // (exclusive of endpoints) is a possible time for a duplication event
        // on the edge(startnode, endnode) followed by a host switch
        node startnode = hostEdge.first;
        node endnode = hostEdge.second;
        int startTime = Math.max(startnode.time + 1, hostNetwork.timeZoneMin(parasiteNode.timeZones.firstElement()));
        int endTime = Math.min(endnode.time, hostNetwork.timeZoneMax(parasiteNode.timeZones.lastElement()));
        Vector<Association> p1candidates = new Vector<Association>();
        Vector<Association> p2candidates = new Vector<Association>();
        Vector<locAssocPair> p1pairs = new Vector<locAssocPair>();
        Vector<locAssocPair> p2pairs = new Vector<locAssocPair>();
        Vector<edge> liveEdges;
        treeLocation switchTo = null;
        Association assocA1 = null;
        Association assocA2 = null;
        Association assocB1 = null;
        Association assocB2 = null;
        Association assoc1a;
        Association assoc2a;
        int cost = 0;
        int costA;
        int costB;

        for (Association assoc : child1Assoc) {
            if (assoc.time >= startTime && hostNetwork.descendant(hostEdge, assoc.associate)) {
                p1candidates.add(assoc);
            }
        }
        for (Association assoc : child2Assoc) {
            if (assoc.time >= startTime && hostNetwork.descendant(hostEdge, assoc.associate)) {
                p2candidates.add(assoc);
            }
        }

        // range function excludes the right endpoint, so we add 1 to include it
        for (int i = startTime; i <= endTime; i++) {
            p1pairs.clear();
            p2pairs.clear();

            for (Iterator<Association> it = p1candidates.iterator(); it.hasNext();) {
                Association assoc = it.next();
                if (assoc.time < i) {
                    it.remove();
                }
            }
            for (Iterator<Association> it = p2candidates.iterator(); it.hasNext();) {
                Association assoc = it.next();
                if (assoc.time < i) {
                    it.remove();
                }
            }

            liveEdges = hostNetwork.liveEdges(i);
            liveEdges.remove(hostEdge);

            for (edge switchEdge : liveEdges) {
                if (hostNetwork.withinDistanceN(hostEdge, switchEdge, switchDist)) {
                    for (Association assoc : child2Assoc) {
                        if (hostNetwork.descendant(switchEdge, assoc.associate) && assoc.time >= i) {
                            p2pairs.add(new locAssocPair(switchEdge, assoc));
                        }
                    }
                    for (Association assoc : child1Assoc) {
                        if (hostNetwork.descendant(switchEdge, assoc.associate) && assoc.time >= i) {
                            p1pairs.add(new locAssocPair(switchEdge, assoc));
                        }
                    }
                }
            }

            // OPTION A: Child p1 of parasite is on a descendant of
            // the hostEdge but child p2 host is a descendant of a host
            // switch contemporaneous lineage
            costA = pNetwork.INFINITY;
            treeLocation switchToA = null;
            for (Association assoc1 : p1candidates) {
                for (locAssocPair pairs : p2pairs) {
                    switchTo = pairs.l;
                    assoc2a = pairs.a;
                    if (TARZAN) {
                        cost = costs[SWITCH];
                    } else {
                        cost = 2 * costs[DUPLICATION] + costs[SWITCH];
                    }
                    cost += assoc1.cost + assoc2a.cost +
                            (hostNetwork.distance(hostEdge, assoc1.associate) +
                            hostNetwork.distance(switchTo, assoc2a.associate)) * costs[LOSS] +
                            hostNetwork.regionCosts.get(hostEdge.second.region).get(((edge) switchTo).second.region);
                    if (cost < costA) {
                        costA = cost;
                        assocA1 = assoc1;
                        assocA2 = assoc2a;
                        switchToA = switchTo;
                    }
                }
            }
            //OPTION B: Child p2 of parasite is on a descendant of
            // the hostEdge but child p1 is a descendant of a
            // host switch contemporaneous lineage
            costB = pNetwork.INFINITY;
            treeLocation switchToB = null;
            for (Association assoc2 : p2candidates) {
                for (locAssocPair pairs : p1pairs) {
                    switchTo = pairs.l;
                    assoc1a = pairs.a;
                    if (TARZAN) {
                        cost = costs[SWITCH];
                    } else {
                        cost = 2 * costs[DUPLICATION] + costs[SWITCH];
                    }

                    cost += assoc1a.cost + assoc2.cost +
                            (hostNetwork.distance(hostEdge, assoc2.associate) +
                            hostNetwork.distance(switchTo, assoc1a.associate)) * costs[LOSS] +
                            hostNetwork.regionCosts.get(hostEdge.second.region).get(((edge) switchTo).second.region);


                    if (cost < costB) {
                        costB = cost;
                        assocB1 = assoc1a;
                        assocB2 = assoc2;
                        switchToB = switchTo;
                    }
                }
            }
            if (costA >= pNetwork.INFINITY && costB >= pNetwork.INFINITY) {
                return;
            }

            if (costA <= costB) {
                dpTable.get(parasiteNode.name).add(new Association(Association.AssociationType.HOST_SWITCH, parasiteNode, hostEdge, switchToA, i, costA, assocA1, assocA2));
            }
            if (costB <= costA) {
                dpTable.get(parasiteNode.name).add(new Association(Association.AssociationType.HOST_SWITCH, parasiteNode, hostEdge, switchToB, i, costB, assocB1, assocB2));
            }
        }
    }

    Association bestAssociation(node parasiteNode) {
        /* Returns the association of minimum cost for parasiteName
         */
        double minCost = pNetwork.INFINITY;
        Association bestAssociation = null;
        /*iterate across assoc in dpTable[parasiteName]*/
        for (Association assoc : dpTable.get(parasiteNode.name)) {
            if (assoc.cost < minCost) {
                minCost = assoc.cost;
                bestAssociation = assoc;
            }
        }
        return bestAssociation;
    }

    void bestRootAssociations(node parasiteNode) {
        /* Loops across all the possible root associations and
         * inserts into bestRoots all the roots which
         * have the best cost we've found
         */
        double minCost = pNetwork.INFINITY;
        bestRoots = new Vector<Vector<Association>>();
        for (Association assoc : dpTable.get(parasiteNode.name)) {
            Vector<Association> temp = new Vector<Association>();
            if (assoc.cost < minCost) {
                minCost = assoc.cost;
                rootsTraverse(assoc, temp);
                bestRoots = new Vector<Vector<Association>>();
                bestRoots.add(temp);
            } else if (assoc.cost == minCost) {
                rootsTraverse(assoc, temp);
                bestRoots.add(temp);
            }
        }
    }

    String printOptimal() {
        /*Returns a String with the optimal solution*/
        String result = "==================================\n";
        node rootName = parasiteTree.root();
        Association start = bestAssociation(rootName);
        result += traverse(start);
        return result;
    }

    String printOptimal(Association start) {
        String result = "==================================\n";
        result += traverse(start);
        return result;
    }

    String traverse(Association assoc) {
        String result = "";
        result += "" + assoc + "\n";
        result += "--------------------------\n";
        bestAssocs.add(assoc);
        if (assoc.type == Association.AssociationType.TIP) {
            return result;
        } else {
            result += traverse(assoc.AChild1);
            result += traverse(assoc.AChild2);
        }

        return result;
    }

    void rootsTraverse(Association assoc, Vector<Association> aRoot) {
        aRoot.add(assoc);
        if (assoc.type == Association.AssociationType.TIP) {
            return;
        } else {
            rootsTraverse(assoc.AChild1, aRoot);
            rootsTraverse(assoc.AChild2, aRoot);
        }
    }

    public static class Solution {

        Association root;
        pNetwork hostNetwork;

        Solution(Association a, pNetwork pn) {
            root = a;
            hostNetwork = pn;
        }
    }
}

class locAssocPair {

    treeLocation l;
    Association a;

    locAssocPair(treeLocation e, Association a) {
        l = e;
        this.a = a;
    }
}
