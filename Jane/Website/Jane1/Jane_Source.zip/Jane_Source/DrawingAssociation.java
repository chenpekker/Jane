/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of the Harvey Mudd College nor the names of its
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dfielder
 */
public class DrawingAssociation extends Association {

    public static DrawingAssociation constructDrawingAssociation(Association root, pNetwork hostNetwork) {
        if (root instanceof DrawingAssociation) {
            throw new ClassCastException("Don't do that!");
        }

        if (root.associate.isEdge()) {
            return makeAssoc(root, (edge) root.associate, hostNetwork);
        } else {
            node as = (node) root.associate;
            return makeAssoc(root, new edge(as.parents.get(0), as), hostNetwork);
        }
    }

    private static DrawingAssociation makeAssoc(Association root, edge loc, pNetwork hostNetwork) {
        if (root.associate.equals(loc)) {
            DrawingAssociation answer = new DrawingAssociation(root);

            if (root.type == Association.AssociationType.DUPLICATION) {
                answer.AChild1 = makeAssoc(root.AChild1, loc, hostNetwork);
                answer.AChild2 = makeAssoc(root.AChild2, loc, hostNetwork);
            } else {
                if (hostNetwork.descendant(loc, root.AChild1.associate)) {
                    answer.AChild1 = makeAssoc(root.AChild1, loc, hostNetwork);
                    answer.AChild2 = makeAssoc(root.AChild2, (edge) root.switchTarget, hostNetwork);
                } else {
                    answer.AChild2 = makeAssoc(root.AChild2, loc, hostNetwork);
                    answer.AChild1 = makeAssoc(root.AChild1, (edge) root.switchTarget, hostNetwork);
                }
            }
            return answer;
        } else if (loc.second.equals(root.associate)) {
            DrawingAssociation answer = new DrawingAssociation(root);

            //This is a cospeciation, since only they have children and map to nodes
            if (root.type == Association.AssociationType.COSPECIATION) {
                node base = loc.second;
                node child1 = base.children.get(0);
                node child2 = base.children.get(1);
                if (hostNetwork.descendant(new edge(base, child1), root.AChild1.associate)) {
                    answer.AChild1 = makeAssoc(root.AChild1, new edge(base, child1), hostNetwork);
                    answer.AChild2 = makeAssoc(root.AChild2, new edge(base, child2), hostNetwork);
                } else if (hostNetwork.descendant(new edge(base, child2), root.AChild1.associate)) {
                    answer.AChild1 = makeAssoc(root.AChild1, new edge(base, child2), hostNetwork);
                    answer.AChild2 = makeAssoc(root.AChild2, new edge(base, child1), hostNetwork);
                } else {
                    System.out.println("How??");
                }
            }
            return answer;
        } else {
            DrawingAssociation answer = new DrawingAssociation(loc.second);
            node base = loc.second;
            node child1 = base.children.get(0);
            node child2 = base.children.get(1);
            if (hostNetwork.descendant(new edge(base, child1), root.associate)) {
                answer.AChild1 = makeAssoc(root, new edge(base, child1), hostNetwork);
            } else {
                answer.AChild1 = makeAssoc(root, new edge(base, child2), hostNetwork);
            }

            answer.parasite = answer.AChild1.parasite;

            return answer;
        }
    }

    private DrawingAssociation(node host) {
        super(AssociationType.LOSS, null, host, host.time, -1, null, null);
    }

    private DrawingAssociation(Association root) {
        super(root.type, root.parasite, root.associate, root.time, root.cost, null, null);
        switchTarget = root.switchTarget;
    }
    int x;
    int lane;
    DrawingAssociation parent;
}
