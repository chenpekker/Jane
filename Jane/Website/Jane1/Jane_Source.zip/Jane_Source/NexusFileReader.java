/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of the Harvey Mudd College nor the names of its
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


import java.io.*;
import java.util.*;

class NexusFileReader extends TreeFileReader
{

    private String annoyingExtraData = "";
    boolean knownNexus = false;
    boolean isNexus = false;
    boolean ranked = false;
    Map<Integer, Vector<Integer>> host = null;
    Map<Integer, String> hostNames = null;
    Map<Integer, Vector<Integer>> parasite = null;
    Map<Integer, String> parasiteNames = null;
    Map<Integer, Integer> phi = null;
    SortedMap<Integer, Vector<Integer>> hostRanks = new TreeMap<Integer, Vector<Integer>>();
    SortedMap<Integer, Vector<Integer>> parasiteRanks = new TreeMap<Integer, Vector<Integer>>();
    static int freeIndex = 1;

    public NexusFileReader(String filename) throws FileNotFoundException
    {
        super(filename);
    }

    boolean isNexus() throws java.io.IOException
    {
        if (knownNexus)
        {
            return isNexus;
        }

        String s = fin.readLine();
        while (s != null && !s.toLowerCase().startsWith("#nexus"))
        {
            s = fin.readLine();
        }
        knownNexus = true;
        isNexus = s != null;
        return isNexus;
    }

    String nextLine() throws java.io.IOException
    {
        StringBuilder curLine = new StringBuilder(annoyingExtraData);
        while (curLine.indexOf(";") == -1)
        {
            String s = fin.readLine();
            if (s != null)
            {
                if (s.indexOf("#") != -1)
                {
                    s = s.substring(0, s.indexOf("#"));
                }
                curLine.append(s.trim());
            } else
            {
                return null;
            }
        }

        String s = curLine.toString();

        annoyingExtraData = s.substring(s.indexOf(";") + 1).trim();

        return s.substring(0, s.indexOf(";"));
    }

    Block nextBlock() throws FileFormatException, java.io.IOException
    {
        String s = nextLine();
        if (s == null)
        {
            return null;
        }
        s = s.toLowerCase();
        if (!s.startsWith("begin"))
        {
            throw new FileFormatException("Unexpected data between blocks in the input file.");
        }
        Block b = new Block();

        b.title = s.substring("begin ".length());
        b.contents = new LinkedList<String>();

        String str;
        for (str = nextLine(); str != null && !(str.toLowerCase().startsWith("endblock") || str.toLowerCase().startsWith("end")); str = nextLine())
        {
            b.contents.addLast(str);
        }
        if (str == null)
        {
            throw new FileFormatException("Block ended without closing");
        }

        return b;
    }

    void readBlock(Block b) throws FileFormatException
    {
        if ("host".equals(b.title))
        {
            if (b.contents.size() > 1)
            {
                System.err.println("Unexpected multiple lines inside parasite block.");
            }
            if (b.contents.size() == 0)
            {
                throw new FileFormatException("No data inside parasite block");
            }

            String s = b.contents.get(0);
            host = new HashMap<Integer, Vector<Integer>>();
            hostNames = new HashMap<Integer, String>();
            TreeParser t = new TreeParser(s.substring(s.indexOf('(')).trim(), host, hostNames, hostRanks);
            int hroot = t.parseTree();
            Vector<Integer> v = new Vector<Integer>();
            v.add(hroot);
            host.put(0, v);
            hostNames.put(0, "Dummy Root");

            if(ranked)
                hostRanks.get(hostRanks.firstKey()).add(0);
        } else if ("parasite".equals(b.title))
        {
            if (b.contents.size() > 1)
            {
                System.err.println("Unexpected multiple lines inside host block.");
            }
            if (b.contents.size() == 0)
            {
                throw new FileFormatException("No data inside host block");
            }
            String s = b.contents.get(0);

            parasite = new HashMap<Integer, Vector<Integer>>();
            parasiteNames = new HashMap<Integer, String>();
            TreeParser t = new TreeParser(s.substring(s.indexOf('(')).trim(), parasite, parasiteNames, parasiteRanks);
            t.parseTree();
        } else if ("distribution".equals(b.title))
        {
            if (b.contents.size() != 1)
            {
                System.err.println("Unexpected multiple lines inside distribution block.");
            }
            if (b.contents.size() == 0)
            {
                throw new FileFormatException("No data inside distribution block");
            }

            String s = b.contents.get(0);
            phi = parsePhi(s);
        } else
        {
            System.err.println("Unrecognized block " + b.title);
        }
    }

    Map<Integer, Integer> parsePhi(String s) throws FileFormatException
    {
        Map<Integer, Integer> phi = new HashMap<Integer, Integer>();
        if (!s.toLowerCase().startsWith("range"))
        {
            throw new FileFormatException("Missing keyword range inside distribution data.");
        }
        s = s.substring("range".length()).trim();
        String[] pairs = s.split(",");
        for (String pair : pairs)
        {
            String[] map = pair.split(":");
            if (map.length != 2)
            {
                throw new FileFormatException("Missing colon between a parasite and a host");
            }
            Integer p = backwardsLookup(parasiteNames, map[0].trim());
            Integer h = backwardsLookup(hostNames, map[1].trim());
            if (p == null)
            {
                throw new FileFormatException("Unrecognized Parasite: " + map[0]);
            }
            if (h == null)
            {
                throw new FileFormatException("Unrecognized Host: " + map[1]);
            }
            phi.put(p, h);
        }
        return phi;
    }

    static Integer backwardsLookup(Map<Integer, String> map, String s)
    {
        for (Map.Entry<Integer, String> me : map.entrySet())
        {
            if (me.getValue().equals(s))
            {
                return me.getKey();
            }
        }
        System.out.println(s);
        return null;
    }

    public ProblemInstance readProblem() throws FileFormatException, java.io.IOException
    {
        freeIndex = 1;
        if (!isNexus)
        {
            throw new FileFormatException("The file does not contain #NEXUS in the header");
        }

        for (Block s = nextBlock(); s != null; s = nextBlock())
        {
            readBlock(s);
        }


        if (host == null)
        {
            throw new FileFormatException("The file does not specify a host tree");
        }
        if (parasite == null)
        {
            throw new FileFormatException("The file does not specify a parasite tree");
        }
        if (phi == null)
        {
            throw new FileFormatException("The file does not specify a mapping between parasites and hosts.");
        }

        for (Map.Entry<Integer, Vector<Integer>> par : parasite.entrySet())
        {
            if (par.getValue().size() == 0 && phi.get(par.getKey()) == null)
            {
                throw new FileFormatException("Not all parasite tips are mapped to host tips.");
            }
        }


        if (!ranked)
        {
            hostRanks.put(1, new Vector<Integer>());
            parasiteRanks.put(1, new Vector<Integer>());

            for (Integer i : host.keySet())
            {
                hostRanks.get(1).add(i);
            }

            for (Integer i : parasite.keySet())
            {
                parasiteRanks.get(1).add(i);
            }
        } else
        {
            for (Integer i : host.keySet())
            {
                boolean hasRank = false;
                for (Vector<Integer> v : hostRanks.values())
                {
                    if (v.contains(i))
                    {
                        hasRank = true;
                    }
                }

                if (!hasRank)
                {
                    System.out.println(i + " in \n" + host);
                    System.out.println(hostRanks);
                    throw new FileFormatException("Parital time zone assignment in the host tree.");
                }
            }
            for (Integer i : parasite.keySet())
            {
                boolean hasRank = false;
                for (Vector<Integer> v : parasiteRanks.values())
                {
                    if (v.contains(i))
                    {
                        hasRank = true;
                    }
                }

                if (!hasRank)
                {
                    throw new FileFormatException("Parital time zone assignment in the parasite tree.");
                }
            }
        }

        return new ProblemInstance(host, hostNames, hostRanks, parasite, parasiteNames, parasiteRanks, phi);
    }

    class Block
    {

        String title;
        LinkedList<String> contents;
    }

    class TreeParser
    {

        int index;
        String tree;
        Map<Integer, Vector<Integer>> relations;
        Map<Integer, String> names;
        SortedMap<Integer, Vector<Integer>> ranks;

        TreeParser(String t, Map<Integer, Vector<Integer>> r, Map<Integer, String> n, SortedMap<Integer, Vector<Integer>> ranks)
        {
            index = 0;
            tree = t;
            relations = r;
            names = n;
            this.ranks = ranks;
        }

        int parseTree() throws FileFormatException
        {
            int myName;
            if (tree.charAt(index) == '(')
            {
                index++;
                int lchild = parseTree();

                if (tree.charAt(index) != ',')
                {
                    throw new FileFormatException("Malformed tree");
                }
                index++;
                if (tree.charAt(index) == ' ')
                {
                    index++;
                }

                int rchild = parseTree();

                if (tree.charAt(index) != ')')
                {
                    if (tree.charAt(index) == ',')
                    {
                        throw new FileFormatException("Non-binary species trees are not supported.");
                    }
                    throw new FileFormatException("Malformed tree");
                }
                index++;

                Vector<Integer> vi = new Vector<Integer>();
                vi.add(lchild);
                vi.add(rchild);
                myName = freeIndex;
                freeIndex++;
                relations.put(myName, vi);
                names.put(myName, myName + "");
            } else
            {
                StringBuilder sb = new StringBuilder();
                while (!"(),:".contains("" + tree.charAt(index)))
                {
                    sb.append(tree.charAt(index));
                    index++;
                }

                myName = freeIndex;
                freeIndex++;
                relations.put(myName, new Vector<Integer>());
                names.put(myName, sb.toString().trim());
            }

            if (index < tree.length() && tree.charAt(index) == ':')
            {
                index++;
                if (tree.charAt(index) == '[')
                {
                    index++;
                    int rangeStart = 0;
                    while (Character.isDigit(tree.charAt(index)))
                    {
                        rangeStart *= 10;
                        rangeStart += tree.charAt(index) - '0';
                        index++;
                    }
                    if (tree.charAt(index) == ']')
                    {
                        ranked = true;
                        index++;
                        if (!ranks.containsKey(rangeStart))
                        {
                            ranks.put(rangeStart, new Vector<Integer>());
                        }
                        ranks.get(rangeStart).add(myName);
                    } else if (tree.charAt(index) != ',')
                    {
                        throw new FileFormatException("Timings must be of the form [number] or [number,number]");
                    } else
                    {
                        index++;

                        int rangeEnd = 0;
                        while (Character.isDigit(tree.charAt(index)))
                        {
                            rangeEnd *= 10;
                            rangeEnd += tree.charAt(index) - '0';
                            index++;
                        }

                        if (tree.charAt(index) != ']')
                        {
                            System.out.println(tree.substring(index));
                            throw new FileFormatException("Timings must be of the form [number] or [number,number]");
                        }
                        if (rangeStart > rangeEnd)
                        {
                            throw new FileFormatException("The end of a range of time zones must be greater than the start.");
                        }

                        index++;
                        ranked = true;
                        for (int i = rangeStart; i <= rangeEnd; i++)
                        {
                            if (!ranks.containsKey(i))
                            {
                                ranks.put(i, new Vector<Integer>());
                            }
                            ranks.get(i).add(myName);
                        }
                    }

                } else
                {
                    while (Character.isDigit(tree.charAt(index)) || tree.charAt(index) == '.')
                    {
                        index++;
                    }
                }
            }

            return myName;
        }
    }
}
