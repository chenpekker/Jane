/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
 * Neither the name of the Harvey Mudd College nor the names of its
contributors may be used to endorse or promote products derived from this
software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

import java.awt.Color;
import java.awt.Font;

/*
 * SimpleViewer.java
 *
 * Created on Jul 28, 2009, 9:56:53 AM
 */
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.HashMap;
import java.util.Vector;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Comparator;
import java.util.Collections;
import javax.imageio.ImageIO;
import javax.swing.KeyStroke;
import javax.swing.JOptionPane;

/**
 *
 * @author dfielder
 */
public class SimpleViewer extends javax.swing.JFrame {

    private enum DrawLocation {

        TOP, BOTTOM, OTHER
    };

    private static class EdgeDrawingInstruction {

        static final EdgeDrawingInstruction BLACK_THIN = new EdgeDrawingInstruction(false, Color.BLACK);
        static final EdgeDrawingInstruction BLACK_THICK = new EdgeDrawingInstruction(true, Color.BLACK);
        static final EdgeDrawingInstruction BLUE_THIN = new EdgeDrawingInstruction(false, Color.BLUE);
        static final EdgeDrawingInstruction BLUE_THICK = new EdgeDrawingInstruction(true, Color.BLUE);
        static final EdgeDrawingInstruction GREEN_THIN = new EdgeDrawingInstruction(false, Color.GREEN);
        static final EdgeDrawingInstruction GREEN_THICK = new EdgeDrawingInstruction(true, Color.GREEN);
        static final EdgeDrawingInstruction GREEN_OUTLINED = new EdgeDrawingInstruction(true, Color.GREEN, Color.BLACK);
        static final EdgeDrawingInstruction RED_THIN = new EdgeDrawingInstruction(false, Color.RED);
        static final EdgeDrawingInstruction RED_THICK = new EdgeDrawingInstruction(true, Color.RED);
        static final EdgeDrawingInstruction RED_OUTLINED = new EdgeDrawingInstruction(true, Color.RED, Color.BLACK);
        static final EdgeDrawingInstruction YELLOW_THIN = new EdgeDrawingInstruction(false, Color.YELLOW);
        static final EdgeDrawingInstruction YELLOW_THICK = new EdgeDrawingInstruction(true, Color.YELLOW);
        static final EdgeDrawingInstruction YELLOW_OUTLINED = new EdgeDrawingInstruction(true, Color.YELLOW, Color.BLACK);
        boolean thick;
        boolean outlined;
        java.awt.Color color;
        java.awt.Color outlineColor;

        EdgeDrawingInstruction(boolean thick, java.awt.Color color) {
            this.thick = thick;
            this.color = color;
            this.outlined = false;
        }

        EdgeDrawingInstruction(boolean thick, java.awt.Color color, java.awt.Color outlineColor) {
            this.thick = thick;
            this.color = color;
            this.outlined = true;
            this.outlineColor = outlineColor;
        }
    }
    private SortedMap<Integer, Vector<DrawingAssociation>> timeEvents = new TreeMap<Integer, Vector<DrawingAssociation>>();
    private Map<Integer, Vector<DrawingAssociation>> incidentAssociations = new HashMap<Integer, Vector<DrawingAssociation>>();
    private Map<Integer, Vector<DrawingAssociation>> previousEdgeEvents = new HashMap<Integer, Vector<DrawingAssociation>>();
    private Map<Integer, ParasiteNode> pNodes = new HashMap<Integer, ParasiteNode>();
    private Map<Integer, EdgeDrawingInstruction> parentDrawingInstructions = new HashMap<Integer, EdgeDrawingInstruction>();
    private DrawingAssociation solution;
    private pNetwork hostTree;
    private Map<Integer, Map<Integer, EdgeDrawingInstruction>> hostEdgeTimeDrawingInstructions = new HashMap<Integer, Map<Integer, EdgeDrawingInstruction>>();
    private Map<Integer, EdgeDrawingInstruction> hostNodeDrawingInstructions = new HashMap<Integer, EdgeDrawingInstruction>();

    /**
     * Creates a new viewer frame to view solutions to cophylogeny problems.
     * hostTree and solution must both come from the same Solver instance.
     * @param solution
     * @param hostTree
     */
    public SimpleViewer(Association solution, pNetwork hostTree) {
        this.setTitle("Solution Viewer Cost: " + solution.cost);
        this.solution = DrawingAssociation.constructDrawingAssociation(solution, hostTree);
        this.hostTree = hostTree;
        this.setContentPane(new SolutionPane());
        this.assignPNodes(this.solution);
        this.assignHostDrawing();
    }

    void assignHostDrawing() {
        for (node n : hostTree.nodes.values()) {
            hostNodeDrawingInstructions.put(n.name, EdgeDrawingInstruction.BLACK_THICK);
            if (n.Root()) {
                continue;
            }
            hostEdgeTimeDrawingInstructions.put(n.name, new HashMap<Integer, EdgeDrawingInstruction>());
            for (int time = n.parents.get(0).time; time <= n.time; time++) {
                hostEdgeTimeDrawingInstructions.get(n.name).put(time, EdgeDrawingInstruction.BLACK_THICK);
            }
        }
    }

    /*
     * Creates PNodes for all each event in the association tree.
     * These will be dots placed at each event.
     */
    void assignPNodes(DrawingAssociation asc) {
        if (asc.type != Association.AssociationType.LOSS) {
            ParasiteNode pn = new ParasiteNode(asc);
            pn.setVisible(false);
            pNodes.put(asc.parasite.name, pn);
            this.getContentPane().add(pn);
            parentDrawingInstructions.put(asc.parasite.name, EdgeDrawingInstruction.BLUE_THIN);
        }

        if (asc.AChild1 != null) {
            assignPNodes((DrawingAssociation) asc.AChild1);
        }
        if (asc.AChild2 != null) {
            assignPNodes((DrawingAssociation) asc.AChild2);
        }
    }

    /*
     * the JPanel which draws the host and parasite trees as its background
     */
    private class SolutionPane extends javax.swing.JPanel {

        Map<Integer, Integer> heights = new HashMap<Integer, Integer>();
        SortedMap<Integer, Integer> xPos = new TreeMap<Integer, Integer>();
        Map<Integer, Integer> lineY = new TreeMap<Integer, Integer>();
        private final int spacingBelow = 1;
        private final int nodeSize = 5;
        private int timeZoneHeight = 50;
        private int laneHeight = 8;
        private int eventWidth = 10;
        private int textHeight = 12;
        private boolean ready = false;
        private int assocCount = 0;
        private int maxLanesRequired;
        private int totalEvents;

        /* This is a one-time method that takes solution and puts it into all the
         * data structures used to draw it.
         */
        void associateEvents() {
            ready = false;
            heights.clear();
            xPos.clear();
            lineY.clear();

            for (node n : hostTree.nodes.values()) {
                incidentAssociations.put(n.name, new Vector<DrawingAssociation>());
                previousEdgeEvents.put(n.name, new Vector<DrawingAssociation>());
            }

            int tiptime = hostTree.tips().get(0).time;
            for (int i = 0; i <= tiptime; ++i) {
                timeEvents.put(i, new Vector<DrawingAssociation>());
            }

            mapAssociation(solution);

            assocCount = 0;
            timeMapAssociation(solution);

            for (Vector<DrawingAssociation> da : timeEvents.values()) {
                Collections.sort(da, new Comparator<DrawingAssociation>() {

                    public int compare(DrawingAssociation da1, DrawingAssociation da2) {
                        int da1type, da2type;
                        if (da1.type == Association.AssociationType.DUPLICATION || da1.type == Association.AssociationType.HOST_SWITCH) {
                            da1type = 1;
                        } else {
                            da1type = 2;
                        }
                        if (da2.type == Association.AssociationType.DUPLICATION || da2.type == Association.AssociationType.HOST_SWITCH) {
                            da2type = 1;
                        } else {
                            da2type = 2;
                        }
                        if (da1type != da2type) {
                            return da1type - da2type;
                        } else {
                            return da1.parasite.timeZones.firstElement() - da2.parasite.timeZones.firstElement();
                        }
                    }
                });
            }

            assignLanes();

            //pad for the beginning of time
            totalEvents = 1;
            for (Map.Entry<Integer, Vector<DrawingAssociation>> va : timeEvents.entrySet()) {
                totalEvents += va.getValue().size() + 1;
            }

            totalEvents -= (assocCount + 1) / 2;

            laneHeight = 1;
            calculateHeightAndY(hostTree.root(), 0);
            int maxy = 0;
            for (Integer n : lineY.values()) {
                maxy = Math.max(maxy, n);
            }
            maxLanesRequired = (maxy + 1);

            ready = true;
        }

        /*
         * In order to draw parasite lineages tracking down a host lineage, each
         * parasite lineage is assigned a lane. This method calculates lane assignments.
         */
        void assignLanes() {
            for (Integer n : incidentAssociations.keySet()) {
                Vector<DrawingAssociation> incident = incidentAssociations.get(n);
                Vector<DrawingAssociation> edge = previousEdgeEvents.get(n);

                for (int i = 0; i < incident.size(); i++) {
                    incident.get(i).lane = i + 1;
                }

                for (int i = edge.size() - 1; i >= 0; --i) {
                    DrawingAssociation asc = edge.get(i);

                    if (asc.type == Association.AssociationType.DUPLICATION) {
                        asc.lane = ((DrawingAssociation) asc.AChild1).lane;
                    } else if (asc.type == Association.AssociationType.HOST_SWITCH && ((edge) asc.associate).second.name == n) {
                        if (hostTree.descendant(asc.associate, asc.AChild1.associate)) {
                            asc.lane = ((DrawingAssociation) asc.AChild1).lane;
                        } else {
                            asc.lane = ((DrawingAssociation) asc.AChild2).lane;
                        }
                    }
                }
            }
        }

        /*
         * Puts each association into the appropriate slot of timeEvents.
         * Also, assigns parents on drawingAssociations.
         */
        void timeMapAssociation(DrawingAssociation assoc) {
            if (assoc.type != Association.AssociationType.LOSS) {
                assocCount++;
            }
            timeEvents.get(assoc.time).add(assoc);
            if (assoc.AChild1 != null) {
                timeMapAssociation((DrawingAssociation) assoc.AChild1);
                ((DrawingAssociation) assoc.AChild1).parent = assoc;
            }
            if (assoc.AChild2 != null) {
                timeMapAssociation((DrawingAssociation) assoc.AChild2);
                ((DrawingAssociation) assoc.AChild2).parent = assoc;
            }
        }

        /* Places each association into incidentAssociations or
         * previousEdgeEvents for its host, as appropriate.
         */
        void mapAssociation(DrawingAssociation assoc) {
            switch (assoc.type) {
                case COSPECIATION:
                    incidentAssociations.get(((node) assoc.associate).name).add(assoc);
                    mapAssociation((DrawingAssociation) assoc.AChild1);
                    mapAssociation((DrawingAssociation) assoc.AChild2);
                    break;
                case LOSS:
                    incidentAssociations.get(((node) assoc.associate).name).add(assoc);
                    mapAssociation((DrawingAssociation) assoc.AChild1);
                    break;
                case HOST_SWITCH:
                    previousEdgeEvents.get(((edge) assoc.associate).second.name).add(assoc);
                    previousEdgeEvents.get(((edge) assoc.switchTarget).second.name).add(assoc);
                    mapAssociation((DrawingAssociation) assoc.AChild1);
                    mapAssociation((DrawingAssociation) assoc.AChild2);
                    break;
                case DUPLICATION:
                    previousEdgeEvents.get(((edge) assoc.associate).second.name).add(assoc);
                    mapAssociation((DrawingAssociation) assoc.AChild1);
                    mapAssociation((DrawingAssociation) assoc.AChild2);
                    break;
                case TIP:
                    incidentAssociations.get(((node) assoc.associate).name).add(assoc);
                    break;
            }
        }


        /*
         * This method scales the x and y values assigned to components of the
         * tree to fit the current window size.
         */
        void scale(java.awt.Graphics g) {
            if (hostTree.zoneList.size() > 1) {
                laneHeight = (getHeight() - timeZoneHeight) / maxLanesRequired;
            } else {
                laneHeight = getHeight() / maxLanesRequired;
            }

            resizeFont(g, laneHeight);

            FontMetrics fm = g.getFontMetrics();

            int maxTextWidth = 0;
            for (DrawingAssociation assoc : timeEvents.get(timeEvents.lastKey())) {
                if (assoc.type == Association.AssociationType.TIP) {
                    maxTextWidth = Math.max(maxTextWidth, fm.stringWidth(assoc.parasite.fancyName));
                }
            }

            for (node n : hostTree.tips()) {
                maxTextWidth = Math.max(maxTextWidth, fm.stringWidth(n.fancyName));
            }

            eventWidth = (getWidth() - (maxTextWidth + nodeSize / 2 + 1)) / totalEvents;
            calculateXPos();

            calculateHeightAndY(hostTree.root(), 0);
        }

        /*
         * Calculates the y value for the horizontal line representing a host
         * vertex. It also recursively calculates y values for descendants.
         */
        void calculateHeightAndY(node n, int y) {
            int liney;
            int height;
            if (n.Tip()) {
                height = (spacingBelow + 1 + incidentAssociations.get(n.name).size()) * laneHeight;
                liney = y + height - spacingBelow * laneHeight;
            } else {
                calculateHeightAndY(n.children.get(0), y);
                int child0y = lineY.get(n.children.get(0).name);
                liney = Math.max(y + heights.get(n.children.get(0).name), child0y + incidentAssociations.get(n.name).size() * laneHeight);
                //height = Math.max((1 + incidentAssociations.get(n.name).size()) * laneHeight, heights.get(n.children.get(0).name));
                height = liney - y;

                for (int i = 1; i < n.children.size(); i++) {
                    calculateHeightAndY(n.children.get(i), liney);
                    height += heights.get(n.children.get(i).name);
                }
            }
            heights.put(n.name, height);
            lineY.put(n.name, liney);
            //System.out.println(n.name +","+ liney);
            //return liney;
        }

        /*
         * Calculates the x position of every parasite association and host tree
         * node.
         */
        void calculateXPos() {
            //pad for the beginning of time
            int x = eventWidth;
            for (Integer i : timeEvents.keySet()) {
                //first assign stuff that goes on edges
                for (DrawingAssociation asc : timeEvents.get(i)) {
                    if (asc.type == Association.AssociationType.DUPLICATION || asc.type == Association.AssociationType.HOST_SWITCH) {
                        x += eventWidth;
                        asc.x = x;
                    }
                }
                //then assign stuff that goes on the vertex
                for (DrawingAssociation asc : timeEvents.get(i)) {
                    if (asc.type == Association.AssociationType.LOSS || asc.type == Association.AssociationType.COSPECIATION) {
                        x += eventWidth;
                        asc.x = x;
                    }
                }
                //finally assign the host vertex
                x += eventWidth;

                xPos.put(i, x);

                for (DrawingAssociation asc : timeEvents.get(i)) {
                    if (asc.type == Association.AssociationType.TIP) {
                        asc.x = x;
                    }
                }
            }
            //Special case the x position for the root to 0
            xPos.put(timeEvents.firstKey(), 0);

            if (eventWidth * totalEvents != x) {
                System.out.println("Event Counting Error!");
            }
        }

        /*
         * Scales the font on a graphics object to a specified height
         */
        void resizeFont(Graphics g, int h) {
            FontMetrics fm = g.getFontMetrics();
            int curH = fm.getHeight();
            Font curF = g.getFont();
            float size = curF.getSize2D();
            while (curH > h && size > 8) {
                size -= 0.1f;
                curF = curF.deriveFont(size);
                fm = g.getFontMetrics(curF);
                curH = fm.getHeight();
            }
            textHeight = curH;
            g.setFont(curF);
        }

        /** Creates new SolutionPane */
        SolutionPane() {
            initComponents();
            this.setLayout(null);
            associateEvents();
            validate();
            repaint();
        }

        /*
         * Draws the tree
         */
        @Override
        public void paintComponent(java.awt.Graphics g) {
            if (ready) {
                g.setColor(Color.WHITE);
                g.fillRect(0, 0, getWidth(), getHeight());
                scale(g);

                drawNode(g, hostTree.root(), 0, 0, DrawLocation.OTHER);
                //now, add a leading edge to the parasite tree
                node solutionAssoc = getAssociateNode(solution);
                drawHorizLine(g, getY(solution),
                        solution.x, xPos.get(solutionAssoc.parents.get(0).time),
                        parentDrawingInstructions.get(solution.parasite.name));

                if (hostTree.zoneList.size() > 1) {
                    drawTimeZones(g);
                }
            }
        }

        /*
         * Draws labels for time zones onto the bottom of the tree
         */
        void drawTimeZones(Graphics g) {
            g.setFont(g.getFont().deriveFont(13.0f));
            g.setColor(Color.BLACK);

            int startX = 0;
            int endX = 0;
            int currentZone = hostTree.zoneList.firstKey();
            int nextZone;
            int parX;

            SortedSet<Integer> s = new TreeSet<Integer>();
            for (Integer i : timeEvents.keySet()) {
                s = new TreeSet<Integer>();
                parX = xPos.get(i);
                nextZone = hostTree.nodeAtTime(i).zone;
                int prevZone = currentZone; // used later to determine if the last
                // time zone only has tips

                // this loop sets things up for the case in which parasite
                // nodes occur in a time zone between two consecutive
                // host time zones
                for (DrawingAssociation d : timeEvents.get(i)) {
                    if (!d.type.equals(Association.AssociationType.LOSS)) {
                        for (Integer j : d.parasite.timeZones) {
                            if (j > currentZone && j < nextZone) {
                                s.add(j);
                                if (d.x < parX) {
                                    parX = d.x;
                                }
                            }
                            break;
                        }
                    }
                }

                // draws the section for the current time zone
                if (hostTree.nodeAtTime(i).zone != currentZone || i.equals(timeEvents.lastKey())) {
                    if (s.isEmpty()) {
                        endX = xPos.get(i);
                        if (currentZone != hostTree.tips().get(0).zone) {
                            endX -= eventWidth / 2;
                        }
                        if (i != timeEvents.lastKey()) {
                            endX -= incidentAssociations.get(hostTree.nodeAtTime(i).name).size() * eventWidth;
                        }
                    } else {
                        endX = parX - eventWidth / 2;
                    }

                    drawTimeZone(g, currentZone + "", startX, endX);

                    currentZone = hostTree.nodeAtTime(i).zone;
                    startX = endX;
                }

                // if there is a parasite only time zone, draw that one
                if (!s.isEmpty()) {
                    endX = xPos.get(i) - eventWidth / 2;
                    if (!i.equals(timeEvents.lastKey())) {
                        endX -= timeEvents.get(i + 1).size() * eventWidth;
                    }

                    if (currentZone != s.first()) {
                        drawTimeZone(g, s.first() + "", startX, endX);
                        startX = endX;
                    }
                }

                // if the last time zone only has tips
                if (i.equals(timeEvents.lastKey()) && prevZone != currentZone) {
                    drawTimeZone(g, currentZone + "", endX, xPos.get(i));
                }
            }
        }

        /*
         * Draws an individual time zone label
         */
        void drawTimeZone(Graphics g, String name, int startX, int endX) {
            int timezoneTextHeight = g.getFontMetrics().getHeight();
            int textWidth = g.getFontMetrics().stringWidth(name);

            g.drawString(name, (startX + endX) / 2 - textWidth / 2, getHeight() - timezoneTextHeight);
            g.drawLine(startX, getHeight() - timeZoneHeight * 4 / 5, endX, getHeight() - timeZoneHeight * 4 / 5);
            g.drawLine(startX, getHeight() - timeZoneHeight, startX, getHeight() - timeZoneHeight * 3 / 5);
            g.drawLine(endX, getHeight() - timeZoneHeight, endX, getHeight() - timeZoneHeight * 3 / 5);
        }

        /*
         * Gets the node associated with an association.
         * If the association is on an edge, it returns the end of that edge
         */
        node getAssociateNode(Association asc) {
            if (asc.associate.isEdge()) {
                return ((edge) asc.associate).second;
            } else {
                return (node) asc.associate;
            }
        }

        /*
         * Gets the y coordinate of the location of an association
         */
        int getY(DrawingAssociation asc) {
            return lineY.get(getAssociateNode(asc).name) - asc.lane * laneHeight;
        }

        /*
         * Draws an arrow
         */
        void drawArrow(java.awt.Graphics g, int x, int y, int width, int height, boolean up) {
            if (height < 4) {
                height = 4;
            }
            if (width < 4) {
                width = 4;
            }
            if (up) {
                g.drawLine(x - width / 2, y - height / 2, x, y + height / 2);
                g.drawLine(x + width / 2, y - height / 2, x, y + height / 2);
            } else {
                g.drawLine(x - width / 2, y + height / 2, x, y - height / 2);
                g.drawLine(x + width / 2, y + height / 2, x, y - height / 2);
            }
        }

        /*
         * Moves a PNode to a position
         */
        void placeNode(int parasite, int x, int y) {
            ParasiteNode pn = pNodes.get(parasite);
            if (pn.dragging) {
                return;
            }
            pn.setSideLength(nodeSize);
            pn.setLocation(x - nodeSize / 2, y - nodeSize / 2);
            pn.setVisible(true);
        }

        /*
         * Draws a vertical line while obeying EdgeDrawingInstructions
         */
        void drawVertLine(Graphics g, int x, int y1, int y2, EdgeDrawingInstruction instruction) {
            g.setColor(instruction.color);
            if (!instruction.thick) {
                g.drawLine(x, y1, x, y2);
            } else {
                g.fillRect(x, Math.min(y1, y2), 2, Math.abs(y1 - y2));
                if (instruction.outlined) {
                    g.setColor(instruction.outlineColor);
                    g.drawRect(x - 1, Math.min(y1, y2) - 1, 4, Math.abs(y1 - y2) + 2);
                }
            }
        }

        /*
         * Draws a horizontal line while obeying EdgeDrawingInstructions
         */
        void drawHorizLine(Graphics g, int y, int x1, int x2, EdgeDrawingInstruction instruction) {
            g.setColor(instruction.color);
            if (!instruction.thick) {
                g.drawLine(x1, y, x2, y);
            } else {
                g.fillRect(Math.min(x1, x2), y - 1, Math.abs(x1 - x2), 2);
                if (instruction.outlined) {
                    g.setColor(instruction.outlineColor);
                    g.drawRect(Math.min(x1, x2) - 1, y - 2, Math.abs(x1 - x2) + 2, 4);
                }
            }
        }

        /*
         * Draws loss, cospeciation, and tip events
         */
        void drawIncidentAssociation(Graphics g, DrawingAssociation asc, node n) {
            int assocliney = getY(asc);
            switch (asc.type) {
                case TIP:
                    if (asc.time == timeEvents.lastKey()) {
                        g.drawString(asc.parasite.fancyName, asc.x + nodeSize / 2 + 1, assocliney + textHeight / 2);
                    }

                    placeNode(asc.parasite.name, asc.x, assocliney);
                    break;
                case COSPECIATION:
                    int targety1 = getY((DrawingAssociation) asc.AChild1);
                    int targetx1 = ((DrawingAssociation) asc.AChild1).x;

                    int targety2 = getY((DrawingAssociation) asc.AChild2);
                    int targetx2 = ((DrawingAssociation) asc.AChild2).x;
                    placeNode(asc.parasite.name, asc.x, assocliney);
                    drawVertLine(g, asc.x, assocliney, targety1, parentDrawingInstructions.get(asc.AChild1.parasite.name));
                    drawHorizLine(g, targety1, asc.x, targetx1, parentDrawingInstructions.get(asc.AChild1.parasite.name));
                    drawVertLine(g, asc.x, assocliney, targety2, parentDrawingInstructions.get(asc.AChild2.parasite.name));
                    drawHorizLine(g, targety2, asc.x, targetx2, parentDrawingInstructions.get(asc.AChild2.parasite.name));
                    break;
                case LOSS:
                    int targety = getY((DrawingAssociation) asc.AChild1);
                    int targetx = ((DrawingAssociation) asc.AChild1).x;

                    drawVertLine(g, asc.x, assocliney, targety, parentDrawingInstructions.get(asc.AChild1.parasite.name));
                    drawHorizLine(g, targety, asc.x, targetx, parentDrawingInstructions.get(asc.AChild1.parasite.name));
                    break;
            }
        }

        /*
         * Draws duplication and host switch events
         */
        void drawEdgeAssociation(Graphics g, DrawingAssociation asc) {
            DrawingAssociation nearChild = null;
            DrawingAssociation farChild = null;
            switch (asc.type) {
                case DUPLICATION:
                    nearChild = (DrawingAssociation) asc.AChild1;
                    farChild = (DrawingAssociation) asc.AChild2;
                    break;
                case HOST_SWITCH:
                    if (hostTree.descendant(asc.associate, asc.AChild1.associate)) {
                        nearChild = (DrawingAssociation) asc.AChild1;
                        farChild = (DrawingAssociation) asc.AChild2;
                    } else {
                        nearChild = (DrawingAssociation) asc.AChild2;
                        farChild = (DrawingAssociation) asc.AChild1;
                    }
                    break;
            }

            int nearY = getY(nearChild);
            int farY = getY(farChild);

            drawHorizLine(g, nearY, asc.x, nearChild.x, parentDrawingInstructions.get(nearChild.parasite.name));
            drawHorizLine(g, farY, asc.x, farChild.x, parentDrawingInstructions.get(farChild.parasite.name));
            drawVertLine(g, asc.x, nearY, farY, parentDrawingInstructions.get(farChild.parasite.name));
            asc.lane = nearChild.lane;
            placeNode(asc.parasite.name, asc.x, nearY);

            if (asc.type == Association.AssociationType.HOST_SWITCH) {
                drawArrow(g, asc.x, (nearY + farY) / 2, laneHeight * 2 / 3, laneHeight * 2 / 3, nearY < farY);
            }
        }

        /*
         * Draws nodes of the host tree, and the parasite tree nodes that
         * are associated with them.
         */
        void drawNode(java.awt.Graphics g, node n, int x, int y, DrawLocation location) {
            int endx = xPos.get(n.time);
            int liney = lineY.get(n.name);

            if (n.Root()) {
                drawNode(g, n.children.get(0), x, y, DrawLocation.OTHER);
            } else {
                //Draw the host tree portion for this node
                int prevX = x;
                for (int time = n.parents.get(0).time + 1; time <= n.time; ++time) {
                    if (time == n.time) {
                        drawHorizLine(g, liney, prevX, xPos.get(time) - eventWidth / 2,
                                hostEdgeTimeDrawingInstructions.get(n.name).get(time));
                    } else {
                        drawHorizLine(g, liney, prevX, xPos.get(time),
                                hostEdgeTimeDrawingInstructions.get(n.name).get(time));
                    }
                    prevX = xPos.get(time);
                }
                drawHorizLine(g, liney, xPos.get(n.time) - eventWidth / 2, xPos.get(n.time), hostNodeDrawingInstructions.get(n.name));

                if (n.Tip()) {
                    g.drawString(n.fancyName, endx + nodeSize / 2 + 1, liney + textHeight / 2);
                } else {
                    drawNode(g, n.children.get(0), endx, y, DrawLocation.TOP);
                    drawNode(g, n.children.get(1), endx, liney, DrawLocation.BOTTOM);
                }

                //Draw all events that take place at the node
                for (DrawingAssociation asc : incidentAssociations.get(n.name)) {
                    drawIncidentAssociation(g, asc, n);
                }

                //Draw events on the preceding edge
                //We do this in reverse order so children get lanes before parents are drawn.
                Vector<DrawingAssociation> previousEdge = previousEdgeEvents.get(n.name);
                for (int i = previousEdge.size() - 1; i >= 0; --i) {
                    DrawingAssociation asc = previousEdge.get(i);

                    drawEdgeAssociation(g, asc);
                }
            }

            //Draw a line up or down to connect to the previous host tree line
            if (location == DrawLocation.BOTTOM) {
                drawVertLine(g, x, y, liney, hostNodeDrawingInstructions.get(n.parents.get(0).name));
            } else if (location == DrawLocation.TOP) {
                drawVertLine(g, x, lineY.get(n.parents.get(0).name), liney, hostNodeDrawingInstructions.get(n.parents.get(0).name));
            }
        }

        timedTreeLocation whereOnTree(int x, int y) {
            int time;
            for (time = timeEvents.firstKey(); time <= timeEvents.lastKey(); time++) {
                if (xPos.get(time) > x) {
                    break;
                }
            }
            if (time > timeEvents.lastKey()) {
                return null;
            }

            if (time != timeEvents.lastKey()) {
                node n = hostTree.nodeAtTime(time);
                if (!n.Root()) {
                    if (x >= xPos.get(time) - eventWidth / 2 && y >= lineY.get(n.children.get(0).name) && y <= lineY.get(n.children.get(1).name)) {
                        return new timedTreeLocation(n, time);
                    }
                }
            }

            Vector<edge> activeEdges = hostTree.liveEdges(time);
            for (edge e : activeEdges) {
                if (y >= lineY.get(e.second.name) - laneHeight && y <= lineY.get(e.second.name) + laneHeight) {
                    return new timedTreeLocation(e, time);
                }
            }

            return null;
        }
    }

    class ParasiteNode extends javax.swing.JComponent implements java.awt.event.MouseListener, java.awt.event.MouseMotionListener {

        private int sideLength = 8;
        private int bestCost;
        private DrawingAssociation myAssoc;
        public boolean dragging = false;
        private java.awt.Color borderColor;

        public int getSideLength() {
            return sideLength;
        }

        public void setSideLength(int sideLength) {
            this.sideLength = sideLength;
            this.setPreferredSize(new java.awt.Dimension(sideLength + 2, sideLength + 2));
            this.setSize(this.getPreferredSize());
        }

        public ParasiteNode(DrawingAssociation asc) {
            this.setPreferredSize(new java.awt.Dimension(sideLength + 2, sideLength + 2));
            this.setSize(this.getPreferredSize());
            myAssoc = asc;
            this.setToolTipText(asc.parasite.fancyName);
            this.addMouseListener(this);
            this.addMouseMotionListener(this);
            borderColor = findBorderColor();
        }

        @Override
        public void paint(Graphics g) {
            java.awt.Graphics2D gp = (java.awt.Graphics2D) g;
            gp.setColor(borderColor);
            gp.fillOval(0, 0, sideLength, sideLength);
            if (myAssoc.type == Association.AssociationType.COSPECIATION) {
                gp.setColor(gp.getBackground());
                gp.fillOval(2, 2, sideLength - 4, sideLength - 4);
            }
        }

        java.awt.Color findBorderColor() {
            return Color.BLUE;
        }

        public void mouseClicked(MouseEvent e) {
        }

        void colorHostAssoc(Association assoc, EdgeDrawingInstruction inst) {
            if (assoc.associate instanceof edge) {
                hostEdgeTimeDrawingInstructions.get(((edge) assoc.associate).second.name).put(assoc.time, inst);
            } else {
                hostNodeDrawingInstructions.put(((node) assoc.associate).name, inst);
            }
        }

        void colorHost(timedTreeLocation loc, EdgeDrawingInstruction inst) {
            if (loc.loc instanceof edge) {
                hostEdgeTimeDrawingInstructions.get(((edge) loc.loc).second.name).put(loc.time, inst);
            } else {
                hostNodeDrawingInstructions.put(((node) loc.loc).name, inst);
            }
        }

        /*
         * When the mouse is pressed, we color the host tree to represent
         * the cost of moving the association there.
         */
        public void mousePressed(MouseEvent e) {
        }

        public void mouseReleased(MouseEvent e) {
        }

        /*
         * Colors all edges incident to the association to a particular
         * color. For a tip, it colors the entire path up to the root.
         */
        void setLocalDrawingInstruction(EdgeDrawingInstruction instruction) {
            parentDrawingInstructions.put(myAssoc.parasite.name, instruction);
            if (myAssoc.AChild1 != null) {
                parentDrawingInstructions.put(myAssoc.AChild1.parasite.name, instruction);
            }
            if (myAssoc.AChild2 != null) {
                parentDrawingInstructions.put(myAssoc.AChild2.parasite.name, instruction);
            }

            if (myAssoc.parasite.Tip()) {
                DrawingAssociation parent = myAssoc.parent;
                while (parent != null) {
                    parentDrawingInstructions.put(parent.parasite.name, instruction);
                    parent = parent.parent;
                }
            }
            this.getParent().repaint();
        }

        public void mouseEntered(MouseEvent e) {
            setLocalDrawingInstruction(EdgeDrawingInstruction.BLUE_THICK);
        }

        public void mouseExited(MouseEvent e) {
            if (!dragging) {
                setLocalDrawingInstruction(EdgeDrawingInstruction.BLUE_THIN);
            }
        }

        public void mouseDragged(MouseEvent e) {
        }

        EdgeDrawingInstruction unOutlined(EdgeDrawingInstruction orig) {
            if (orig == EdgeDrawingInstruction.GREEN_OUTLINED) {
                return EdgeDrawingInstruction.GREEN_THICK;
            }
            if (orig == EdgeDrawingInstruction.RED_OUTLINED) {
                return EdgeDrawingInstruction.RED_THICK;
            }
            if (orig == EdgeDrawingInstruction.YELLOW_OUTLINED) {
                return EdgeDrawingInstruction.YELLOW_THICK;
            }

            return EdgeDrawingInstruction.BLACK_THICK;
        }

        EdgeDrawingInstruction getOutlined(EdgeDrawingInstruction original) {
            if (original.color == Color.GREEN) {
                return EdgeDrawingInstruction.GREEN_OUTLINED;
            } else if (original.color == Color.YELLOW) {
                return EdgeDrawingInstruction.YELLOW_OUTLINED;
            } else if (original.color == Color.RED) {
                return EdgeDrawingInstruction.RED_OUTLINED;
            } else {
                return EdgeDrawingInstruction.BLACK_THICK;
            }
        }

        public void mouseMoved(MouseEvent e) {
        }
    }

    class timedTreeLocation {

        treeLocation loc;
        int time;

        timedTreeLocation(treeLocation loc, int time) {
            this.loc = loc;
            this.time = time;
        }
    }

    /*
     * Saves the timing
     */
    void saveItemActionPerformed(java.awt.event.ActionEvent evt) {
        int saveResult = saveFile.showSaveDialog(this);
        if (saveResult == javax.swing.JFileChooser.APPROVE_OPTION) {
            try {
                java.io.FileWriter fw = new java.io.FileWriter(saveFile.getSelectedFile());
                fw.write(hostTree.fileTimingString());
                fw.close();
            } catch (java.io.IOException e) {
                JOptionPane.showMessageDialog(this, "Unable to write to the specified filename", "Error Writing File", JOptionPane.ERROR_MESSAGE);
                System.err.println(e);
            }
        }
    }

    void closeItemActionPerformed(java.awt.event.ActionEvent evt) {
        this.setVisible(false);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        mainMenu = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu("File");
        saveItem = new javax.swing.JMenuItem("Save Timing");
        sep1 = new javax.swing.JSeparator();
        closeItem = new javax.swing.JMenuItem("Close");

        mainMenu.add(fileMenu);
        fileMenu.add(saveItem);
        fileMenu.add(sep1);
        fileMenu.add(closeItem);
        this.setJMenuBar(mainMenu);

        saveItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));

        saveItem.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveItemActionPerformed(evt);
            }
        });

        closeItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W, InputEvent.CTRL_DOWN_MASK));
        closeItem.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeItemActionPerformed(evt);
            }
        });

        saveFile = new javax.swing.JFileChooser();

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING).add(0, 400, Short.MAX_VALUE));
        layout.setVerticalGroup(
                layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING).add(0, 300, Short.MAX_VALUE));

        pack();
    }// </editor-fold>
    // Variables declaration - do not modify
    private javax.swing.JMenuBar mainMenu;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenuItem saveItem;
    private javax.swing.JSeparator sep1;
    private javax.swing.JMenuItem closeItem;
    private javax.swing.JFileChooser saveFile;
    // End of variables declaration

    static TreeFileReader.ProblemInstance readTree(String path) {

        TreeFileReader nr = null;
        try {
            nr = new NexusFileReader(path);
            if (!((NexusFileReader) nr).isNexus()) {
                nr = new TarzanFileReader(path);
            }
        } catch (java.io.FileNotFoundException e) {
            System.out.println("The file " + path + " does not exist.");
            return null;
        } catch (java.io.IOException e) {
            System.out.println("Error reading file " + path);
            return null;
        }
        try {
            return nr.readProblem();
        } catch (FileFormatException e) {
            System.out.println("Error reading file " + path);
        } catch (java.io.IOException e) {
            System.out.println("Error reading file " + path);
            return null;
        }
        return null;
    }

    static pNetwork readTiming(TreeFileReader.ProblemInstance prob, String path) {
        pNetwork hostTree = null;
        try {
            hostTree = loadTimingFile(new java.io.File(path), prob);
        } catch (java.io.FileNotFoundException f) {
            System.out.println("We were not able to open the requested timing file : " + f.getLocalizedMessage());
        } catch (java.io.IOException ix) {
            System.out.println("An error occurred while trying to read the file: " + ix.getLocalizedMessage());
        }
        return hostTree;
    }

    static pNetwork loadTimingFile(java.io.File f, TreeFileReader.ProblemInstance prob) throws java.io.FileNotFoundException, java.io.IOException {
        java.io.BufferedReader fin = new java.io.BufferedReader(new java.io.FileReader(f));
        pNetwork hostTree = new pNetwork(prob.host, prob.hostRanks, prob.hostNames, prob.regionCosts, prob.hostRegions);
        hostTree.initializeCounters();
        String s;
        while ((s = fin.readLine()) != null) {
            String[] vals = s.split(",");
            if (vals.length == 3) {
                int host = Integer.parseInt(vals[0]);
                int time = Integer.parseInt(vals[1]);
                int zone = Integer.parseInt(vals[2]);

                if (!hostTree.nodes.containsKey(host)) {
                    System.out.println("This file does not match the current tree");
                    return null;
                }

                node h = hostTree.nodes.get(host);
                h.time = time;
                h.zone = zone;
            }
        }

        int finalTime = hostTree.tips().get(0).time;
        java.util.Iterator<Integer> it = hostTree.zoneList.keySet().iterator();
        int currentZone = it.next();
        for (int i = 0; i <= finalTime; i++) {
            while (hostTree.nodeAtTime(i).timeZones.firstElement() > currentZone) {
                hostTree.zoneTimes.put(currentZone, i - 1);
                currentZone = it.next();
            }
            hostTree.nodeAtTime(i).zone = currentZone;
        }
        hostTree.zoneTimes.put(currentZone, finalTime);
        while (it.hasNext()) {
            hostTree.zoneTimes.put(it.next(), finalTime);
        }

        if (!hostTree.checkConsistency()) {
            System.out.println("The timing specified was not consistent with some of the information on the host tree");
            return null;
        }

        return hostTree;
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new viewerInvoker(args));
    }

    static class viewerInvoker implements Runnable {
        static int costs[] = {0, 1, 1, 2};
        static String treeFile = null;
        static String timingFile = null;
        static boolean verbose = false;
        static boolean tarzan = false;
        static int switchDist = -1;
        static String outputFile = null;

        static void usage() {
            System.err.println("usage: java SimpleViewer [-V] [-c {Cospeciation,Duplication,Switch,Loss}] [-T] [-S max_switch_distance] [-o outputFile] treeFile timingFile");
            System.exit(1);
        }

        static void readArgs(String[] args) {
            int index = 0;

            while (index < args.length) {
                if ("-c".equals(args[index])) {
                    index++;
                    costs = new int[4];
                    for (int i = 0; i < 4; ++i) {
                        try {
                            costs[i] = Integer.parseInt(args[index]);
                        } catch (NumberFormatException e) {
                            System.err.println("The -c flag must be followed with 4 integers representing the costs of various operations.");
                            usage();
                        }
                        index++;
                    }
                } else if ("-o".equals(args[index])) {
                    index++;
                    outputFile = args[index];
                    index++;
                } else if ("-V".equals(args[index])) {
                    index++;
                    verbose = true;
                } else if ("-T".equals(args[index])) {
                    index++;
                    tarzan = true;
                } else if ("-S".equals(args[index])) {
                    index++;
                    try {
                        switchDist = Integer.parseInt(args[index]);
                    } catch (NumberFormatException e) {
                        System.err.println("The argument following -S must be an integer");
                        usage();
                    }
                } else if (args[index].startsWith("-")) {
                    System.err.println("Unrecognized command-line switch: " + args[index]);
                    usage();
                } else {
                    break;
                }
            }

            if (index == args.length - 2) {
                treeFile = args[index];
                timingFile = args[index+1];
            } else if (index >= args.length) {
                System.err.println("Not enough filenames provided");
                usage();
            } else {
                System.err.println("Unexpected arguments after the filename");
                usage();
            }
            return;
        }

        public viewerInvoker(String[] args) {
            readArgs(args);
        }

        public void run(){
            if(treeFile == null)
                return;
            TreeFileReader.ProblemInstance prob = readTree(treeFile);
            pNetwork hostTree = readTiming(prob, timingFile);
            Solver s = new Solver(hostTree, new pNetwork(prob.parasite, prob.parasiteRanks, prob.parasiteNames), prob.phi, costs, switchDist);
            System.out.println("Started solving");
            double cost = s.solve();
            System.out.println("Finish solving");
            if(outputFile != null)
            {
                SimpleViewer v = new SimpleViewer(s.bestAssoc, hostTree);
                BufferedImage bi = new BufferedImage(5000, 5000, BufferedImage.TYPE_INT_ARGB);
                Graphics g = bi.getGraphics();
                g.setColor(Color.WHITE);
                g.fillRect(0, 0, 5000, 5000);
                v.getContentPane().setSize(5000, 5000);
                v.getContentPane().paint(g);
		File f = new File(outputFile + ".png");
                try
                {
                    ImageIO.write(bi, "png", f);
                }
                catch(java.io.IOException e)
                {
                    System.out.println(e);
                }
                System.exit(0);
            }
            else
            {
                new SimpleViewer(s.bestAssoc, hostTree).setVisible(true);
            }
        }
    }
}
