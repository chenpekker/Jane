/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of the Harvey Mudd College nor the names of its
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * An association represents a mapping of a parasite vertex onto a vertex or edge of the host tree
 */
public class Association
{

    /*
     * Lists the different types of associations that are possible.
     * Losses are implied in the default implementation of Association, but
     * are included for completeness.
     */
    public enum AssociationType
    {

        HOST_SWITCH("Host Switch"),
        COSPECIATION("Cospeciation"),
        DUPLICATION("Duplication"),
        TIP("Tip"),
        LOSS("Loss");

        AssociationType(String name)
        {
            this.name = name;
        }
        private final String name;

        public String toString()
        {
            return name;
        }
    }


    // Computes total events by adding the events in child sub-trees
    protected void countEvents(pNetwork hostTree)
    {
        eventCounts = new int[4];

        if(AChild1 != null && AChild1.eventCounts == null)
            AChild1.countEvents(hostTree);
        if(AChild2 != null && AChild2.eventCounts == null)
            AChild2.countEvents(hostTree);

        for(int i = 0; i < 4; i++)
            eventCounts[i] = 0;

        if (AChild1 != null)
        {
            for (int i = 0; i < 4; i++)
            {
                eventCounts[i] += AChild1.eventCounts[i];
            }
        }
        if (AChild2 != null)
        {
            for (int i = 0; i < 4; i++)
            {
                eventCounts[i] += AChild2.eventCounts[i];
            }
        }

        switch (type)
        {
            case HOST_SWITCH:
                eventCounts[Solver.SWITCH]++;
                break;
            case DUPLICATION:
                eventCounts[Solver.DUPLICATION]++;
                break;
            case COSPECIATION:
                eventCounts[Solver.COSPECIATION]++;
                break;
            case LOSS:
                eventCounts[Solver.LOSS]++;
        }
        switch(type)
        {
            case HOST_SWITCH:
                eventCounts[Solver.LOSS] += Math.min(hostTree.distance(associate, AChild1.associate) + hostTree.distance(switchTarget, AChild2.associate),
                                                 hostTree.distance(associate, AChild2.associate) + hostTree.distance(switchTarget, AChild1.associate));
                break;
            case COSPECIATION:
                node nodeAssociate = (node)associate;
                node child1 = nodeAssociate.children.get(0);
                node child2 = nodeAssociate.children.get(1);
                eventCounts[Solver.LOSS] += Math.min(hostTree.distance(new edge(nodeAssociate, child1), AChild1.associate) +
                                                     hostTree.distance(new edge(nodeAssociate, child2), AChild2.associate),
                                                     hostTree.distance(new edge(nodeAssociate, child2), AChild1.associate) +
                                                     hostTree.distance(new edge(nodeAssociate, child1), AChild2.associate));
                break;
            case DUPLICATION:
                eventCounts[Solver.LOSS] += hostTree.distance(associate, AChild1.associate) + hostTree.distance(associate, AChild2.associate);
        }
    }

    //This association constructor is for non-host-switch associations
    public Association(AssociationType type, node parasite, treeLocation associate, int time, int cost, Association child1, Association child2)
    {
        this.type = type;
        assert (type != AssociationType.HOST_SWITCH);
        this.parasite = parasite;
        this.associate = associate;
        this.time = time;
        this.cost = cost;
        this.AChild1 = child1;
        this.AChild2 = child2;
    }

    //this constructor is for host-switches, since they have extra information about the switch's target
    public Association(AssociationType type, node parasite, treeLocation associate, treeLocation switchTarget, int time, int cost, Association child1, Association child2)
    {
        this.type = type;
        assert (this.type == AssociationType.HOST_SWITCH);
        this.parasite = parasite;
        this.associate = associate;
        this.switchTarget = switchTarget;
        this.time = time;
        this.cost = cost;
        this.AChild1 = child1;
        this.AChild2 = child2;
    }

    public String toString()
    {
        return "Parasite Node: " + parasite.fancyName + "\nAssociation type: " + type + "\nHost: " + associate + (switchTarget == null ? "" : "\nSwitch Target: " + switchTarget) + "\nEvent Time: " + time + "\nCost: " + cost;
    }

    public boolean isDistinct(Association other){
        if(!other.type.equals(this.type) || !other.associate.equals(this.associate))
            return true;
        else if(other.type.equals(AssociationType.HOST_SWITCH) && !other.switchTarget.equals(this.switchTarget))
            return true;
        return false;
    }

    //The type of event
    AssociationType type;
    //The parasite being associated
    node parasite;
    //The location on the host tree where the event occurs
    treeLocation associate;
    //The target of a host switch. This will be null on non-host-switch events
    treeLocation switchTarget;
    //The time at which the event occurs
    int time;
    //The cost of the event, plus the costs of all child events associated with it
    int cost;
    //The associations for the children of the parasite node
    Association AChild1;
    Association AChild2;

    //Counts how many of each event type have occurred in this association
    //This stays null until someone asks us to compute it
    int[] eventCounts = null;
};
