/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of the Harvey Mudd College nor the names of its
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//GEN-LINE:initComponents
import java.awt.Color;
import java.awt.Font;

/*
 * SolutionViewer.java
 *
 * Created on Jul 28, 2009, 9:56:53 AM
 */
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.Map;
import java.util.HashMap;
import java.util.Vector;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Comparator;
import java.util.Collections;
import javax.swing.KeyStroke;
import javax.swing.JOptionPane;

/**
 *
 * @author dfielder
 */
public class SolutionViewer extends javax.swing.JFrame {

    private enum DrawLocation {

        TOP, BOTTOM, OTHER
    };

    private static class EdgeDrawingInstruction {
        static final EdgeDrawingInstruction BLACK_THIN = new EdgeDrawingInstruction(false, Color.BLACK);
        static final EdgeDrawingInstruction BLACK_THICK = new EdgeDrawingInstruction(true, Color.BLACK);
        static final EdgeDrawingInstruction BLUE_THIN = new EdgeDrawingInstruction(false, Color.BLUE);
        static final EdgeDrawingInstruction BLUE_THICK = new EdgeDrawingInstruction(true, Color.BLUE);
        static final EdgeDrawingInstruction GREEN_THIN = new EdgeDrawingInstruction(false, Color.GREEN);
        static final EdgeDrawingInstruction GREEN_THICK = new EdgeDrawingInstruction(true, Color.GREEN);
        static final EdgeDrawingInstruction GREEN_OUTLINED = new EdgeDrawingInstruction(true, Color.GREEN, Color.BLACK);
        static final EdgeDrawingInstruction RED_THIN = new EdgeDrawingInstruction(false, Color.RED);
        static final EdgeDrawingInstruction RED_THICK = new EdgeDrawingInstruction(true, Color.RED);
        static final EdgeDrawingInstruction RED_OUTLINED = new EdgeDrawingInstruction(true, Color.RED, Color.BLACK);
        static final EdgeDrawingInstruction YELLOW_THIN = new EdgeDrawingInstruction(false, Color.YELLOW);
        static final EdgeDrawingInstruction YELLOW_THICK = new EdgeDrawingInstruction(true, Color.YELLOW);
        static final EdgeDrawingInstruction YELLOW_OUTLINED = new EdgeDrawingInstruction(true, Color.YELLOW, Color.BLACK);

        boolean thick;
        boolean outlined;
        java.awt.Color color;
        java.awt.Color outlineColor;

        EdgeDrawingInstruction(boolean thick, java.awt.Color color) {
            this.thick = thick;
            this.color = color;
            this.outlined = false;
        }
        EdgeDrawingInstruction(boolean thick, java.awt.Color color, java.awt.Color outlineColor)
        {
            this.thick = thick;
            this.color = color;
            this.outlined = true;
            this.outlineColor = outlineColor;
        }
    }
    private SortedMap<Integer, Vector<DrawingAssociation>> timeEvents = new TreeMap<Integer, Vector<DrawingAssociation>>();
    private Map<Integer, Vector<DrawingAssociation>> incidentAssociations = new HashMap<Integer, Vector<DrawingAssociation>>();
    private Map<Integer, Vector<DrawingAssociation>> previousEdgeEvents = new HashMap<Integer, Vector<DrawingAssociation>>();
    private Map<Integer, ParasiteNode> pNodes = new HashMap<Integer, ParasiteNode>();
    private Map<Integer, EdgeDrawingInstruction> parentDrawingInstructions = new HashMap<Integer, EdgeDrawingInstruction>();
    private DrawingAssociation solution;
    private pNetwork hostTree;
    private Map<Integer, Map<Integer, EdgeDrawingInstruction>> hostEdgeTimeDrawingInstructions = new HashMap<Integer, Map<Integer, EdgeDrawingInstruction>>();
    private Map<Integer, EdgeDrawingInstruction> hostNodeDrawingInstructions = new HashMap<Integer, EdgeDrawingInstruction>();
    private Map<Integer, MultiAssociation> multiAssocs = new HashMap<Integer, MultiAssociation>();
    private Vector<MultiAssociation> alternateRoots = new Vector<MultiAssociation>();
    /**
     * Creates a new viewer frame to view solutions to cophylogeny problems.
     * hostTree and solution must both come from the same Solver instance.
     * @param solution
     * @param hostTree
     */
    public SolutionViewer(MultiAssociation solution, pNetwork hostTree, Vector<MultiAssociation> alternateRoots) {
        fillMultiAssocs(solution);
        this.setTitle("Solution Viewer Cost: "+solution.cost);
        this.solution = DrawingAssociation.constructDrawingAssociation(solution, hostTree);
        this.hostTree = hostTree;
        this.alternateRoots = alternateRoots;
        this.setContentPane(new SolutionPane());
        this.assignPNodes(this.solution);
        this.assignHostDrawing();
    }

    private void reloadAssociations(MultiAssociation solution)
    {
        timeEvents.clear();
        incidentAssociations.clear();
        previousEdgeEvents.clear();
        pNodes.clear();
        parentDrawingInstructions.clear();
        hostEdgeTimeDrawingInstructions.clear();
        hostNodeDrawingInstructions.clear();
        multiAssocs.clear();

        this.setTitle("Solution Viewer Cost: "+solution.cost);

        fillMultiAssocs(solution);
        this.solution = DrawingAssociation.constructDrawingAssociation(solution, hostTree);

        ((SolutionPane)this.getContentPane()).associateEvents();
        this.getContentPane().removeAll();
        this.assignPNodes(this.solution);
        this.assignHostDrawing();
    }

    private void fillMultiAssocs(MultiAssociation soln)
    {
        multiAssocs.put(soln.parasite.name, soln);
        if(soln.AChild1 != null)
            fillMultiAssocs((MultiAssociation)soln.AChild1);
        if(soln.AChild2 != null)
            fillMultiAssocs((MultiAssociation)soln.AChild2);
    }

    void assignHostDrawing()
    {
        for(node n:hostTree.nodes.values())
        {
            hostNodeDrawingInstructions.put(n.name, EdgeDrawingInstruction.BLACK_THICK);
            if(n.Root())
                continue;
            hostEdgeTimeDrawingInstructions.put(n.name, new HashMap<Integer, EdgeDrawingInstruction>());
            for(int time = n.parents.get(0).time; time <= n.time; time++)
                hostEdgeTimeDrawingInstructions.get(n.name).put(time, EdgeDrawingInstruction.BLACK_THICK);
        }
    }

    /*
     * Creates PNodes for all each event in the association tree.
     * These will be dots placed at each event.
     */
    void assignPNodes(DrawingAssociation asc) {
        if (asc.type != Association.AssociationType.LOSS) {
            ParasiteNode pn = new ParasiteNode(asc);
            pn.setVisible(false);
            pNodes.put(asc.parasite.name, pn);
            this.getContentPane().add(pn);
            parentDrawingInstructions.put(asc.parasite.name, EdgeDrawingInstruction.BLUE_THIN);
        }

        if (asc.AChild1 != null) {
            assignPNodes((DrawingAssociation)asc.AChild1);
        }
        if (asc.AChild2 != null) {
            assignPNodes((DrawingAssociation)asc.AChild2);
        }
    }

    /*
     * the JPanel which draws the host and parasite trees as its background
     */
    private class SolutionPane extends javax.swing.JPanel {

        Map<Integer, Integer> heights = new HashMap<Integer, Integer>();
        SortedMap<Integer, Integer> xPos = new TreeMap<Integer, Integer>();
        Map<Integer, Integer> lineY = new TreeMap<Integer, Integer>();
        private final int spacingBelow = 1;
        private final int nodeSize = 5;
        private int timeZoneHeight = 50;
        private int laneHeight = 8;
        private int eventWidth = 10;
        private int textHeight = 12;
        private boolean ready = false;
        private int assocCount = 0;
        private int maxLanesRequired;
        private int totalEvents;

        /* This is a one-time method that takes solution and puts it into all the
         * data structures used to draw it.
         */
        void associateEvents() {
            ready = false;
            heights.clear();
            xPos.clear();
            lineY.clear();

            for (node n : hostTree.nodes.values()) {
                incidentAssociations.put(n.name, new Vector<DrawingAssociation>());
                previousEdgeEvents.put(n.name, new Vector<DrawingAssociation>());
            }

            int tiptime = hostTree.tips().get(0).time;
            for (int i = 0; i <= tiptime; ++i) {
                timeEvents.put(i, new Vector<DrawingAssociation>());
            }

            mapAssociation(solution);

            assocCount = 0;
            timeMapAssociation(solution);

            for (Vector<DrawingAssociation> da : timeEvents.values())
            {
                Collections.sort(da, new Comparator<DrawingAssociation>(){
                    public int compare(DrawingAssociation da1, DrawingAssociation da2)
                    {
                        int da1type, da2type;
                        if(da1.type == Association.AssociationType.DUPLICATION || da1.type == Association.AssociationType.HOST_SWITCH)
                        {
                            da1type = 1;
                        }
                        else
                        {
                            da1type = 2;
                        }
                        if(da2.type == Association.AssociationType.DUPLICATION || da2.type == Association.AssociationType.HOST_SWITCH)
                        {
                            da2type = 1;
                        }
                        else
                        {
                            da2type = 2;
                        }
                        if(da1type != da2type)
                        {
                            return da1type - da2type;
                        }
                        else
                        {
                            return da1.parasite.timeZones.firstElement() - da2.parasite.timeZones.firstElement();
                        }
                    }
                });
            }

            assignLanes();

            //pad for the beginning of time
            totalEvents = 1;
            for (Map.Entry<Integer, Vector<DrawingAssociation>> va : timeEvents.entrySet()) {
                totalEvents += va.getValue().size() + 1;
            }

            totalEvents -= (assocCount + 1) / 2;

            laneHeight = 1;
            calculateHeightAndY(hostTree.root(), 0);
            int maxy = 0;
            for (Integer n : lineY.values()) {
                maxy = Math.max(maxy, n);
            }
            maxLanesRequired = (maxy + 1);

            ready = true;
        }

        /*
         * In order to draw parasite lineages tracking down a host lineage, each
         * parasite lineage is assigned a lane. This method calculates lane assignments.
         */
        void assignLanes() {
            for (Integer n : incidentAssociations.keySet()) {
                Vector<DrawingAssociation> incident = incidentAssociations.get(n);
                Vector<DrawingAssociation> edge = previousEdgeEvents.get(n);

                for (int i = 0; i < incident.size(); i++) {
                    incident.get(i).lane = i + 1;
                }

                for (int i = edge.size() - 1; i >= 0; --i) {
                    DrawingAssociation asc = edge.get(i);

                    if (asc.type == Association.AssociationType.DUPLICATION) {
                        asc.lane = ((DrawingAssociation) asc.AChild1).lane;
                    } else if (asc.type == Association.AssociationType.HOST_SWITCH && ((edge) asc.associate).second.name == n) {
                        if (hostTree.descendant(asc.associate, asc.AChild1.associate)) {
                            asc.lane = ((DrawingAssociation) asc.AChild1).lane;
                        } else {
                            asc.lane = ((DrawingAssociation) asc.AChild2).lane;
                        }
                    }
                }
            }
        }

        /*
         * Puts each association into the appropriate slot of timeEvents.
         * Also, assigns parents on drawingAssociations.
         */
        void timeMapAssociation(DrawingAssociation assoc) {
            if (assoc.type != Association.AssociationType.LOSS) {
                assocCount++;
            }
            timeEvents.get(assoc.time).add(assoc);
            if (assoc.AChild1 != null) {
                timeMapAssociation((DrawingAssociation) assoc.AChild1);
                ((DrawingAssociation) assoc.AChild1).parent = assoc;
            }
            if (assoc.AChild2 != null) {
                timeMapAssociation((DrawingAssociation) assoc.AChild2);
                ((DrawingAssociation) assoc.AChild2).parent = assoc;
            }
        }

        /* Places each association into incidentAssociations or
         * previousEdgeEvents for its host, as appropriate.
         */
        void mapAssociation(DrawingAssociation assoc) {
            switch (assoc.type) {
                case COSPECIATION:
                    incidentAssociations.get(((node) assoc.associate).name).add(assoc);
                    mapAssociation((DrawingAssociation) assoc.AChild1);
                    mapAssociation((DrawingAssociation) assoc.AChild2);
                    break;
                case LOSS:
                    incidentAssociations.get(((node) assoc.associate).name).add(assoc);
                    mapAssociation((DrawingAssociation) assoc.AChild1);
                    break;
                case HOST_SWITCH:
                    previousEdgeEvents.get(((edge) assoc.associate).second.name).add(assoc);
                    previousEdgeEvents.get(((edge) assoc.switchTarget).second.name).add(assoc);
                    mapAssociation((DrawingAssociation) assoc.AChild1);
                    mapAssociation((DrawingAssociation) assoc.AChild2);
                    break;
                case DUPLICATION:
                    previousEdgeEvents.get(((edge) assoc.associate).second.name).add(assoc);
                    mapAssociation((DrawingAssociation) assoc.AChild1);
                    mapAssociation((DrawingAssociation) assoc.AChild2);
                    break;
                case TIP:
                    incidentAssociations.get(((node) assoc.associate).name).add(assoc);
                    break;
            }
        }


        /*
         * This method scales the x and y values assigned to components of the
         * tree to fit the current window size.
         */
        void scale(java.awt.Graphics g) {
            if (hostTree.zoneList.size() > 1) {
                laneHeight = (getHeight() - timeZoneHeight) / maxLanesRequired;
            } else {
                laneHeight = getHeight() / maxLanesRequired;
            }

            resizeFont(g, laneHeight);

            FontMetrics fm = g.getFontMetrics();

            int maxTextWidth = 0;
            for (DrawingAssociation assoc : timeEvents.get(timeEvents.lastKey())) {
                if (assoc.type == Association.AssociationType.TIP) {
                    maxTextWidth = Math.max(maxTextWidth, fm.stringWidth(assoc.parasite.fancyName));
                }
            }

            for (node n : hostTree.tips()) {
                maxTextWidth = Math.max(maxTextWidth, fm.stringWidth(n.fancyName));
            }

            eventWidth = (getWidth() - (maxTextWidth + nodeSize/2 + 1)) / totalEvents;
            calculateXPos();

            calculateHeightAndY(hostTree.root(), 0);
        }

        /*
         * Calculates the y value for the horizontal line representing a host
         * vertex. It also recursively calculates y values for descendants.
         */
        void calculateHeightAndY(node n, int y) {
            int liney;
            int height;
            if (n.Tip()) {
                height = (spacingBelow + 1 + incidentAssociations.get(n.name).size()) * laneHeight;
                liney = y + height - spacingBelow * laneHeight;
            } else {
                calculateHeightAndY(n.children.get(0), y);
                int child0y = lineY.get(n.children.get(0).name);
                liney = Math.max(y + heights.get(n.children.get(0).name), child0y + incidentAssociations.get(n.name).size() * laneHeight);
                //height = Math.max((1 + incidentAssociations.get(n.name).size()) * laneHeight, heights.get(n.children.get(0).name));
                height = liney - y;

                for (int i = 1; i < n.children.size(); i++) {
                    calculateHeightAndY(n.children.get(i), liney);
                    height += heights.get(n.children.get(i).name);
                }
            }
            heights.put(n.name, height);
            lineY.put(n.name, liney);
            //System.out.println(n.name +","+ liney);
            //return liney;
        }

        /*
         * Calculates the x position of every parasite association and host tree
         * node.
         */
        void calculateXPos() {
            //pad for the beginning of time
            int x = eventWidth;
            for (Integer i : timeEvents.keySet()) {
                //first assign stuff that goes on edges
                for (DrawingAssociation asc : timeEvents.get(i)) {
                    if (asc.type == Association.AssociationType.DUPLICATION || asc.type == Association.AssociationType.HOST_SWITCH) {
                        x += eventWidth;
                        asc.x = x;
                    }
                }
                //then assign stuff that goes on the vertex
                for (DrawingAssociation asc : timeEvents.get(i)) {
                    if (asc.type == Association.AssociationType.LOSS || asc.type == Association.AssociationType.COSPECIATION) {
                        x += eventWidth;
                        asc.x = x;
                    }
                }
                //finally assign the host vertex
                x += eventWidth;

                xPos.put(i, x);

                for (DrawingAssociation asc : timeEvents.get(i)) {
                    if (asc.type == Association.AssociationType.TIP) {
                        asc.x = x;
                    }
                }
            }
            //Special case the x position for the root to 0
            xPos.put(timeEvents.firstKey(), 0);

            if (eventWidth * totalEvents != x) {
                System.out.println("Event Counting Error!");
            }
        }

        /*
         * Scales the font on a graphics object to a specified height
         */
        void resizeFont(Graphics g, int h) {
            FontMetrics fm = g.getFontMetrics();
            int curH = fm.getHeight();
            Font curF = g.getFont();
            float size = curF.getSize2D();
            while (curH > h && size > 8) {
                size -= 0.1f;
                curF = curF.deriveFont(size);
                fm = g.getFontMetrics(curF);
                curH = fm.getHeight();
            }
            textHeight = curH;
            g.setFont(curF);
        }

        /** Creates new SolutionPane */
        SolutionPane() {
            initComponents();
            this.setLayout(null);
            associateEvents();
            validate();
            repaint();
        }

        /*
         * Draws the tree
         */
        @Override
        public void paintComponent(java.awt.Graphics g) {
            if (ready) {
                g.clearRect(0, 0, getWidth(), getHeight());
                scale(g);

                drawNode(g, hostTree.root(), 0, 0, DrawLocation.OTHER);
                //now, add a leading edge to the parasite tree
                node solutionAssoc = getAssociateNode(solution);
                drawHorizLine(g, getY(solution),
                        solution.x,xPos.get(solutionAssoc.parents.get(0).time),
                        parentDrawingInstructions.get(solution.parasite.name));

                if (hostTree.zoneList.size() > 1) {
                    drawTimeZones(g);
                }
            }
        }

        /*
         * Draws labels for time zones onto the bottom of the tree
         */
        void drawTimeZones(Graphics g) {
            g.setFont(g.getFont().deriveFont(13.0f));
            g.setColor(Color.BLACK);

            int startX = 0;
            int endX = 0;
            int currentZone = hostTree.zoneList.firstKey();
            int nextZone;
            int parX;

            SortedSet<Integer> s = new TreeSet<Integer>();
            for (Integer i : timeEvents.keySet()) {
                s = new TreeSet<Integer>();
                parX = xPos.get(i);
                nextZone = hostTree.nodeAtTime(i).zone;
                int prevZone = currentZone; // used later to determine if the last
                                            // time zone only has tips

                // this loop sets things up for the case in which parasite
                // nodes occur in a time zone between two consecutive
                // host time zones
                for(DrawingAssociation d : timeEvents.get(i)){
                    if(!d.type.equals(Association.AssociationType.LOSS)){
                        for(Integer j : d.parasite.timeZones){
                            if(j > currentZone && j < nextZone){
                            s.add(j);
                            if(d.x < parX)
                                parX = d.x;
                            }
                            break;
                        }
                    }
                }

                // draws the section for the current time zone
                if (hostTree.nodeAtTime(i).zone != currentZone || i.equals(timeEvents.lastKey())) {
                    if(s.isEmpty()){
                        endX = xPos.get(i);
                        if (currentZone != hostTree.tips().get(0).zone)
                            endX -= eventWidth / 2;
                        if (i != timeEvents.lastKey())
                            endX -= incidentAssociations.get(hostTree.nodeAtTime(i).name).size() * eventWidth;
                    }
                    else
                        endX = parX - eventWidth / 2;

                    drawTimeZone(g, currentZone + "", startX, endX);

                    currentZone = hostTree.nodeAtTime(i).zone;
                    startX = endX;
                }

                // if there is a parasite only time zone, draw that one
                if(!s.isEmpty()){
                    endX = xPos.get(i) - eventWidth / 2;
                    if (!i.equals(timeEvents.lastKey()))
                        endX -= timeEvents.get(i + 1).size() * eventWidth;

                    if(currentZone != s.first()){
                        drawTimeZone(g, s.first() + "", startX, endX);
                        startX = endX;
                    }
                }

                // if the last time zone only has tips
                if(i.equals(timeEvents.lastKey()) && prevZone != currentZone){
                        drawTimeZone(g, currentZone + "", endX, xPos.get(i));
                }
            }
        }

        /*
         * Draws an individual time zone label
         */
        void drawTimeZone(Graphics g, String name, int startX, int endX) {
            int timezoneTextHeight = g.getFontMetrics().getHeight();
            int textWidth = g.getFontMetrics().stringWidth(name);

            g.drawString(name, (startX + endX) / 2 - textWidth / 2, getHeight() - timezoneTextHeight);
            g.drawLine(startX, getHeight() - timeZoneHeight * 4 / 5, endX, getHeight() - timeZoneHeight * 4 / 5);
            g.drawLine(startX, getHeight() - timeZoneHeight, startX, getHeight() - timeZoneHeight * 3 / 5);
            g.drawLine(endX, getHeight() - timeZoneHeight, endX, getHeight() - timeZoneHeight * 3 / 5);
        }
        
        /*
         * Gets the node associated with an association.
         * If the association is on an edge, it returns the end of that edge
         */
        node getAssociateNode(Association asc) {
            if (asc.associate.isEdge()) {
                return ((edge) asc.associate).second;
            } else {
                return (node) asc.associate;
            }
        }

        /*
         * Gets the y coordinate of the location of an association
         */
        int getY(DrawingAssociation asc) {
            return lineY.get(getAssociateNode(asc).name) - asc.lane * laneHeight;
        }

        /*
         * Draws an arrow
         */
        void drawArrow(java.awt.Graphics g, int x, int y, int width, int height, boolean up) {
            if (height < 4) {
                height = 4;
            }
            if (width < 4) {
                width = 4;
            }
            if (up) {
                g.drawLine(x - width / 2, y - height / 2, x, y + height / 2);
                g.drawLine(x + width / 2, y - height / 2, x, y + height / 2);
            } else {
                g.drawLine(x - width / 2, y + height / 2, x, y - height / 2);
                g.drawLine(x + width / 2, y + height / 2, x, y - height / 2);
            }
        }

        /*
         * Moves a PNode to a position
         */
        void placeNode(int parasite, int x, int y) {
            ParasiteNode pn = pNodes.get(parasite);
            if(pn.dragging)
                return;
            pn.setSideLength(nodeSize);
            pn.setLocation(x - nodeSize / 2, y - nodeSize / 2);
            pn.setVisible(true);
        }

        /*
         * Draws a vertical line while obeying EdgeDrawingInstructions
         */
        void drawVertLine(Graphics g, int x, int y1, int y2, EdgeDrawingInstruction instruction) {
            g.setColor(instruction.color);
            if (!instruction.thick) {
                g.drawLine(x, y1, x, y2);
            } else {
                g.fillRect(x, Math.min(y1, y2), 2, Math.abs(y1 - y2));
                if(instruction.outlined)
                {
                    g.setColor(instruction.outlineColor);
                    g.drawRect(x-1, Math.min(y1, y2)-1, 4, Math.abs(y1 - y2)+2);
                }
            }
        }

        /*
         * Draws a horizontal line while obeying EdgeDrawingInstructions
         */
        void drawHorizLine(Graphics g, int y, int x1, int x2, EdgeDrawingInstruction instruction) {
            g.setColor(instruction.color);
            if (!instruction.thick) {
                g.drawLine(x1, y, x2, y);
            } else {
                g.fillRect(Math.min(x1, x2), y - 1, Math.abs(x1 - x2), 2);
                if(instruction.outlined)
                {
                    g.setColor(instruction.outlineColor);
                    g.drawRect(Math.min(x1, x2)-1, y - 2, Math.abs(x1 - x2)+2, 4);
                }
            }
        }

        /*
         * Draws loss, cospeciation, and tip events
         */
        void drawIncidentAssociation(Graphics g, DrawingAssociation asc, node n) {
            int assocliney = getY(asc);
            switch (asc.type) {
                case TIP:
                    if (asc.time == timeEvents.lastKey()) {
                        g.drawString(asc.parasite.fancyName, asc.x + nodeSize/2+1, assocliney + textHeight / 2);
                    }

                    placeNode(asc.parasite.name, asc.x, assocliney);
                    break;
                case COSPECIATION:
                    int targety1 = getY((DrawingAssociation) asc.AChild1);
                    int targetx1 = ((DrawingAssociation) asc.AChild1).x;

                    int targety2 = getY((DrawingAssociation) asc.AChild2);
                    int targetx2 = ((DrawingAssociation) asc.AChild2).x;
                    placeNode(asc.parasite.name, asc.x, assocliney);
                    drawVertLine(g, asc.x, assocliney, targety1,parentDrawingInstructions.get(asc.AChild1.parasite.name));
                    drawHorizLine(g, targety1, asc.x, targetx1, parentDrawingInstructions.get(asc.AChild1.parasite.name));
                    drawVertLine(g, asc.x, assocliney, targety2, parentDrawingInstructions.get(asc.AChild2.parasite.name));
                    drawHorizLine(g, targety2, asc.x, targetx2, parentDrawingInstructions.get(asc.AChild2.parasite.name));
                    break;
                case LOSS:
                    int targety = getY((DrawingAssociation) asc.AChild1);
                    int targetx = ((DrawingAssociation) asc.AChild1).x;

                    drawVertLine(g, asc.x, assocliney, targety, parentDrawingInstructions.get(asc.AChild1.parasite.name));
                    drawHorizLine(g, targety, asc.x, targetx, parentDrawingInstructions.get(asc.AChild1.parasite.name));
                    break;
            }
        }

        /*
         * Draws duplication and host switch events
         */
        void drawEdgeAssociation(Graphics g, DrawingAssociation asc) {
            DrawingAssociation nearChild = null;
            DrawingAssociation farChild = null;
            switch(asc.type)
            {
                case DUPLICATION:
                    nearChild = (DrawingAssociation) asc.AChild1;
                    farChild = (DrawingAssociation) asc.AChild2;
                break;
                case HOST_SWITCH:
                    if(hostTree.descendant(asc.associate, asc.AChild1.associate))
                    {
                        nearChild = (DrawingAssociation)asc.AChild1;
                        farChild = (DrawingAssociation)asc.AChild2;
                    }
                    else
                    {
                        nearChild = (DrawingAssociation)asc.AChild2;
                        farChild = (DrawingAssociation)asc.AChild1;
                    }
                    break;
            }

            int nearY = getY(nearChild);
            int farY = getY(farChild);
            
            drawHorizLine(g, nearY, asc.x, nearChild.x, parentDrawingInstructions.get(nearChild.parasite.name));
            drawHorizLine(g, farY, asc.x, farChild.x, parentDrawingInstructions.get(farChild.parasite.name));
            drawVertLine(g, asc.x, nearY, farY, parentDrawingInstructions.get(farChild.parasite.name));
            asc.lane = nearChild.lane;
            placeNode(asc.parasite.name, asc.x, nearY);

            if(asc.type == Association.AssociationType.HOST_SWITCH)
                drawArrow(g, asc.x, (nearY + farY) / 2, laneHeight * 2 / 3, laneHeight * 2 / 3, nearY < farY);
        }

        /*
         * Draws nodes of the host tree, and the parasite tree nodes that
         * are associated with them.
         */
        void drawNode(java.awt.Graphics g, node n, int x, int y, DrawLocation location) {
            int endx = xPos.get(n.time);
            int liney = lineY.get(n.name);

            if (n.Root()) {
                drawNode(g, n.children.get(0), x, y, DrawLocation.OTHER);
            } else {
                //Draw the host tree portion for this node
                int prevX = x;
                for(int time = n.parents.get(0).time+1; time <= n.time; ++time)
                {
                    if(time == n.time)
                        drawHorizLine(g, liney, prevX, xPos.get(time) - eventWidth/2,
                            hostEdgeTimeDrawingInstructions.get(n.name).get(time));
                    else
                        drawHorizLine(g, liney, prevX, xPos.get(time),
                            hostEdgeTimeDrawingInstructions.get(n.name).get(time));
                    prevX = xPos.get(time);
                }
                drawHorizLine(g, liney, xPos.get(n.time) - eventWidth/2, xPos.get(n.time), hostNodeDrawingInstructions.get(n.name));

                if (n.Tip()) {
                    g.drawString(n.fancyName, endx + nodeSize/2 + 1, liney + textHeight / 2);
                } else {
                    drawNode(g, n.children.get(0), endx, y, DrawLocation.TOP);
                    drawNode(g, n.children.get(1), endx, liney, DrawLocation.BOTTOM);
                }

                //Draw all events that take place at the node
                for (DrawingAssociation asc : incidentAssociations.get(n.name)) {
                    drawIncidentAssociation(g, asc, n);
                }

                //Draw events on the preceding edge
                //We do this in reverse order so children get lanes before parents are drawn.
                Vector<DrawingAssociation> previousEdge = previousEdgeEvents.get(n.name);
                for (int i = previousEdge.size() - 1; i >= 0; --i) {
                    DrawingAssociation asc = previousEdge.get(i);

                    drawEdgeAssociation(g, asc);
                }
            }

            //Draw a line up or down to connect to the previous host tree line
            if (location == DrawLocation.BOTTOM) {
                drawVertLine(g, x, y, liney, hostNodeDrawingInstructions.get(n.parents.get(0).name));
            } else if (location == DrawLocation.TOP) {
                drawVertLine(g, x, lineY.get(n.parents.get(0).name), liney, hostNodeDrawingInstructions.get(n.parents.get(0).name));
            }
        }

        timedTreeLocation whereOnTree(int x, int y)
        {
            int time;
            for(time = timeEvents.firstKey(); time <= timeEvents.lastKey(); time++)
            {
                if(xPos.get(time) > x)
                    break;
            }
            if(time > timeEvents.lastKey())
                return null;

            if(time != timeEvents.lastKey())
            {
                node n = hostTree.nodeAtTime(time);
                if(!n.Root())
                    if(x >= xPos.get(time) - eventWidth/2 && y >= lineY.get(n.children.get(0).name) && y <= lineY.get(n.children.get(1).name))
                        return new timedTreeLocation(n, time);
            }

            Vector<edge> activeEdges = hostTree.liveEdges(time);
            for(edge e : activeEdges)
                if(y >= lineY.get(e.second.name) - laneHeight && y <= lineY.get(e.second.name) + laneHeight)
                    return new timedTreeLocation(e, time);

            return null;
        }
    }

    class ParasiteNode extends javax.swing.JComponent implements java.awt.event.MouseListener, java.awt.event.MouseMotionListener {

        abstract class ChildrenHandler
        {
            abstract void handleChildren(int i1, int whichChildAmI, int otherCost, MultiAssociation parent);
        }

        private int sideLength = 8;
        private int bestCost;
        private DrawingAssociation myAssoc;
        public boolean dragging = false;
        private java.awt.Color borderColor;

        public int getSideLength() {
            return sideLength;
        }

        public void setSideLength(int sideLength) {
            this.sideLength = sideLength;
            this.setPreferredSize(new java.awt.Dimension(sideLength + 2, sideLength + 2));
            this.setSize(this.getPreferredSize());
        }

        public ParasiteNode(DrawingAssociation asc) {
            this.setPreferredSize(new java.awt.Dimension(sideLength + 2, sideLength + 2));
            this.setSize(this.getPreferredSize());
            myAssoc = asc;
            this.setToolTipText(asc.parasite.fancyName);
            this.addMouseListener(this);
            this.addMouseMotionListener(this);
            borderColor = findBorderColor();
        }

        @Override
        public void paint(Graphics g) {
            java.awt.Graphics2D gp = (java.awt.Graphics2D) g;
            gp.setColor(borderColor);
            gp.fillOval(0, 0, sideLength, sideLength);
            if(myAssoc.type == Association.AssociationType.COSPECIATION)
            {
                gp.setColor(gp.getBackground());
                gp.fillOval(2, 2, sideLength-4, sideLength-4);
            }
        }

        java.awt.Color findBorderColor()
        {
            bestCost = pNetwork.INFINITY;
            int targetCost;
            if(myAssoc.parasite.Root())
            {
                targetCost = myAssoc.cost;
                
                for(MultiAssociation asc : alternateRoots)
                {
                    if(asc.isDistinct(myAssoc))
                    {
                        bestCost = Math.min(bestCost, asc.cost);
                    }
                }
            }
            else
            {
                targetCost = multiAssocs.get(myAssoc.parasite.parents.get(0).name).cost;
                processAlternateLocations(new ChildrenHandler()
                {
                    void handleChildren(int i1, int whichChildAmI, int otherCost, MultiAssociation parent)
                    {
                        bestCost = Math.min(bestCost, findMinCost(i1, whichChildAmI, otherCost, parent));
                    }
                });
            }
            
            if(bestCost < targetCost)
                return Color.GREEN;
            else if(bestCost == targetCost)
                return Color.YELLOW;
            else
                return Color.BLUE;
        }

        public void mouseClicked(MouseEvent e) {
        }

        MultiAssociation findTwin(MultiAssociation asc)
        {
            if(asc.parasite.Root())
            {
                for(MultiAssociation assoc : alternateRoots)
                {
                    if(assoc.associate.equals(asc.associate) && asc.time == assoc.time && asc.type != assoc.type)
                        return assoc;
                }
            }
            else
            {
                MultiAssociation parent = multiAssocs.get(asc.parasite.parents.get(0).name);
                Vector<Vector<MultiAssociation>> potentialClones;
                if(parent.AChild1 == asc)
                    potentialClones = parent.child1options;
                else
                    potentialClones = parent.child2options;

                for(Vector<MultiAssociation> assocs : potentialClones)
                {
                    for(MultiAssociation assoc : assocs)
                    {
                        if(assoc.associate.equals(asc.associate) && asc.time == assoc.time && asc.type != assoc.type)
                            return assoc;
                    }
                }
            }
            return null;
        }

        void colorHostAssoc(MultiAssociation assoc, EdgeDrawingInstruction inst)
        {
            if(assoc.associate instanceof edge)
            {
                hostEdgeTimeDrawingInstructions.get(((edge)assoc.associate).second.name).put(assoc.time, inst);
            }
            else
            {
                hostNodeDrawingInstructions.put(((node)assoc.associate).name, inst);
            }
        }

        void colorHost(timedTreeLocation loc, EdgeDrawingInstruction inst)
        {
            if(loc.loc instanceof edge)
            {
                hostEdgeTimeDrawingInstructions.get(((edge)loc.loc).second.name).put(loc.time, inst);
            }
            else
            {
                hostNodeDrawingInstructions.put(((node)loc.loc).name, inst);
            }
        }

        int findMinCost(int i1, int whichChildAmI, int otherCost, MultiAssociation parent)
        {
            int minCost = pNetwork.INFINITY;

            Vector<MultiAssociation> myAssocs;
            if(whichChildAmI == 1)
                myAssocs = parent.child1options.get(i1);
            else
                myAssocs = parent.child2options.get(i1);
            for(int i2 = 0; i2 < myAssocs.size(); i2++)
                if(myAssocs.get(i2).isDistinct(myAssoc))
                    minCost = Math.min(minCost, otherCost + parent.subAssociationCost(i1, i2, whichChildAmI, hostTree) +
                        parent.getCost(hostTree));

            return minCost;
        }

        void colorParentChild(int i1, int whichChildAmI, int otherCost, MultiAssociation parent)
        {
            if(otherCost >= pNetwork.INFINITY)
                return;

            MultiAssociation originalParent = multiAssocs.get(parent.parasite.name);

            Vector<MultiAssociation> myAssocs;
            if(whichChildAmI == 1)
                myAssocs = parent.child1options.get(i1);
            else
                myAssocs = parent.child2options.get(i1);
            for(int i2 = 0; i2 < myAssocs.size(); i2++)
                if(parent.subAssociationCost(i1, i2, whichChildAmI, hostTree) < pNetwork.INFINITY)
                    colorHostAssoc(myAssocs.get(i2), EdgeDrawingInstruction.RED_THICK);

            for(int i2 = 0; i2 < myAssocs.size(); i2++)
                if(otherCost + parent.subAssociationCost(i1, i2, whichChildAmI, hostTree) == originalParent.cost - parent.getCost(hostTree))
                    colorHostAssoc(myAssocs.get(i2), EdgeDrawingInstruction.YELLOW_THICK);

            for(int i2 = 0; i2 < myAssocs.size(); i2++)
                if(otherCost + parent.subAssociationCost(i1, i2, whichChildAmI, hostTree) < originalParent.cost - parent.getCost(hostTree))
                    colorHostAssoc(myAssocs.get(i2), EdgeDrawingInstruction.GREEN_THICK);
        }

        /* This traverses all possible places that an association can be placed
         * without moving the parent. This switches based on what the parent is.
         * If the parent is a cospeciation, then the child can go anywhere that
         * is a descendant of that parent.
         * If the parent is a duplication, the child can go anywhere that is
         * a descendant of it, and also the child can go anywhere else on the
         * tree, which will transform the parent into a host switch.
         * If the parent is a host switch, then there are two different cases
         * If the child is the desecendant of the switch, then it can either move
         * around there, or be switched with the other child, and go somewhere far.
         * If the child is the far descendant, it can either stay far, or it can
         * move close and transform the parent into a duplication.
         */
        void processAlternateLocations(ChildrenHandler ch)
        {
            MultiAssociation parent = multiAssocs.get(myAssoc.parasite.parents.get(0).name);
            if(parent.minChild1Costs == null)
                parent.calculateMinCosts(hostTree);


            Vector<Vector<MultiAssociation>> alternateMe;
            int whichChildAmI;
            MultiAssociation otherChild;
            Vector<Integer> otherCosts;

            if (parent.AChild1.parasite.equals(myAssoc.parasite))
            {
                alternateMe = parent.child1options;
                whichChildAmI = 1;
                otherChild = (MultiAssociation)parent.AChild2;
                otherCosts = parent.minChild2Costs;
            } else
            {
                alternateMe = parent.child2options;
                whichChildAmI = 2;
                otherChild = (MultiAssociation)parent.AChild1;
                otherCosts = parent.minChild1Costs;
            }

            if(parent.type == Association.AssociationType.COSPECIATION)
            {
                    for(int i = 0; i < parent.child1options.size(); i++)
                    {
                        if(alternateMe.get(i).size() > 0)
                        {
                            node parentNode = (node)parent.associate;
                            boolean originallyChild1 = hostTree.descendant(new edge(parentNode, parentNode.children.get(0)), myAssoc.associate);
                            boolean nowChild1 = hostTree.descendant(new edge(parentNode, parentNode.children.get(0)), alternateMe.get(i).get(0).associate);
                            if(nowChild1 == originallyChild1)
                            {
                                ch.handleChildren(i, whichChildAmI, parent.childCost(otherChild, hostTree), parent);
                            }
                            else
                            {
                                ch.handleChildren(i, whichChildAmI, otherCosts.get(i), parent);
                            }
                        }
                    }
            }
            else if(parent.type == Association.AssociationType.DUPLICATION)
            {
                    for(int i = 0; i < alternateMe.size(); i++)
                    {
                        ch.handleChildren(i, whichChildAmI, parent.childCost(otherChild, hostTree), parent);
                    }


                    MultiAssociation evilHostSwitchTwin = findTwin(parent);

                    if(evilHostSwitchTwin != null)
                    {
                        if(evilHostSwitchTwin.minChild1Costs == null)
                            evilHostSwitchTwin.calculateMinCosts(hostTree);

                        //do something with the evilHostSwitchTwin
                        Vector<Vector<MultiAssociation>> TwinNotMe;
                        if(whichChildAmI == 1)
                        {
                            TwinNotMe = evilHostSwitchTwin.child2options;
                        }
                        else
                        {
                            TwinNotMe = evilHostSwitchTwin.child1options;
                        }

                        for(int i = 0; i < TwinNotMe.size(); i++)
                        {
                            if(TwinNotMe.get(i).size() > 0 && hostTree.descendant(evilHostSwitchTwin.associate, TwinNotMe.get(i).get(0).associate))
                            {
                                ch.handleChildren(i, whichChildAmI, parent.childCost(otherChild, hostTree), evilHostSwitchTwin);
                            }
                        }
                    }
            }
            else if(parent.type == Association.AssociationType.HOST_SWITCH)
            {
                    //We are the close child
                    if(hostTree.descendant(parent.associate, myAssoc.associate))
                    {
                        for(int i = 0; i < alternateMe.size(); i++)
                        {
                            //if we're not becoming the far one, use the real cost
                            if(alternateMe.get(i).size() > 0 && hostTree.descendant(parent.associate, alternateMe.get(i).get(0).associate))
                            {
                                ch.handleChildren(i, whichChildAmI, parent.childCost(otherChild, hostTree), parent);
                            }
                            else if(alternateMe.get(i).size() > 0) //If we are becoming the far one, use the optimal cost
                            {
                                ch.handleChildren(i, whichChildAmI, otherCosts.get(i), parent);
                            }
                        }
                    }
                    else //we are the far child
                    {
                        MultiAssociation evilDuplicationTwin = findTwin(parent);

                        //You can drag me somwhere else far
                        for(int i = 0; i < alternateMe.size(); i++)
                        {
                            if(alternateMe.get(i).size() > 0 && !hostTree.descendant(parent.associate, alternateMe.get(i).get(0).associate))
                            {
                                ch.handleChildren(i, whichChildAmI, parent.childCost(otherChild, hostTree), parent);
                            }
                        }

                        if(evilDuplicationTwin == null)
                            return;
                        if(evilDuplicationTwin.minChild1Costs == null)
                            evilDuplicationTwin.calculateMinCosts(hostTree);

                        //Or somewhere close, and I become my evil twin
                        Vector<Vector<MultiAssociation>>TwinAlternateMe;
                        if(whichChildAmI == 1)
                        {
                            TwinAlternateMe = evilDuplicationTwin.child1options;
                        }
                        else
                        {
                            TwinAlternateMe = evilDuplicationTwin.child2options;
                        }
                        for(int i = 0; i < TwinAlternateMe.size(); i++)
                        {
                            ch.handleChildren(i, whichChildAmI, parent.childCost(otherChild, hostTree), evilDuplicationTwin);
                        }
                    }
            }
        }

        void colorAlternates()
        {
            processAlternateLocations(new ChildrenHandler(){
                void handleChildren(int i1, int whichChildAmI, int otherCost, MultiAssociation parent)
                {
                    colorParentChild(i1, whichChildAmI, otherCost, parent);
                }
            });
        }

        /*
         * When the mouse is pressed, we color the host tree to represent
         * the cost of moving the association there.
         */
        public void mousePressed(MouseEvent e) {
            if(myAssoc.parasite.Tip())
                return;
            
            dragging = true;

            if(myAssoc.parasite.Root())
            {
                int minCost = pNetwork.INFINITY;
                for(MultiAssociation ma : alternateRoots)
                    minCost = Math.min(minCost, ma.cost);

                for (MultiAssociation asc : alternateRoots)
                {
                    colorHostAssoc(asc, EdgeDrawingInstruction.RED_THICK);
                }
                for(MultiAssociation asc : alternateRoots)
                {
                    if(asc.cost == solution.cost)
                        colorHostAssoc(asc, EdgeDrawingInstruction.YELLOW_THICK);
                }
                for(MultiAssociation asc : alternateRoots)
                {
                    if(asc.cost < solution.cost)
                        colorHostAssoc(asc, EdgeDrawingInstruction.GREEN_THICK);
                }
            }

            else
            {
                colorAlternates();
            }

            this.getParent().repaint();
        }

        public void mouseReleased(MouseEvent e) {
            if(myAssoc.parasite.Tip())
                return;
            dragging = false;
            assignHostDrawing();
            timedTreeLocation t = ((SolutionPane)(this.getParent())).whereOnTree(this.getX(), this.getY());

            currentLoc = null;

            java.awt.Component parent = this.getParent();

            if(t != null)
                handleDrop(t);       

            parent.repaint();

            hostTree.checkConsistency();
        }
        
        void handleDrop(timedTreeLocation t)
        {
            if(t.loc.equals(myAssoc.associate) && t.time == myAssoc.time)
                return;
            if(myAssoc.parasite.Root())
            {
                int minCost = pNetwork.INFINITY;
                MultiAssociation minAsc = null;

                for(MultiAssociation ma : alternateRoots)
                {
                    if(ma.time == t.time && ma.associate.equals(t.loc) && ma.cost < minCost)
                    {
                        minCost = ma.cost;
                        minAsc = ma;
                    }
                }

                if(minAsc != null)
                    reloadAssociations(minAsc);
            }
            else
            {
                processAlternateLocations(new dropHandler(t));
            }
        }

        class dropHandler extends ChildrenHandler
        {
            timedTreeLocation t;
            dropHandler(timedTreeLocation t)
            {
                this.t = t;
            }
            void handleChildren(int i1, int whichChildAmI, int otherCost, MultiAssociation parent)
            {
                Vector<MultiAssociation> myAssocs;
                Vector<Integer> otherOptCosts;
                if (whichChildAmI == 1) {
                    myAssocs = parent.child1options.get(i1);
                    otherOptCosts = parent.minChild2Costs;
                } else {
                    myAssocs = parent.child2options.get(i1);
                    otherOptCosts = parent.minChild2Costs;
                }
                int answerIndex = -1;

                for(int i2 = 0; i2 < myAssocs.size(); i2++)
                {
                    if(myAssocs.get(i2).time == t.time && myAssocs.get(i2).associate.equals(t.loc))
                    {
                        if(answerIndex == -1 || parent.subAssociationCost(i1, i2, whichChildAmI, hostTree) <
                                                parent.subAssociationCost(i1, answerIndex, whichChildAmI, hostTree))
                        {
                            answerIndex = i2;
                        }
                    }
                }

                if(answerIndex != -1)
                {
                    if(parent.subAssociationCost(i1, answerIndex, whichChildAmI, hostTree) < pNetwork.INFINITY&&
                            otherOptCosts.get(i1) < pNetwork.INFINITY)
                        setChild(parent, myAssocs.get(answerIndex), whichChildAmI, i1);
                }
            }
        }

        /*
         * Completes a drag operation by mutating the MultiAssociations.
         * This handles the same cases as ProcessAlternativeLocations
         */
        void setChild(MultiAssociation parent, MultiAssociation child, int whichChild, int whichSolutions)
        {
            //clear up any parent confusion we may have incurred.
            parent = multiAssocs.get(parent.parasite.name);

            MultiAssociation oldMe;
            if(whichChild == 1)
                oldMe = (MultiAssociation)parent.AChild1;
            else
                oldMe = (MultiAssociation)parent.AChild2;
            
            if(parent.type == Association.AssociationType.COSPECIATION)
            {
                if(whichChild == 1)
                    parent.AChild1 = child;
                else
                    parent.AChild2 = child;

                node parentNode = (node)parent.associate;
                boolean wasonhost0 = hostTree.descendant(new edge(parentNode, parentNode.children.get(0)), oldMe.associate);
                boolean isonhost0 = hostTree.descendant(new edge(parentNode, parentNode.children.get(0)), child.associate);
                if(isonhost0 != wasonhost0)
                {
                    Vector<MultiAssociation> other;
                    if(whichChild == 1)
                        other = parent.child2options.get(whichSolutions);
                    else
                        other = parent.child1options.get(whichSolutions);

                    if(other.size() == 0)
                        return;
                    MultiAssociation bestOther = other.get(0);
                    for(MultiAssociation asc : other)
                        if(asc.cost < bestOther.cost)
                            bestOther = asc;

                    if(whichChild == 1)
                        parent.AChild2 = bestOther;
                    else
                        parent.AChild1 = bestOther;
                }
            }
            else if(parent.type == Association.AssociationType.DUPLICATION)
            {
                if(hostTree.descendant(parent.associate, child.associate))
                {
                    if(whichChild == 1)
                        parent.AChild1 = child;
                    else
                        parent.AChild2 = child;
                }
                else
                {
                    MultiAssociation twin = findTwin(parent);
                    if(!parent.parasite.Root())
                    {
                        MultiAssociation parentParent = getParent(parent);
                        if(parentParent.AChild1 == parent)
                        {
                            parentParent.AChild1 = twin;
                        }
                        else
                        {
                            parentParent.AChild2 = twin;
                        }
                    }
                    if(whichChild == 1)
                    {
                        twin.AChild1 = child;
                        twin.AChild2 = parent.AChild2;
                        twin.switchTarget = twin.switchTargets.get(whichSolutions).get(twin.child1options.get(whichSolutions).indexOf(child));
                    }
                    else
                    {
                        twin.AChild1 = parent.AChild1;
                        twin.AChild2 = child;
                        twin.switchTarget = twin.switchTargets.get(whichSolutions).get(twin.child2options.get(whichSolutions).indexOf(child));
                    }
                    parent = twin;
                }
            }
            else if(parent.type == Association.AssociationType.HOST_SWITCH)
            {
                boolean wasClose = hostTree.descendant(parent.associate, oldMe.associate);
                boolean isClose = hostTree.descendant(parent.associate, child.associate);
                if(wasClose == isClose)
                {
                    if(whichChild == 1)
                    {
                        parent.AChild1 = child;
                        if(!isClose)
                            parent.switchTarget = parent.switchTargets.get(whichSolutions).get(parent.child1options.get(whichSolutions).indexOf(child));
                    }
                    else
                    {
                        parent.AChild2 = child;
                        if(!isClose)
                            parent.switchTarget = parent.switchTargets.get(whichSolutions).get(parent.child2options.get(whichSolutions).indexOf(child));
                    }
                }
                else if(isClose)
                {
                    System.out.println("Changed to close");
                    MultiAssociation twin = findTwin(parent);
                    if(!parent.parasite.Root())
                    {
                        MultiAssociation parentParent = getParent(parent);
                        if(parentParent.AChild1 == parent)
                        {
                            parentParent.AChild1 = twin;
                        }
                        else
                        {
                            parentParent.AChild2 = twin;
                        }
                    }
                    if(whichChild == 1)
                    {
                        twin.AChild1 = child;
                        twin.AChild2 = parent.AChild2;
                    }
                    else
                    {
                        twin.AChild1 = parent.AChild1;
                        twin.AChild2 = child;
                    }
                    parent = twin;
                }
                else if(wasClose)
                {
                    System.out.println("Changed from close!");
                    Vector<MultiAssociation> other;
                    if(whichChild == 1)
                        other = parent.child2options.get(whichSolutions);
                    else
                        other = parent.child1options.get(whichSolutions);

                    MultiAssociation bestOther = other.get(0);
                    for(MultiAssociation asc : other)
                        if(asc.cost < bestOther.cost)
                            bestOther = asc;

                    if(whichChild == 1)
                    {
                        parent.AChild1 = child;
                        parent.AChild2 = bestOther;
                        parent.switchTarget = parent.switchTargets.get(whichSolutions).get(parent.child1options.indexOf(child));
                    }
                    else
                    {
                        parent.AChild1 = bestOther;
                        parent.AChild2 = child;
                        parent.switchTarget = parent.switchTargets.get(whichSolutions).get(parent.child2options.indexOf(child));
                    }
                }
            }

            while(!parent.parasite.Root())
            {
                parent.reCalculateCosts(hostTree);
                parent = multiAssocs.get(parent.parasite.parents.get(0).name);
            }
            parent.reCalculateCosts(hostTree);
            reloadAssociations(parent);
        }

        MultiAssociation getParent(MultiAssociation child)
        {
            return multiAssocs.get(child.parasite.parents.get(0).name);
        }

        /*
         * Colors all edges incident to the association to a particular
         * color. For a tip, it colors the entire path up to the root.
         */
        void setLocalDrawingInstruction(EdgeDrawingInstruction instruction)
        {
            parentDrawingInstructions.put(myAssoc.parasite.name, instruction);
            if (myAssoc.AChild1 != null) {
                parentDrawingInstructions.put(myAssoc.AChild1.parasite.name, instruction);
            }
            if (myAssoc.AChild2 != null) {
                parentDrawingInstructions.put(myAssoc.AChild2.parasite.name, instruction);
            }

            if(myAssoc.parasite.Tip())
            {
                DrawingAssociation parent = myAssoc.parent;
                while(parent != null)
                {
                    parentDrawingInstructions.put(parent.parasite.name, instruction);
                    parent = parent.parent;
                }
            }
            this.getParent().repaint();
        }

        public void mouseEntered(MouseEvent e) {
            setLocalDrawingInstruction(EdgeDrawingInstruction.BLUE_THICK);
        }

        public void mouseExited(MouseEvent e) {
            if(!dragging)
               setLocalDrawingInstruction(EdgeDrawingInstruction.BLUE_THIN);
        }

        /*
         * Handles highlighting as the mouse is dragged.
         */
        timedTreeLocation currentLoc = null;
        public void mouseDragged(MouseEvent e) {
            if(dragging)
            {
                this.setLocation(this.getX() + e.getX() - sideLength/2, this.getY() + e.getY() - sideLength/2);
                if(currentLoc != null)
                {
                    EdgeDrawingInstruction oldInstruction;
                    if(currentLoc.loc.isEdge())
                    {
                        oldInstruction = hostEdgeTimeDrawingInstructions.get(((edge)currentLoc.loc).second.name).get(currentLoc.time);
                    }
                    else
                    {
                        oldInstruction = hostNodeDrawingInstructions.get(((node)currentLoc.loc).name);
                    }
                    colorHost(currentLoc, unOutlined(oldInstruction));
                }
                currentLoc = ((SolutionPane)(this.getParent())).whereOnTree(this.getX(), this.getY());
                if(currentLoc != null)
                {
                    EdgeDrawingInstruction oldInstruction;
                    if(currentLoc.loc.isEdge())
                    {
                        oldInstruction = hostEdgeTimeDrawingInstructions.get(((edge)currentLoc.loc).second.name).get(currentLoc.time);
                    }
                    else
                    {
                        oldInstruction = hostNodeDrawingInstructions.get(((node)currentLoc.loc).name);
                    }
                    colorHost(currentLoc, getOutlined(oldInstruction));
                }
            }
            this.getParent().repaint();
        }

        EdgeDrawingInstruction unOutlined(EdgeDrawingInstruction orig)
        {
            if(orig == EdgeDrawingInstruction.GREEN_OUTLINED)
                return EdgeDrawingInstruction.GREEN_THICK;
            if(orig == EdgeDrawingInstruction.RED_OUTLINED)
                return EdgeDrawingInstruction.RED_THICK;
            if(orig == EdgeDrawingInstruction.YELLOW_OUTLINED)
                return EdgeDrawingInstruction.YELLOW_THICK;

            return EdgeDrawingInstruction.BLACK_THICK;
        }

        EdgeDrawingInstruction getOutlined(EdgeDrawingInstruction original)
        {
            if(original.color == Color.GREEN)
                return EdgeDrawingInstruction.GREEN_OUTLINED;
            else if(original.color == Color.YELLOW)
                return EdgeDrawingInstruction.YELLOW_OUTLINED;
            else if(original.color == Color.RED)
                return EdgeDrawingInstruction.RED_OUTLINED;
            else
                return EdgeDrawingInstruction.BLACK_THICK;
        }

        public void mouseMoved(MouseEvent e) {

        }
    }

    class timedTreeLocation
    {
        treeLocation loc;
        int time;
        timedTreeLocation(treeLocation loc, int time)
        {
            this.loc = loc;
            this.time = time;
        }
    }

    /*
     * Saves the timing
     */
    void saveItemActionPerformed(java.awt.event.ActionEvent evt)
    {
        int saveResult = saveFile.showSaveDialog(this);
        if(saveResult == javax.swing.JFileChooser.APPROVE_OPTION)
        {
            try{
                java.io.FileWriter fw = new java.io.FileWriter(saveFile.getSelectedFile());
                fw.write(hostTree.fileTimingString());
                fw.close();
            }
            catch(java.io.IOException e)
            {
                JOptionPane.showMessageDialog(this, "Unable to write to the specified filename", "Error Writing File", JOptionPane.ERROR_MESSAGE);
                System.err.println(e);
            }
        }
    }

    void closeItemActionPerformed(java.awt.event.ActionEvent evt)
    {
        this.setVisible(false);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        mainMenu = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu("File");
        saveItem = new javax.swing.JMenuItem("Save Timing");
        sep1 = new javax.swing.JSeparator();
        closeItem = new javax.swing.JMenuItem("Close");

        mainMenu.add(fileMenu);
        fileMenu.add(saveItem);
        fileMenu.add(sep1);
        fileMenu.add(closeItem);
        this.setJMenuBar(mainMenu);

        saveItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));

        saveItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveItemActionPerformed(evt);
            }
        });

        closeItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W, InputEvent.CTRL_DOWN_MASK));
        closeItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeItemActionPerformed(evt);
            }
        });

        saveFile = new javax.swing.JFileChooser();

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>                        
    // Variables declaration - do not modify
    private javax.swing.JMenuBar mainMenu;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenuItem saveItem;
    private javax.swing.JSeparator sep1;
    private javax.swing.JMenuItem closeItem;
    private javax.swing.JFileChooser saveFile;
    // End of variables declaration                   
}
