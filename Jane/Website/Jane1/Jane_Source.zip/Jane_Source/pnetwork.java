/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of the Harvey Mudd College nor the names of its
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


import java.util.*;

/*
 * A class for representing phylogenetic networks.
 */
class pNetwork
{
    // This is infinity for distances inside trees.
    // If there is a 100-million depth tree, we have problems.
    static final int INFINITY = 100000000;

    /* Constructs a pNetwork from a mapping from nodes to their children,
     * A mapping from time zones to the names of those nodes,
     * and a list of (hopefully human-readable) names for those nodes
     */
    public pNetwork(Map<Integer, Vector<Integer>> adjacencyList, SortedMap<Integer, Vector<Integer>> zoneList, Map<Integer, String> realNames, Map<Integer, Map<Integer, Integer>> regionCosts, Map<Integer, Integer> nodeRegions)
    {
        this.adjacencyList = adjacencyList;
        this.realNames = realNames;
        this.size = 0;
        this._root = null;
        this.nodes = new TreeMap<Integer, node>();

        // Convert our adjacency list into our internal node class
        Set<Map.Entry<Integer, Vector<Integer>>> entrySet = adjacencyList.entrySet();
        for (Map.Entry<Integer, Vector<Integer>> value : entrySet)
        {
            int nodeName = value.getKey();
            size++;
            nodes.put(nodeName, new node(nodeName, realNames.get(nodeName)));
            nodes.get(nodeName).region = nodeRegions.get(nodeName);
        }
        for (Map.Entry<Integer, Vector<Integer>> value : entrySet)
        {
            int nodeName = value.getKey();
            node parent = nodes.get(nodeName);

            Vector<Integer> children = value.getValue();
            for (Integer childName : children)
            {
                node child = nodes.get(childName);
                child.addParent(parent);
                parent.addChild(child);
            }
        }

        this.zoneList = zoneList;
        this.regionCosts = regionCosts;
        
        for (Integer i : zoneList.keySet())
        {
            for (Integer n : zoneList.get(i))
            {
                nodes.get(n).addZone(i);
            }
            finalZone = i;
        }

        this.zoneTimes = new TreeMap<Integer, Integer>();
    }

    public pNetwork(Map<Integer, Vector<Integer>> adjacencyList, SortedMap<Integer, Vector<Integer>> zoneList, Map<Integer, String> realNames)
    {
        this.adjacencyList = adjacencyList;
        this.realNames = realNames;
        this.size = 0;
        this._root = null;
        this.nodes = new TreeMap<Integer, node>();

        // Convert our adjacency list into our internal node class
        Set<Map.Entry<Integer, Vector<Integer>>> entrySet = adjacencyList.entrySet();
        for (Map.Entry<Integer, Vector<Integer>> value : entrySet)
        {
            int nodeName = value.getKey();
            size++;
            nodes.put(nodeName, new node(nodeName, realNames.get(nodeName)));
        }
        for (Map.Entry<Integer, Vector<Integer>> value : entrySet)
        {
            int nodeName = value.getKey();
            node parent = nodes.get(nodeName);

            Vector<Integer> children = value.getValue();
            for (Integer childName : children)
            {
                node child = nodes.get(childName);
                child.addParent(parent);
                parent.addChild(child);
            }
        }

        this.zoneList = zoneList;

        for (Integer i : zoneList.keySet())
        {
            for (Integer n : zoneList.get(i))
            {
                nodes.get(n).addZone(i);
            }
            finalZone = i;
        }

        this.zoneTimes = new TreeMap<Integer, Integer>();
    }

    //Copy constructor for pNetworks
    public pNetwork(pNetwork other)
    {
        this(other.adjacencyList, other.zoneList, other.realNames);

        this.zoneTimes = new TreeMap<Integer, Integer>(other.zoneTimes);
        this.regionCosts = other.regionCosts;

        for (node n : other.nodes.values())
        {
            this.nodes.get(n.name).time = n.time;
            this.nodes.get(n.name).zone = n.zone;
            this.nodes.get(n.name).region = n.region;
        }
    }

    //Returns the root node of a pNetwork
    public node root()
    {
        if (_root != null)
        {
            return _root;
        }
        for (node candidate : nodes.values())
        {
            if (candidate.Root())
            {
                _root = candidate;
                return candidate;
            }
        }
        //this should never happen
        return null;
    }

    //Returns the children of a node. This method is for convenience only.
    public Vector<node> children(int nodeName)
    {
        return nodes.get(nodeName).children;
    }

    public boolean empty()
    {
        return size == 0;
    }

    //Finds the tips of the parasite tree
    public Vector<node> tips()
    {
        Vector<node> tips = new Vector<node>();
        for (node candidate : nodes.values())
        {
            if (candidate.Tip())
            {
                tips.add(candidate);
            }
        }
        return tips;
    }

    //Clears internal counters on the nodes that are used by other methods
    public void initializeCounters()
    {
        for (node n : nodes.values())
        {
            n.counter = 0;
            n.assigned = false;
        }
    }

    /*
     * Finds the distance from one location in the tree to another
     * viewing it as a directed graph from root to tips
     * returns infinity if no path can be found
     *
     * Optimization:
     * This method is a considerable portion of runtime. Pre-computing distances
     * instead of using the current memoizing approach may be a viable strategy
     * for improving runtime.
     */
    public int distance(treeLocation from, treeLocation to)
    {
        node start;
        node end;
        int offset = 0;
        boolean startnode = from instanceof node;
        boolean endnode = to instanceof node;

        if (!startnode && !endnode)
        {
            if (((edge) from).equals((edge) to))
            {
                return 0;
            }
            offset = 1;
        }

        if (startnode)
        {
            start = (node) from;
        } else
        {
            start = ((edge) from).second;
        }

        if (endnode)
        {
            end = (node) to;
        } else
        {
            end = ((edge) to).first;
        }

        if (end.ancestors.containsKey(start))
        {
            return end.ancestors.get(start) + offset;
        }
        Queue<nodeCostPair> bfsNodes = new LinkedList<nodeCostPair>();
        bfsNodes.offer(new nodeCostPair(start, 0));

        while (!bfsNodes.isEmpty())
        {
            nodeCostPair current = bfsNodes.poll();
            node n = current.n;
            if (!n.ancestors.containsKey(start))
            {
                n.ancestors.put(start, current.c);
            }
            if (n.equals(end))
            {
                return current.c + offset;
            }
            for (node child : n.children)
            {
                bfsNodes.offer(new nodeCostPair(child, current.c + 1));
            }
        }

        end.ancestors.put(start, INFINITY);

        return INFINITY;
    }

    public boolean descendant(treeLocation start, treeLocation end)
    {
        return distance(start, end) < INFINITY;
    }

    /*
     * Checks if one location on the tree is within a distance n of another
     * location on the tree, viewing it as an undirected graph.
     */
    public boolean withinDistanceN(treeLocation start, treeLocation end, int n)
    {
        if(n == -1)
            return true;
        initializeCounters();

        Queue<nodeCostPair> treelocs = new LinkedList<nodeCostPair>();

        if(start.isEdge())
        {
            node f = ((edge)start).first;
            node s = ((edge)start).second;
            f.assigned = true;
            s.assigned = true;
            treelocs.offer(new nodeCostPair(f, n));
            treelocs.offer(new nodeCostPair(s, n));
        }
        else
        {
            node s = (node)start;
            s.assigned = true;
            treelocs.offer(new nodeCostPair(s, n));
        }

        while(!treelocs.isEmpty())
        {
            nodeCostPair loc = treelocs.poll();
            if(end.isEdge())
            {
                if(loc.n.equals(((edge)end).first) || loc.n.equals(((edge)end).second))
                    return loc.c > 0;
            }
            else
            {
                if(loc.n.equals(end))
                    return true;
            }
            if(loc.c > 0)
            {
                for(node nod: loc.n.children)
                {
                    if(!nod.assigned)
                    {
                        nod.assigned = true;
                        treelocs.offer(new nodeCostPair(nod, loc.c-1));
                    }
                }
                for(node nod: loc.n.parents)
                {
                    if(!nod.assigned)
                    {
                        nod.assigned = true;
                        treelocs.offer(new nodeCostPair(nod, loc.c-1));
                    }
                }
            }
        }
        return false;
    }

    /*
     * Gets all edges that are active at a particular relative time.
     * by active we mean start_time < time <= end_time.
     */
    public Vector<edge> liveEdges(int time)
    {
        Vector<edge> liveEdges = new Vector<edge>();
        for (node n : nodes.values())
        {
            if (!n.Tip() && time > n.time)
            {
                for (node child : n.children)
                {
                    if (child.time >= time)
                    {
                        liveEdges.add(new edge(n, child));
                    }
                }
            }
        }
        return liveEdges;
    }

    /* Gets the node that has been assigned to a particular relative time.
     * Undefined if called on tipTime.
     */
    public node nodeAtTime(int time)
    {
        for (node n : nodes.values())
        {
            if (n.time == time)
            {
                return n;
            }
        }

        return null;
    }

    /*
     * Finds the first relative time that could possibly be within a paricular zone
     */
    public int timeZoneMin(int zone)
    {
        if (zone == zoneTimes.firstKey())
        {
            return 0;
        } else
        {
            return zoneTimes.get(zoneTimes.headMap(zone).lastKey()) + 1;
        }
    }

    /*
     * Finds the last relative time that could possibly be within a paticular zone
     */
    public int timeZoneMax(int zone)
    {
        if(!zoneTimes.containsKey(zone))
            return timeZoneMin(zone);
        return zoneTimes.get(zoneTimes.tailMap(zone).firstKey()) + 1;
    }

    /*
     * Internal testing method to see that time zone information stored on the
     * nodes is the same as that stored in other places.
     */
    public boolean checkConsistency()
    {
        for (node n : nodes.values())
        {
            // this fail is due to a node being assigned a zone which does not
            // occur in it's list of valid time zones
            if (n.zone < n.timeZones.firstElement() || n.zone > n.timeZones.lastElement())
            {
                System.out.println(n + " " + n.zone);
                System.out.println(n.timeZones);
                System.out.println("Fail1");
                return false;
            }

            // this fail is due to this pNetwork's zone list not containing
            // a node in the same time zone which the node thinks it's in
            if (!zoneList.get(n.zone).contains(n.name))
            {
                System.out.println(n + "\t" + n.zone);
                System.out.println(zoneList.get(n.zone));
                System.out.println("Fail2");
                return false;
            }
        }

        // this fail is due to no node in a given time zone actually having
        // the final time in that zone
        for (Integer z : zoneTimes.keySet())
        {
            boolean foundThis = false;
            for (Integer n : zoneList.get(z))
            {
                if (nodes.get(n).time == zoneTimes.get(z))
                {
                    foundThis = true;
                }
            }
            if (!foundThis)
            {
                System.out.println("Zone " + z + " has no node at final time?" + " (should be " + zoneTimes.get(z) + ")");
                System.out.println("Fail3");
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString()
    {
        String output = "\n=============== pNetwork ===============\n";
        for (node node : nodes.values())
        {
            output += node.timingString() + "\n";
        }
        output += "========================================";
        return output;
    }

    public String timingString()
    {
        int finalTime = tips().get(0).time;
        String output = "\n=============== pNetwork ===============\n";
        for (int i = 0; i < finalTime; i++)
        {
            output += nodeAtTime(i).timingString() + "\n";
        }
        output += "========================================";
        return output;
    }

    public String fileTimingString()
    {
        int finalTime = tips().get(0).time;
        StringBuilder output = new StringBuilder("");

        for (int i = 0; i < finalTime; i++)
        {
            output.append(nodeAtTime(i).fileTimingString()).append("\n");
        }

        for(node n : tips())
        {
            output.append(n.fileTimingString()).append("\n");
        }

        return output.toString();
    }

    public boolean equals(pNetwork other){
        if(!nodes.keySet().equals(other.nodes.keySet()))
            return false;
        for(Integer i : nodes.keySet()){
            if(this.nodes.get(i).time != other.nodes.get(i).time)
                return false;
        }
        return true;
    }

    
    Map<Integer, Vector<Integer>> adjacencyList;
    Map<Integer, String> realNames;

    SortedMap<Integer, Vector<Integer>> zoneList; // list of nodes which occur in a time zone
    SortedMap<Integer, Integer> zoneTimes; // the final time which occurs in a time zone

    Map<Integer, Map<Integer, Integer>> regionCosts; // holds the cost of switching from one region to the other region

    int finalZone;
    int size;
    Map<Integer, node> nodes;
    private node _root = null;

    //used in queues for breadth first search.
    private class nodeCostPair
    {

        int c;
        node n;

        nodeCostPair(node node, int cost)
        {
            c = cost;
            n = node;
        }
    }
}
