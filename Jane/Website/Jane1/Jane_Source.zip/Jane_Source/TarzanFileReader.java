/*
Copyright (c) 2009, Chris Conow, Daniel Fielder, Yaniv Ovidia, Ran Libeskind-Hadas
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name of the Harvey Mudd College nor the names of its
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


import java.io.*;
import java.util.*;

class TarzanFileReader extends TreeFileReader {

    public TarzanFileReader(String filename) throws FileNotFoundException {
        super(filename);
    }

    Map<Integer, Map<Integer, Integer>> readRegionCosts() throws IOException, FileFormatException
    {
        Map<Integer, Map<Integer, Integer>> answer = new HashMap<Integer, Map<Integer, Integer>>();
        try{
            while(true){
            String inline = fin.readLine();
            if(inline == null)
                break;
            String[] entry = inline.split("\\s");
            if(entry.length < 3)
                break;
            Integer firstReg = Integer.parseInt(entry[0]);
            if(!answer.containsKey(firstReg))
                answer.put(firstReg, new HashMap<Integer, Integer>());
            answer.get(firstReg).put(Integer.parseInt(entry[1]), Integer.parseInt(entry[2]));
        }
            return answer;
        }
        catch(NumberFormatException ex)
        {
            throw new FileFormatException("Every entry in the cost mapping for regions must be a number.");
        }
    }

    Map<Integer, Vector<Integer>> readTree() throws IOException, FileFormatException {
        try{
        Map<Integer, Vector<Integer>> answer = new TreeMap<Integer, Vector<Integer>>();
        while (true) {
            String[] entry = fin.readLine().split("\\s");
            if (entry.length < 2) {
                break;
            }
            int name = Integer.parseInt(entry[0]);
            Vector<Integer> children = new Vector<Integer>();
            for (int i = 1; i < entry.length; ++i) {
                if (!entry[i].equals("null")) {
                    children.add(Integer.parseInt(entry[i]));
                }
            }
            answer.put(name, children);
        }
        return answer;
        }
        catch(NumberFormatException e)
        {
            throw new FileFormatException("Specifications of tree structure must use only numbers and the word \"null\"");
        }
    }

    Map<Integer, String> readNames() throws IOException, FileFormatException{
        try
        {
            Map<Integer, String> answer = new TreeMap<Integer, String>();
            while (true)
            {
                String[] entry = fin.readLine().split("\\s", 2);
                if (entry.length < 2)
                {
                    break;
                }
                int name = Integer.parseInt(entry[0]);
                answer.put(name, entry[1]);
            }
            return answer;
        }
        catch(NumberFormatException ex)
        {
            throw new FileFormatException("Each host/parasite to be named must be identified by a number");
        }
    }

    Map<Integer, Integer> readPhi() throws IOException, FileFormatException {
        try
        {
            Map<Integer, Integer> answer = new TreeMap<Integer, Integer>();
            while (true)
            {
                String[] entry = fin.readLine().split("\\s");
                if (entry.length < 2)
                {
                    break;
                }
                int name = Integer.parseInt(entry[0]);
                answer.put(Integer.parseInt(entry[1]), name);
            }
            return answer;
        }
        catch(NumberFormatException ex)
        {
            throw new FileFormatException("Every host and parasite must be identified by a number.");
        }
    }
   

    Map<Integer, Integer> readRegions() throws IOException, FileFormatException {
        try
        {
            Map<Integer, Integer> answer = new TreeMap<Integer, Integer>();
            while (true)
            {
                String[] entry = fin.readLine().split("\\s");
                if (entry.length < 2)
                {
                    break;
                }
                answer.put(Integer.parseInt(entry[0]), Integer.parseInt(entry[1]));
            }
            return answer;
        }
        catch(NumberFormatException ex)
        {
            throw new FileFormatException("Every host and region in the region mapping must be identified by a number.");
        }
    }

    SortedMap<Integer, Vector<Integer>> readRanks() throws IOException, FileFormatException {
        Map<Integer, Vector<Integer>> answer = new TreeMap<Integer, Vector<Integer>>();
        try
        {
        while (true) {
            String s = fin.readLine();
            if (s == null) {
                break;
            }
            String[] entry = s.split("[\\s,]");
            if (entry.length < 2) {
                break;
            }
            int name = Integer.parseInt(entry[0]);

            Vector<Integer> times = new Vector<Integer>();
            if (entry.length == 2) {
                times.add(Integer.parseInt(entry[1]));
                answer.put(name, times);
            } else {
                for (int j = Integer.parseInt(entry[1]); j <= Integer.parseInt(entry[2]); ++j) {
                    times.add(j);
                }
                answer.put(name, times);
            }
        }
        }
        catch(NumberFormatException exc)
        {
            throw new FileFormatException("All host/parasite vertices and time zones must be represented by numbers");
        }

        SortedMap<Integer, Vector<Integer>> finalAnswer = new TreeMap<Integer, Vector<Integer>>();
        for (Map.Entry<Integer, Vector<Integer>> me : answer.entrySet()) {
            for (Integer i : me.getValue()) {
                if (!finalAnswer.containsKey(i)) {
                    finalAnswer.put(i, new Vector<Integer>());
                }
                finalAnswer.get(i).add(me.getKey());
            }
        }
        return finalAnswer;
    }

    boolean readToToken(String token) throws java.io.IOException{
        String s = fin.readLine();
        while (s != null && !token.equals(s)) {
            s = fin.readLine();
        }
        return token.equals(s);
    }

    void seekString(String s) throws FileFormatException, java.io.IOException{
        if (!readToToken(s)) {
            throw new FileFormatException("Missing token " + s + " in input file. Please choose a valid tarzan tree file");
        }
    }

    public ProblemInstance readProblem() throws FileFormatException, java.io.IOException{
        seekString("HOSTTREE");
        Map<Integer, Vector<Integer>> host = readTree();

        seekString("HOSTNAMES");
        Map<Integer, String> hostNames = readNames();

        seekString("PARASITETREE");
        Map<Integer, Vector<Integer>> parasite = readTree();

        seekString("PARASITENAMES");
        Map<Integer, String> parasiteNames = readNames();

        seekString("PHI");
        Map<Integer, Integer> phi = readPhi();

        seekString("HOSTRANKS");
        SortedMap<Integer, Vector<Integer>> hostRanks = readRanks();

        seekString("PARASITERANKS");
        SortedMap<Integer, Vector<Integer>> parasiteRanks = readRanks();

        //Add an implied root to the host tree
        Map<Integer, Integer> inDegree = new HashMap<Integer, Integer>();
        for (Integer node : host.keySet())
        {
            inDegree.put(node, 0);
        }
        for (Vector<Integer> me : host.values())
        {
            for (Integer i : me)
            {
                inDegree.put(i, inDegree.get(i) + 1);
            }
        }
        int root = -1;
        for (Map.Entry<Integer, Integer> me : inDegree.entrySet())
        {
            if (me.getValue().intValue() == 0)
            {
                root = me.getKey();
            }
        }

        Vector<Integer> rootChild = new Vector<Integer>();
        rootChild.add(root);
        host.put(-1, rootChild);
        hostNames.put(-1, "Implied Root");
        for (Vector<Integer> rankList : hostRanks.values())
        {
            if (rankList.contains(root))
            {
                rankList.add(-1);
                break;
            }
        }
        //Done adding the implied root

        for (Map.Entry<Integer, Vector<Integer>> par : parasite.entrySet())
        {
            if (par.getValue().size() == 0 && phi.get(par.getKey()) == null)
            {
                throw new FileFormatException("Not all parasite tips are mapped to host tips.");
            }
        }

        if(readToToken("HOSTREGIONS"))
        {
            Map<Integer, Integer> hostRegions = readRegions();

            hostRegions.put(-1, -1);

            seekString("REGIONCOSTS");

            Set<Integer> regions = new TreeSet<Integer>();
            
            regions.addAll(hostRegions.values());

            Map<Integer, Map<Integer, Integer>> regionCosts = readRegionCosts();

            for(Integer r1: regions)
            {
                if(!regionCosts.containsKey(r1))
                    regionCosts.put(r1, new HashMap<Integer, Integer>());

                for(Integer r2 : regions)
                {
                    if(!regionCosts.get(r1).containsKey(r2))
                        regionCosts.get(r1).put(r2, 0);
                }
            }

            return new ProblemInstance(host, hostNames, hostRanks, parasite, parasiteNames, parasiteRanks, phi, hostRegions, regionCosts);
        }
        else
        {
            return new ProblemInstance(host, hostNames, hostRanks, parasite, parasiteNames, parasiteRanks, phi);
        }
    }
}
